export class ReporteGenerico {
  tipoReporte: string;
  archivoBytes: any;
  constructor() { }
}
