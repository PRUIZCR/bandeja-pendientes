import { Sorteo } from "./sorteo";
import { Zona } from "./zona";
import { FuncionarioDisponible } from "./funcionariodisponible";
import { DetalleAsignafuncionarioZona } from "./detalleasignafuncionariozona";

export class AsignaFuncionarioZona {
  numAsignacion: number;
  sorteo: Sorteo;
  fecAsignacion: Date;
  estado: string;
  motivo: string;
  tipoAsignacion: string;
  fecEliminacion: Date;
  detallesAsignacion: DetalleAsignafuncionarioZona[];
  zonasDisponibles: Zona[];
  funcionariosDisponibles: FuncionarioDisponible[];

  constructor() { }
}
