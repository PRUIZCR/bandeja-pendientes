import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MantenimientoUnidadDespachoComponent } from './mantenimiento-unidad-despacho.component';

describe('MantenimientoUnidadDespachoComponent', () => {
  let component: MantenimientoUnidadDespachoComponent;
  let fixture: ComponentFixture<MantenimientoUnidadDespachoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MantenimientoUnidadDespachoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MantenimientoUnidadDespachoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
