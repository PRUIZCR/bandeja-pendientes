import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Unidaddespacho } from 'src/app/models/unidaddespacho';
import { Turno } from 'src/app/models/turno';
import { Zona } from 'src/app/models/zona';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { ConstantesListas } from 'src/app/utils/constanteslistas';
import { ResultadoRest } from 'src/app/models/resultadorest';
import { Datacatalogo } from 'src/app/models/datacatalogo';
import { MatTableDataSource } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { TurnoService } from 'src/app/services/turno.service';
import { ResponseManager } from 'src/app/models/responsemanager';
import { ResponseErrorManager } from 'src/app/models/responseerrormanager';
import { ZonaService } from 'src/app/services/zona.service';
import * as moment from 'moment';
import { ModalDirective } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-mantenimiento-turno',
  templateUrl: './mantenimiento-turno.component.html',
  styleUrls: ['./mantenimiento-turno.component.css']
})
export class MantenimientoTurnoComponent implements OnInit {
  @ViewChild('childTurnoModal') childTurnoModal : ModalDirective;
  objTurno: Turno;
  tituloTurno: string;
  esFormularioDeRegistro: boolean = false;
  responseResult: ResultadoRest;
  listZonas: Zona[];
  displayedColumns: string[];
  zonasDS: MatTableDataSource<Zona>;
  selection: SelectionModel<Zona>;
  private estadoOperacion$ = new Subject<String>();
  responseManager: ResponseManager;
  responseErrorManager: ResponseErrorManager;
  txtHora: string;
  txtHora15: string;
  btnGrabarTurno: boolean = true;
  esFecIniVigencia: boolean = false;
  desabilitarHoraCorteFechaDesde: boolean = true;
  funcionesGenerales: FuncionesGenerales;

  constructor(private turnoService: TurnoService,
              private zonaService: ZonaService) {
    this.objTurno = new Turno();
    this.objTurno.unidadDespacho = new Unidaddespacho();
    this.objTurno.unidadDespacho.aduana = new Datacatalogo();
    this.objTurno.zonas = [];
    this.funcionesGenerales = FuncionesGenerales.getInstance();
  }

  ngOnInit() {
  }

  addTurno(turno: Turno, objUnidadDespachoSeleccionado: Unidaddespacho) {
    this.objTurno = FuncionesGenerales.getInstance().clonarObjeto(turno);
    this.objTurno.unidadDespacho = objUnidadDespachoSeleccionado;
    this.esFecIniVigencia = false;
    this.desabilitarHoraCorteFechaDesde = true;
    if (turno.numTurno > 0) {
      this.esFormularioDeRegistro = false;
      this.tituloTurno = ConstantesCadenas.TITULO_MODIFICAR_TURNO;
      this.objTurno.fecInicioVigencia = new Date(turno.fecInicioVigencia);
      this.objTurno.fecFinVigencia = new Date(turno.fecFinVigencia);
      this.objTurno.hraCorte = this.objTurno.hraCorte == " " ? "" : this.objTurno.hraCorte;
      this.validarFechaInicioVigencia();
    } else {
      this.esFormularioDeRegistro = true;
      this.tituloTurno = ConstantesCadenas.TITULO_AGREGAR_TURNO;
      this.objTurno.nombre = "";
      this.objTurno.hraInicio = "";
      this.objTurno.hraFin = "";
      this.objTurno.hraCorte = "";
      this.objTurno.fecInicioVigencia = new Date();
      this.objTurno.fecFinVigencia = new Date();
      this.objTurno.zonas = [];
      this.esFecIniVigencia = false;
    }
    let campos: string = "numZona,nombre,descripcion,fecInicioVigencia,fecFinVigencia";
    this.zonaService.listarZonas(this.objTurno.unidadDespacho.numUnidadDespacho.toString(),
                                 ConstantesCadenas.ESTADO_VIGENTE,
                                 campos).subscribe(result => {
     FuncionesGenerales.getInstance().cerrarModalCargando();
     this.listZonas = result as Zona[];
     if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.listZonas)) {
       this.cargarZonas(this.objTurno);
     } else {
       this.listZonas = [];
     }
    }, error => console.error(error));
    this.childTurnoModal.show();
  }

  cargarZonasSeleccionados() {
    if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.listZonas)) {
      this.objTurno.zonas = this.selection.selected as Zona[];
      this.btnGrabarTurno = true;
      return true;
    } else {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
      "Mensajes de Error: ", "El rango de vigencia que intenta registrar se encuentra fuera del rango de vigencia de las zonas asociadas a la unidad de despacho.", "");
      this.btnGrabarTurno = false;
      return false;
    }
  }

  cargarZonas(turno: Turno) {
    this.displayedColumns = ConstantesListas.COLUMNAS_GRID_ZONAS_DE_TURNOS;
    this.zonasDS = new MatTableDataSource<Zona>(this.listZonas);
    this.selection = new SelectionModel<Zona>(true, []);
    if (turno.numTurno != 0) {
      for (let i = 0; i < this.zonasDS.data.length; i++) {
        for (let j = 0; j < this.objTurno.zonas.length; j++) {
          if (this.objTurno.zonas[j].numZona == this.zonasDS.data[i].numZona) {
            this.selection.select(this.zonasDS.data[i]);
          }
        }
      }
    }
  }

  cerrarTurno() {
    this.childTurnoModal.hide();
  }

  registrarActualizarTurno() {
    if (!this.cargarZonasSeleccionados()) {
      return false;
    }
    if (!this.validarDatosTurnos()) {
      return false;
    }
    this.registrarTurno();
  }

  callback = () : void => {
    this.cerrarTurno();
    this.estadoOperacion$.next("X");
  };

  registrarTurno() {
    this.objTurno.hraCorte = this.objTurno.hraCorte == "" ? " " : this.objTurno.hraCorte;
    this.turnoService.registrarActualizarTurno(this.objTurno).subscribe(
      response => {
        console.log(response);
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(
          ConstantesCadenas.MENSAJE_EXITOSO,
          "El turno se " + (this.objTurno.numTurno == -1 ? "registro" : "modifico") + " correctamente.",
          "", "", this.callback);
      },
      errorResult => {
        if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
          let responseManager: ResponseManager = new ResponseManager();
          this.responseErrorManager = errorResult as ResponseErrorManager;
          responseManager.cod = errorResult.cod;
          responseManager.errors = [this.responseErrorManager];
          this.responseManager = responseManager;
          this.cargarMensajesServicioTurno(this.responseManager);
        } else {
          this.responseManager = errorResult as ResponseManager;
          this.cargarMensajesServicioTurno(this.responseManager);
        }
      }
    );
  }

  cargarMensajesServicioTurno(responseManager: ResponseManager) {
    if (responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO ||
        responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                   "Mensajes de Error: ",
                                                                    "",
                                                                    FuncionesGenerales.getInstance().mostrarTablaDeErrores(this.responseManager.errors));
    }
  }

  validarDatosTurnos() {
    let errorMensaje: string = "";
    let tituloErrores: string = "Mensajes de Error: ";
    let esValido: boolean = false;
    let regExpNombre = "^[áéíóúÁÉÍÓÚñÑa-zA-Z0-9".concat("\\").concat("s,()-._").concat("\\/").concat("]{2,60}$");
    this.objTurno.hraCorte = this.objTurno.hraCorte == " " ? "" : this.objTurno.hraCorte;
    if (this.objTurno.nombre.length == 0) {
      errorMensaje = "Debe ingresar el nombre del Turno.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (!FuncionesGenerales.getInstance().validarExpresionesRegulares(this.objTurno.nombre, regExpNombre)) {
      errorMensaje = "Ingrese al menos 2 caracteres del nombre del turno.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (!FuncionesGenerales.getInstance().esFechaValida(
          FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objTurno.fecInicioVigencia),
          ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO)) {
      errorMensaje = "La fecha de inicio de vigencia es incorrecta.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (!FuncionesGenerales.getInstance().esFechaValida(
          FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objTurno.fecFinVigencia),
          ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO)) {
      errorMensaje = "Fecha de término de vigencia es incorrecta.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (!this.esFecIniVigencia) {
      if (FuncionesGenerales.getInstance().compararFechas(
        FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objTurno.fecInicioVigencia),
                                                           ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
        FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(new Date()),
                                                           ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 0) {
        if (FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objTurno.fecInicioVigencia) !=
            FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(new Date())) {
              errorMensaje = "Fecha de inicio de vigencia no puede ser menor que la fecha actual.";
              FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                          tituloErrores, errorMensaje, "");
              return false;
            }
      }
    }

    if (FuncionesGenerales.getInstance().compararFechas(
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objTurno.fecInicioVigencia),
                                                         ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objTurno.fecFinVigencia),
                                                         ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 1) {
      errorMensaje = "Fecha de inicio de vigencia no puede ser mayor que la fecha de término de vigencia.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (!FuncionesGenerales.getInstance().validarExpresionesRegulares(this.objTurno.hraInicio, ConstantesCadenas.EXPRESION_REGULAR_HORA_MINUTO) && this.objTurno.hraInicio.length != 0) { //cchavezt ATENCION BUGS
      errorMensaje = "Hora desde es incorrecta.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (this.objTurno.hraInicio.length == 0) {
      errorMensaje = "Ingrese la Hora Desde.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (!FuncionesGenerales.getInstance().validarExpresionesRegulares(this.objTurno.hraFin, ConstantesCadenas.EXPRESION_REGULAR_HORA_MINUTO) && this.objTurno.hraFin.length != 0) { //cchavezt ATENCION BUGS
      errorMensaje = "Hora hasta es incorrecta.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (this.objTurno.hraFin.length == 0) {
      errorMensaje = "Ingrese la Hora Hasta.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (this.objTurno.hraCorte.length > 0) {
      if (!FuncionesGenerales.getInstance().validarExpresionesRegulares(this.objTurno.hraCorte, ConstantesCadenas.EXPRESION_REGULAR_HORA_MINUTO) && this.objTurno.hraCorte.length != 0) { //cchavezt ATENCION BUGS
        errorMensaje = "Hora de corte de asignación es incorrecta.";
        //errorMensaje = "Ingrese la Hora de corte de asignación.";
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    tituloErrores, errorMensaje, "");
        return false;
      }
    }

    /*if (this.objTurno.hraCorte.length == 0) {
      errorMensaje = "Ingrese la Hora de corte de asignación.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }*/
    let flagHoraCorte = this.objTurno.hraCorte.length > 0 ? true : false;
    let horaDesde = moment(this.objTurno.hraInicio.concat(":00"), "HH:mm:ss");
    let horaHasta = moment(this.objTurno.hraFin.concat(":00"), "HH:mm:ss");
    let horaCorte;
    if (flagHoraCorte) {
      horaCorte = moment(this.objTurno.hraCorte.concat(":00"), "HH:mm:ss");
    }

    let fechaDesde: Date;
    let fechaHasta: Date;
    let fechaCorte: Date;
    fechaDesde = new Date();
    fechaDesde.setHours(parseInt(this.objTurno.hraInicio.split(':')[0]));
    fechaDesde.setMinutes(parseInt(this.objTurno.hraInicio.split(':')[1]));
    fechaDesde.setSeconds(0);

    fechaHasta = new Date();
    //fechaHasta = moment(fechaHasta).add("day", 1).toDate();
    fechaHasta.setHours(parseInt(this.objTurno.hraFin.split(':')[0]));
    fechaHasta.setMinutes(parseInt(this.objTurno.hraFin.split(':')[1]));
    fechaHasta.setSeconds(0);

    if (fechaDesde > fechaHasta) {
      fechaHasta = moment(fechaHasta).add("day", 1).toDate();
      fechaHasta.setHours(parseInt(this.objTurno.hraFin.split(':')[0]));
      fechaHasta.setMinutes(parseInt(this.objTurno.hraFin.split(':')[1]));
      fechaHasta.setSeconds(0);
    }
    if (flagHoraCorte) {
      fechaCorte = new Date();
      fechaCorte.setHours(parseInt(this.objTurno.hraCorte.split(':')[0]));
      fechaCorte.setMinutes(parseInt(this.objTurno.hraCorte.split(':')[1]));
      fechaCorte.setSeconds(0);
    }

    let momentFechaDesde = moment(
          FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioHoraMinutoSegundoComoCadena(fechaDesde),
          ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO_HORA_MINUTO_SEGUNDO
    ).toDate();
    let momentFechaHasta = moment(
          FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioHoraMinutoSegundoComoCadena(fechaHasta),
          ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO_HORA_MINUTO_SEGUNDO
    ).toDate();

    let horaDesdeMayorHasta: boolean = momentFechaDesde < momentFechaHasta ? true : false;
    let resultado: any;
    let resultadoHoraCorteDesde: any;
    let resultadoHoraCorteHasta: any;
    let resultadoMinutos: number;
    let resultadoMinutosHoraCorteDesde: number;
    let resultadoMinutosHoraCorteHasta: number;
    if (horaDesdeMayorHasta) {
      if (flagHoraCorte) {
        resultado = moment.duration(horaCorte.diff(horaDesde));
        resultadoHoraCorteDesde = parseInt(resultado.asMinutes());
        //si la hora de corte es mayorque la hora Desde
          //considerar la fecha de la hora de corte igual a la fecha Desde
        //caso contrario
          //considerar la fecha de corte igual a la fecha hasta
          // && moment(fechaDesde).diff(fechaHasta, 'days')>0
        if (resultadoHoraCorteDesde < 0) { //cchavezt ATENCION BUGS
          fechaCorte = moment(fechaCorte).add("day", 1).toDate();
        }
      }

      resultadoMinutos = FuncionesGenerales.getInstance().diferenciaEntreFechas(
                         FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioHoraMinutoSegundoComoCadena(fechaDesde),
                         FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioHoraMinutoSegundoComoCadena(fechaHasta),
                         ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO_HORA_MINUTO_SEGUNDO,
                         ConstantesCadenas.FORMATO_UNIDAD_TIEMPO_MINUTOS);

      if (Math.abs(resultadoMinutos) < 60) {
         errorMensaje = "Hora desde y hora hasta deben de tener una diferencia de al menos 60 minutos.";
         FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                     tituloErrores, errorMensaje, "");
         return false;
      }


      if (flagHoraCorte) {
        if (!(fechaCorte >= fechaDesde && fechaCorte <= fechaHasta)) {
          errorMensaje = "Hora de corte de asignación debe estar en el intervalo de la Hora Desde y la Hora Hasta.";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                       tituloErrores, errorMensaje, "");
          return false;
        }
        /*if (!(fechaCorte >= fechaDesde)) { //cchavezt ATENCION BUGS
          errorMensaje = "Hora de corte de asignación debe ser mayor o igual a la Hora Desde.";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                      tituloErrores, errorMensaje, "");
          return false;
        }

        if (!(fechaCorte <= fechaHasta)) { //cchavezt ATENCION BUGS
          errorMensaje = "Hora de corte de asignación debe ser menor o igual a la Hora Hasta.";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                      tituloErrores, errorMensaje, "");
          return false;
        }*/
      }

    } else {

      resultado = moment.duration(horaHasta.diff(horaDesde));

      if (flagHoraCorte) {
        resultadoHoraCorteDesde = moment.duration(horaCorte.diff(horaDesde));
        resultadoHoraCorteHasta = moment.duration(horaHasta.diff(horaCorte));
        resultadoMinutosHoraCorteDesde = parseInt(resultadoHoraCorteDesde.asMinutes());
        resultadoMinutosHoraCorteHasta = parseInt(resultadoHoraCorteHasta.asMinutes());
      }
      resultadoMinutos = parseInt(resultado.asMinutes());

      if (Math.abs(resultadoMinutos) < 60) {
        errorMensaje = "Hora desde y hora hasta deben de tener una diferencia de al menos 60 minutos.";
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    tituloErrores, errorMensaje, "");
        return false;
      }

      if (flagHoraCorte) {
        if (!(fechaCorte >= fechaDesde && fechaCorte <= fechaHasta)) {
          errorMensaje = "Hora de corte de asignación debe estar en el intervalo de la Hora Desde y la Hora Hasta.";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                       tituloErrores, errorMensaje, "");
          return false;
        }
        /*if (resultadoMinutosHoraCorteDesde < 0) {
          errorMensaje = "Hora de corte de asignación debe ser mayor o igual a la Hora Desde.";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                      tituloErrores, errorMensaje, "");
          return false;
        }

        if (resultadoMinutosHoraCorteHasta <= 0) {
          errorMensaje = "Hora de corte de asignación debe ser menor o igual a la Hora Hasta.";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                      tituloErrores, errorMensaje, "");
          return false;
        }*/
      }
    }

    esValido = true;
    return esValido;
  }

  getEstadoOperacion$(): Observable<String> {
    return this.estadoOperacion$.asObservable();
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.zonasDS.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.zonasDS.data.forEach(row => this.selection.select(row));
  }

  cambiarHoraDesde(objSeleccionado: any) {
    let errorMensaje: string = "La hora desde ingresada debe ser múltiplo de 15";//cchavezt ATENCION BUGS
    objSeleccionado.currentTarget.value = this.obtenerHorarioCorrecto(objSeleccionado.currentTarget.value, errorMensaje);
    this.objTurno.hraInicio = objSeleccionado.currentTarget.value;
  }

  cambiarHoraHasta(objSeleccionado: any) {
    let errorMensaje: string = "La hora hasta ingresada debe ser múltiplo de 15";//cchavezt ATENCION BUGS
    objSeleccionado.currentTarget.value = this.obtenerHorarioCorrecto(objSeleccionado.currentTarget.value, errorMensaje);
    this.objTurno.hraFin = objSeleccionado.currentTarget.value;
  }

  cambiarHoraCorte(objSeleccionado: any) {
    let errorMensaje: string = "La hora corte de asignación ingresada debe ser múltiplo de 15";//cchavezt ATENCION BUGS
    objSeleccionado.currentTarget.value = this.obtenerHorarioCorrecto(objSeleccionado.currentTarget.value, errorMensaje);
    this.objTurno.hraCorte = objSeleccionado.currentTarget.value;
  }

  obtenerHorarioCorrecto(horario: string, errorMensaje: string){//cchavezt ATENCION BUGS
    let tituloErrores: string = "Mensajes de Error: ";
    let errorMensajeMostrar;
    let hora;
    let minuto;
    let tieneError: boolean = false;
    if(horario == undefined){
      errorMensaje = "El horario ingresado no es válido";
      let fechaActual = new Date();
      hora = ("00" + fechaActual.getHours()).slice(-2);
      minuto = "00";
      tieneError = true;
    }else{
      hora = horario.substring(0,2);
      minuto = horario.substring(3,5);
      if("00,15,30,45".indexOf(minuto) < 0){
        errorMensajeMostrar = errorMensaje;
        tieneError = true;
        if(+minuto > 0 && +minuto < 15){
          minuto = "00";
        }else if(+minuto > 15 && +minuto < 30){
          minuto = "15";
        }else if(+minuto > 30 && +minuto < 45){
          minuto = "30";
        }else if(+minuto > 45 && +minuto < 60){
          minuto = "45";
        }
      }
    }
    if(tieneError)
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR, tituloErrores, errorMensajeMostrar, "");
    return hora + ":" + minuto;
  }

  validarFechaInicioVigencia() {
    let fechaActual: Date = new Date();
    let fecInicioVigencia: Date = FuncionesGenerales.getInstance().clonarObjeto(this.objTurno.fecInicioVigencia);
    fechaActual.setHours(0);
    fechaActual.setMinutes(0);
    fechaActual.setSeconds(0);

    fecInicioVigencia.setHours(0);
    fecInicioVigencia.setMinutes(0);
    fecInicioVigencia.setSeconds(0);

    if (fecInicioVigencia < fechaActual) {
      this.esFecIniVigencia = true;
    }
    if (fechaActual > fecInicioVigencia) {
      this.desabilitarHoraCorteFechaDesde = false;
    }
  }
}
