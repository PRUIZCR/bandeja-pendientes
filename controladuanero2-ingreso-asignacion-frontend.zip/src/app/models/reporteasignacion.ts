import { ReporteHorario } from './reportehorario';

export enum TipoPaquete {
  TIPO_PAQUETE_REGIMEN = 1,
  TIPO_PAQUETE_RFU = 1
}

export class ReporteAsignacion {
  codAduana: string;
  codAnfora: string;
  fechaDesde: Date;
  strFechaDesde: string;
  fechaHasta: Date;
  strFechaHasta: string;
  rucAlmacen: string;
  codFuncionario: string;
  numTurno: number;
  numHorario: number;
  numSorteo: number;
  numZona: number;
  nomZona: string;
  codLocal: string;
  listaReporteHorarios: ReporteHorario[];
  tipoPaquete: TipoPaquete

  cosntructor() { }
}
