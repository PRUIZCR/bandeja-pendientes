import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListaPaqueteRFUComponent } from './lista-paquete-rfu.component';

describe('ListaPaqueteRFUComponent', () => {
  let component: ListaPaqueteRFUComponent;
  let fixture: ComponentFixture<ListaPaqueteRFUComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListaPaqueteRFUComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListaPaqueteRFUComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
