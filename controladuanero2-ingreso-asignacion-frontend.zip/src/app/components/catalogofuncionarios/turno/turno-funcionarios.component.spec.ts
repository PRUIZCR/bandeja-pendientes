import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TurnoFuncionariosComponent } from './turno-funcionarios.component';

describe('TurnoFuncionariosComponent', () => {
  let component: TurnoFuncionariosComponent;
  let fixture: ComponentFixture<TurnoFuncionariosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TurnoFuncionariosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TurnoFuncionariosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
