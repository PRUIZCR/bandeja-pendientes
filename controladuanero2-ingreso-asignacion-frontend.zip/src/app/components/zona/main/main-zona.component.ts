import { Observable } from 'rxjs/Observable';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Unidaddespacho } from 'src/app/models/unidaddespacho';
import { Zona } from 'src/app/models/zona';
import { Datacatalogo } from 'src/app/models/datacatalogo';
import { ConstantesListas } from 'src/app/utils/constanteslistas';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { MatTableDataSource } from '@angular/material';
import { MatSort  } from '@angular/material/sort';
import { MatPaginator  } from '@angular/material/paginator';
import { setTheme } from 'ngx-bootstrap/utils';
import { MantenimientoZonaComponent } from 'src/app/components/zona/mantenimiento/mantenimiento-zona.component';
import { CatalogoService } from 'src/app/services/catalogo.service';
import { UnidaddespachoService } from 'src/app/services/unidaddespacho.service';
import { ZonaService } from 'src/app/services/zona.service';

@Component({
  selector: 'app-main-zona',
  templateUrl: './main-zona.component.html',
  styleUrls: ['./main-zona.component.css']
})
export class MainZonaComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MantenimientoZonaComponent) child: MantenimientoZonaComponent;
  aduanaSeleccionada: string;
  estadoSeleccionado: string;
  unidadDespachoSeleccionado: string;
  desabilitarBotonZona: boolean = false;
  aduanas: Datacatalogo[];
  estados: Datacatalogo[];
  lstUnidadDespacho: Unidaddespacho[];
  objUnidadDespachoSeleccionado: Unidaddespacho;
  objAduanaSeleccionada: Datacatalogo;
  zonas: Zona;
  lstZonas: Zona[];
  zonasDS: MatTableDataSource<Zona>;
  funcionesGenerales: FuncionesGenerales;
  displayedColumns: string[];
  estadoOperacion$: Observable<String>;
  esSoloConsulta: boolean;

  constructor(private catalogoService: CatalogoService,
              private unidadDespachoService: UnidaddespachoService,
              private zonaService: ZonaService) {
    setTheme('bs4');
  }

  ngOnInit() {
    this.esSoloConsulta = sessionStorage.getItem('esJefeSupervisor') == '0';
    this.catalogoService.listarAduanas().subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.aduanaSeleccionada = result.aduana;
      this.aduanas = result.listaAduanas as Datacatalogo[];
      if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.aduanas)) {
        this.cargarControles();
      }
    }, error => console.error(error));

    this.displayedColumns = ConstantesListas.COLUMNAS_GRID_ZONA;
    this.lstZonas = [];
    this.zonasDS = new MatTableDataSource<Zona>(this.lstZonas);
    this.funcionesGenerales = FuncionesGenerales.getInstance();
    this.estadoOperacion$ = this.child.getEstadoOperacion$();
    this.estadoOperacion$.subscribe(estado => estado == "X" ? this.cargarZonas() : "");
    this.zonas = new Zona();
    this.zonas.numZona = 0;
  }

  seleccionarAduana(objSeleccionado) {
    this.aduanaSeleccionada = objSeleccionado.target.value;
    if (objSeleccionado.target.value != "") {
      this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == objSeleccionado.target.value);
    }
    this.cargarUnidadesDespacho();
  }

  seleccionarEstado(objSeleccionado) {
    this.estadoSeleccionado = objSeleccionado.target.value;
    if (this.unidadDespachoSeleccionado != "" &&
        this.unidadDespachoSeleccionado != null &&
        this.unidadDespachoSeleccionado != undefined) {
      this.cargarZonas();
    }
  }

  cargarControles() {
    this.estados = ConstantesListas.LISTA_ESTADOS;
    this.lstUnidadDespacho = [];
    this.unidadDespachoSeleccionado = "";
    this.estadoSeleccionado = ConstantesCadenas.ESTADO_TODOS;
    //this.aduanaSeleccionada = this.aduanas[0].cod_datacat;
    this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == this.aduanaSeleccionada);
    this.cargarUnidadesDespacho();
  }

  cargarUnidadesDespacho() {
    let campos: string = "numUnidadDespacho,nombre";
    this.unidadDespachoService.listarUnidadesDespacho(this.aduanaSeleccionada,
                                                      ConstantesCadenas.ESTADO_VIGENTE,
                                                      campos).subscribe(result => {
     FuncionesGenerales.getInstance().cerrarModalCargando();
     this.lstUnidadDespacho = result as Unidaddespacho[];
     //if (this.aduanaSeleccionada != "" && this.lstUnidadDespacho != null && this.lstUnidadDespacho != undefined) {
     if(this.aduanaSeleccionada != "" && FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstUnidadDespacho)) {
       this.lstUnidadDespacho = this.lstUnidadDespacho.sort(FuncionesGenerales.getInstance().ordenarPor("numUnidadDespacho", false));
       this.unidadDespachoSeleccionado = this.lstUnidadDespacho[0].numUnidadDespacho.toString();
       this.objUnidadDespachoSeleccionado = this.lstUnidadDespacho.find(element => element.numUnidadDespacho == parseInt(this.unidadDespachoSeleccionado));
       this.objUnidadDespachoSeleccionado.aduana = this.objAduanaSeleccionada;
       this.cargarZonas();
       this.desabilitarBotonZona = true;
     } else {
       this.unidadDespachoSeleccionado = "";
       this.lstUnidadDespacho = [];
       this.lstZonas = [];
       this.zonasDS = new MatTableDataSource<Zona>(this.lstZonas);
       let tituloErrores: string = "Mensaje de Error: ";
       let errorMensaje: string = "No existen unidades de despacho asignadas a la Aduana " + this.objAduanaSeleccionada.des_corta;
       FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                     tituloErrores, errorMensaje, "");
     }
    }, error => console.error(error));
  }

  seleccionarUnidadDespacho(objSeleccionado) {
    this.unidadDespachoSeleccionado = objSeleccionado.target.value;
    if (objSeleccionado.target.value != "") {
      this.objUnidadDespachoSeleccionado = this.lstUnidadDespacho.find(element => element.numUnidadDespacho == objSeleccionado.target.value);
      this.zonas = new Zona();
      this.zonas.numZona = -1;
      this.zonas.unidadDespacho = this.objUnidadDespachoSeleccionado;
      this.zonas.unidadDespacho.aduana = this.objAduanaSeleccionada;
      this.desabilitarBotonZona = true;
    } else {
      this.desabilitarBotonZona = false;
    }
    this.cargarZonas();
  }

  cargarZonas() {
    let campos: string = "numZona,nombre,descripcion,indSusceptible,fecInicioVigencia,fecFinVigencia";
    this.zonaService.listarZonas(this.unidadDespachoSeleccionado,
                                 this.estadoSeleccionado,
                                 campos).subscribe(result => {
     FuncionesGenerales.getInstance().cerrarModalCargando();
     this.lstZonas = result as Zona[];
     //if (this.unidadDespachoSeleccionado != "" && this.lstZonas != null && this.lstZonas != undefined) {
     if (this.unidadDespachoSeleccionado != "" && FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstZonas)) {
       this.lstZonas = this.lstZonas.sort(FuncionesGenerales.getInstance().ordenarPor("numZona", false));
     } else {
       this.lstZonas = [];
       FuncionesGenerales.getInstance().mensajeRegistrosNoEncontrados();
     }
     this.zonasDS = new MatTableDataSource<Zona>(this.lstZonas);
     this.zonasDS.sort = this.sort;
     this.zonasDS.paginator = this.paginator;
    }, error => console.error(error));
  }

  mostrarZonasEditable(fecInicioVigencia: Date, fecFinVigencia: Date) {
    let esEditable: boolean = false;
    this.objUnidadDespachoSeleccionado = this.lstUnidadDespacho.find(
      element => element.numUnidadDespacho == parseInt(this.unidadDespachoSeleccionado)
    );
    /*if (FuncionesGenerales.getInstance().compararFechas(
      FuncionesGenerales.getInstance().formatearFecha(fecInicioVigencia),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
      FuncionesGenerales.getInstance().formatearFecha(fecFinVigencia),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 0) {
        esEditable = true;
    }*/
    if (FuncionesGenerales.getInstance().compararFechas(
      FuncionesGenerales.getInstance().formatearFecha(new Date()),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
      FuncionesGenerales.getInstance().formatearFecha(fecFinVigencia),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 0) {
        esEditable = true;
    }
    return esEditable;
  }
}
