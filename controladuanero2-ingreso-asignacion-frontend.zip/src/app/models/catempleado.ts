import { Datacatalogo } from "./datacatalogo";
import { TipFun } from "./tipfun";
import { TipCargoFun } from "./tipcargofun";

export class CatEmpleado {
  codPers: string;
  apPate: string;
  apMate: string;
  nombres: string;
  aduana: Datacatalogo;
  tipFun: TipFun;
  tipCargoFun: TipCargoFun
  codUniOrg: string;
  codUniOrgDestaque: string;
  seleccion: boolean;

  constructor() { }
}
