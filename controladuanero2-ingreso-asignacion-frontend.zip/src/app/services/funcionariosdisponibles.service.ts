import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { FuncionesGenerales } from '../utils/funcionesgenerales';
import { ConstantesRest } from '../utils/constantesrest';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { FuncionarioDisponible } from '../models/funcionariodisponible';

@Injectable({
  providedIn: 'root'
})
export class FuncionariosdisponiblesService {

  constructor(private http: HttpClient) { }

  listarFuncionariosDisponibles(turno: number,
    fechaAsignacion: Date,aduana: String): Observable<any> {
    return this.http.get<HttpResponse<Object>>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_LISTA_FUNCIONARIO_DISPONIBLES,
      turno,
      fechaAsignacion,
      aduana,
      "",
      { observe: 'response' })).pipe(
        catchError(e => {
          return throwError(e.error);
        })
      );
  }

  listarFuncionariosDisponiblesRFU(fechaAsignacion: Date, aduana: String): Observable<any> {
    return this.http.get<HttpResponse<Object>>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_LISTA_FUNCIONARIO_DISPONIBLES_RFU,
      fechaAsignacion,
	  aduana,
      "",
      { observe: 'response' })).pipe(
        catchError(e => {
          return throwError(e.error);
        })
      );
  }

  registrarReasignarPaquete(numPaquete: number, objFuncionariodisponible: FuncionarioDisponible): Observable<any> {
    return this.http.put<HttpResponse<Object>>(
      FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_GRABAR_REASIGNACION_PAQUETES_BLOQUE, numPaquete),
      objFuncionariodisponible, { observe: 'response' }).pipe(
        catchError(e => {
          return throwError(e.error);
        })
      );
  }

  registrarReasignarPaqueteRFU(numPaquete: number, objFuncionariodisponible: FuncionarioDisponible): Observable<any> {
    return this.http.put<HttpResponse<Object>>(
      FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_GRABAR_REASIGNACION_PAQUETES_BLOQUE_RFU, numPaquete),
      objFuncionariodisponible, { observe: 'response' }).pipe(
        catchError(e => {
          return throwError(e.error);
        })
      );
  }
}
