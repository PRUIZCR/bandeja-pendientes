import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { ConstantesRest } from '../utils/constantesrest';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReportePaquetesService {

  constructor(private http: HttpClient) { }

  reporteAsignacionPaquetes(tipoReporte: string,
                            codAnfora: string,
                            numTurno: number,
                            numHorario: number,
                            rucAlmacen: string,
                            codLocalAnexo: string,
                            codFuncionario: string,
                            fechaDesde: Date,
                            fechaHasta: Date,
                            numSorteo: number,
                            numZona: number) {
    return this.http.get<any>(FuncionesGenerales.getInstance().reemplazarParametros(
          ConstantesRest.URL_EXPORTAR_REPORTE_ASIGNACION_PAQUETES,
          tipoReporte,
          codAnfora,
          numTurno,
          numHorario,
          rucAlmacen,
          codLocalAnexo,
          codFuncionario,
          fechaDesde,
          fechaHasta,
          numSorteo,
          numZona
          )).pipe(
          catchError(e => {
            return throwError(e);
          }));
  }

  reporteAsignacionPaquetesRfu(
    codAduana: string,
    tipoReporte: string,
    rucAlmacen: string,
    codLocalAnexo: string,
    codFuncionario: string,
    fechaDesde: Date,
    fechaHasta: Date) {
      return this.http.get<any>(FuncionesGenerales.getInstance().reemplazarParametros(
        ConstantesRest.URL_EXPORTAR_REPORTE_ASIGNACION_PAQUETES_RFU,
        codAduana,
        tipoReporte,
        rucAlmacen,
        codLocalAnexo,
        codFuncionario,
        fechaDesde,
        fechaHasta
      )).pipe(catchError(e => {
        return throwError(e);
     }));
  }

  reportePaquetes(tipoReporte: string,
                  codAnfora: string,
                  numHorario: number,
                  numSorteo: number,
                  fecha: Date) {
    return this.http.get<any>(FuncionesGenerales.getInstance().reemplazarParametros(
          ConstantesRest.URL_EXPORTAR_REPORTE_PAQUETES,
          tipoReporte,
          codAnfora,
          numHorario,
          numSorteo,
          fecha)).pipe(
          catchError(e => {
            return throwError(e);
          }));
  }

  reportePaquetesRFU(tipoReporte: string,
          codAduana: string,
          fecha: Date,
          numSecHorario: number) {
      return this.http.get<any>(FuncionesGenerales.getInstance().reemplazarParametros(
      ConstantesRest.URL_EXPORTAR_REPORTE_PAQUETES_RFU,
      tipoReporte,
      codAduana,
      fecha,
      numSecHorario)).pipe(
      catchError(e => {
      return throwError(e);
      }));
  }
}
