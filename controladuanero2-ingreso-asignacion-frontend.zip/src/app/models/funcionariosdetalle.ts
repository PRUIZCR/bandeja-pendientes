import { Turno } from "./turno";
import { FuncionarioDisponible } from './funcionariodisponible';

export class FuncionariosDetalle {
  cantidad: number;
  funcionarios: FuncionarioDisponible[];
  start: string;
  title: string;
  turno: Turno;
  funcionariosTotales: FuncionarioDisponible[];
  esDeBD: boolean = true;
  funcionario: FuncionariosDetalle;

  constructor() { }
}
