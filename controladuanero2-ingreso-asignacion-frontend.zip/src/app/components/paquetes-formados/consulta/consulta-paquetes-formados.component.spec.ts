import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsultaPaquetesFormadosComponent } from './consulta-paquetes-formados.component';

describe('ConsultaPaquetesFormadosComponent', () => {
  let component: ConsultaPaquetesFormadosComponent;
  let fixture: ComponentFixture<ConsultaPaquetesFormadosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsultaPaquetesFormadosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsultaPaquetesFormadosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
