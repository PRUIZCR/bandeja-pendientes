import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FuncionariosZonaDetalle } from 'src/app/models/funcionarioszonadetalle';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { ConstantesExcepciones } from 'src/app/utils/constantesExcepciones';
import { ConstantesListas } from 'src/app/utils/constanteslistas';
import { ResponseManager } from 'src/app/models/responsemanager';
import { ResponseErrorManager } from 'src/app/models/responseerrormanager';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { AsignaFuncionarioZona } from 'src/app/models/asignafuncionariozona';
import { FuncionarioDisponible } from 'src/app/models/funcionariodisponible';
import { DetalleAsignafuncionarioZona } from 'src/app/models/detalleasignafuncionariozona';
import { FuncionariosAsignados } from 'src/app/models/funcionariosasignados';
import { CatEmpleado } from 'src/app/models/catempleado';
import { Zona } from 'src/app/models/zona';
import { AsignaFuncionarioZonaService } from 'src/app/services/asignafuncionariozona.service';
import { MatTableDataSource } from '@angular/material';
import { MatSort  } from '@angular/material/sort';
import { MatPaginator  } from '@angular/material/paginator';

@Component({
  selector: 'app-asignacion-funcionario-zona',
  templateUrl: './asignacion-funcionario-zona.component.html',
  styleUrls: ['./asignacion-funcionario-zona.component.css']
})
export class AsignacionFuncionarioZonaComponent implements OnInit {
  @ViewChild('childModal') childModal: ModalDirective;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('urzonas', {read: MatPaginator}) uploadResultPaginator: MatPaginator;
  @ViewChild(MatSort) sortZD: MatSort;
  displayedColumnsFD: string[];
  displayedColumnsZD: string[];
  displayedColumns: string[];
  funcionarioZonaDetalle: FuncionariosZonaDetalle;
  aduanaSeleccionada: string;
  unidadDespachoSeleccionado: string;
  tituloAsignacionFuncionarioZona: string;
  nombreTurno: string;
  anfora: string;
  fecha: string;
  indTipoAsignacion: string;
  asignaFuncionarioZona: AsignaFuncionarioZona;
  enviarAsignaFuncionarioZona: AsignaFuncionarioZona;
  responseManager: ResponseManager;
  responseErrorManager: ResponseErrorManager;
  lstFuncionariosDisponibles: FuncionarioDisponible[];
  lstZonas: DetalleAsignafuncionarioZona[];
  funcionarioDisponibleDS : MatTableDataSource<FuncionarioDisponible>;
  zonaDS: MatTableDataSource<DetalleAsignafuncionarioZona>;
  desabilitarBotonFAZ: boolean;
  mostrarFuncAsignados: boolean = true;
  desabilitarBotonFAZM: boolean = false;
  desabilitarComboFAZ: boolean = true;
  desabilitarComboFAZ2: boolean = true;
  botonesDesabilitados: boolean = false;
  funcionariosAsignados: FuncionariosAsignados[];
  DATA: FuncionariosAsignados[];
  funcionarioAsignadosDS: MatTableDataSource<FuncionariosAsignados>;
  funcionesGenerales: FuncionesGenerales;
  spans = [];
  private estadoOperacionAsignacion$ = new Subject<String>();

  constructor(private asignaFuncionarioZonaService: AsignaFuncionarioZonaService) { }

  ngOnInit() {
    this.displayedColumnsFD = ConstantesListas.COLUMNAS_GRID_ASIGNACION_FUNCIONARIO_DISPONIBLE;
    this.displayedColumnsZD = ConstantesListas.COLUMNAS_GRID_ASIGNACION_ZONA_DISPONIBLE;
    this.funcionesGenerales = FuncionesGenerales.getInstance();
  }

  cargarAsignacionDeFuncionarioAZona(aduanaSeleccionada: string,
                                     unidadDespachoSeleccionado: string,
                                     funcionarioZonaDetalle: FuncionariosZonaDetalle,
                                     fechaEvento: Date) {
    let fechaActual: Date = new Date();
    let errorMensaje: string = "";
    let tituloErrores: string = "Mensaje de Error: ";
    this.funcionarioZonaDetalle = FuncionesGenerales.getInstance().clonarObjeto(funcionarioZonaDetalle);
    this.aduanaSeleccionada = aduanaSeleccionada;
    this.unidadDespachoSeleccionado = unidadDespachoSeleccionado;
    this.nombreTurno = this.funcionarioZonaDetalle.nombreTurno;
    this.fecha = FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(fechaEvento);
    this.tituloAsignacionFuncionarioZona = ConstantesCadenas.TITULO_ASIGNACION_FUNCIONARIO_A_ZONA;
    this.anfora = this.funcionarioZonaDetalle.anfora;
    this.indTipoAsignacion = "0";
    this.botonesDesabilitados = false;
    if (fechaEvento.setHours(0,0,0,0) < fechaActual.setHours(0,0,0,0)) {
      this.botonesDesabilitados = true;
      errorMensaje = "La fecha actual es porterior a la fecha de ejecución del sorteo";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
    } else {
      this.mostrarFuncAsignados = true;
      this.desabilitarBotonFAZ = true;
      this.desabilitarBotonFAZM = true;
    }
    this.obtenerAsignacionFuncionariosAZonas(this.funcionarioZonaDetalle.numAsigFuncZona);
    this.DATA = [];
    this.spans = [];
    this.funcionarioAsignadosDS = new MatTableDataSource<FuncionariosAsignados>(this.DATA);
    this.childModal.show();
  }

  obtenerAsignacionFuncionariosAZonas(numAsigFuncZona: number) {
    this.asignaFuncionarioZonaService.obtenerAsignacionFuncionariosAZonas(numAsigFuncZona).subscribe(
      response => {
        FuncionesGenerales.getInstance().cerrarModalCargando();
        this.asignaFuncionarioZona = response as AsignaFuncionarioZona;
        this.desabilitarBotonFAZ = this.asignaFuncionarioZona.funcionariosDisponibles.length > 0 ? true : false;
        this.mostrarFuncionariosDiponibles(this.asignaFuncionarioZona.funcionariosDisponibles);
        this.mostrarZonasDisponibles(this.asignaFuncionarioZona.zonasDisponibles);
        if (!this.desabilitarBotonFAZ) {
          let responseManager: ResponseManager = new ResponseManager();
          let responseErrorManager: ResponseErrorManager = new ResponseErrorManager();
          responseManager.cod = ConstantesCadenas.CODIGO_NO_ENCONTRADO;
          responseErrorManager.cod = ConstantesCadenas.CODIGO_NO_ENCONTRADO;
          responseErrorManager.msg = ConstantesExcepciones.EXCEPCION_FUNCIONARIOS_NO_ENCONTRADOS;
          responseManager.errors = [responseErrorManager];
          this.responseManager = responseManager;
          this.cargarMensajesAsignacionFuncionariosZona(responseManager);
        }
        if (this.botonesDesabilitados) this.desabilitarBotonFAZ = false;
      },
      errorResult => {
        if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
          let responseManager: ResponseManager = new ResponseManager();
          this.responseErrorManager = errorResult as ResponseErrorManager;
          responseManager.cod = errorResult.cod;
          responseManager.errors = [this.responseErrorManager];
          this.responseManager = responseManager;
          this.cargarMensajesAsignacionFuncionariosZona(this.responseManager);
        } else {
          this.responseManager = errorResult as ResponseManager;
          this.cargarMensajesAsignacionFuncionariosZona(this.responseManager);
        }
      }
    );
  }

  cargarMensajesAsignacionFuncionariosZona(responseManager: ResponseManager) {
    if (responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO ||
        responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR ||
        responseManager.cod == "999") {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                   "Mensajes de Error: ",
                                                                    "",
                                                                    FuncionesGenerales.getInstance().mostrarTablaDeErrores(this.responseManager.errors));
    }
  }

  mostrarFuncionariosDiponibles(funcionariosDisponibles: FuncionarioDisponible[]) {
    this.displayedColumnsFD = ConstantesListas.COLUMNAS_GRID_ASIGNACION_FUNCIONARIO_DISPONIBLE;
    this.lstFuncionariosDisponibles = funcionariosDisponibles;
    this.funcionarioDisponibleDS = new MatTableDataSource<FuncionarioDisponible>(this.lstFuncionariosDisponibles);
    this.funcionarioDisponibleDS.sort = this.sort;
    this.funcionarioDisponibleDS.paginator = this.paginator;
  }

  mostrarZonasDisponibles(zonasDisponibles: Zona[]) {
    this.displayedColumnsZD = ConstantesListas.COLUMNAS_GRID_ASIGNACION_ZONA_DISPONIBLE;
    this.lstZonas = [];
    this.lstZonas = this.cargarListaZonas(zonasDisponibles);
    this.zonaDS = new MatTableDataSource<DetalleAsignafuncionarioZona>(this.lstZonas);
    this.zonaDS.sort = this.sortZD;
    this.zonaDS.paginator = this.uploadResultPaginator;
  }

  cargarListaZonas(zonasDisponibles: Zona[]) {
    let lstZonas: DetalleAsignafuncionarioZona[] = [];
    for (let i = 0; i < zonasDisponibles.length; i++) {
      let detalle: DetalleAsignafuncionarioZona = new DetalleAsignafuncionarioZona();
      detalle.zona = zonasDisponibles[i];
      detalle.cantidadFuncionarios = 0;
      lstZonas.push(detalle);
    }
    return lstZonas;
  }

  cerrarAsignacionDeFuncionarioAZona() {
    this.childModal.hide();
  }

  obtenerFuncionariosManualmente(cantidadFuncionarios: number) {
    let arrayFuncionarios: string[] = [];
    for (let i = 0; i < cantidadFuncionarios; i++) {
      arrayFuncionarios.push("-1");
    }
    return arrayFuncionarios;
  }

  callbackAsignar = () : void => {
    this.mostrarFuncAsignados = false;
    this.desabilitarBotonFAZ = false;
    this.cargarFuncionariosDisponiblesListaAgrupada(this.enviarAsignaFuncionarioZona.detallesAsignacion);
    this.estadoOperacionAsignacion$.next("Y");
  };

  asignarFuncionariosAZona() {
    if (this.indTipoAsignacion == ConstantesCadenas.TIPO_ASIGNACION_MANUAL) {
      this.funcionariosAsignados = [];
      for (let i = 0; i < this.lstZonas.length; i++) {
        let funcionarioAsignado: FuncionariosAsignados = new FuncionariosAsignados();
        funcionarioAsignado.zona = this.lstZonas[i].zona.nombre.trim();
        funcionarioAsignado.cantidad = this.lstZonas[i].cantidadFuncionarios;
        funcionarioAsignado.funcionarios = this.obtenerFuncionariosManualmente(this.lstZonas[i].cantidadFuncionarios);
        this.funcionariosAsignados.push(funcionarioAsignado);
      }
      console.log(this.funcionariosAsignados);

      this.DATA = [];
      this.spans = [];
      this.DATA = this.funcionariosAsignados.reduce((current, next) => {
          next.funcionarios.forEach(x => {
            current.push({ zona: next.zona,
                           cantidad: next.cantidad,
                           funcionarios: x })
          });
          return current;
      }, []);

      console.log(this.DATA);

      this.displayedColumns = ConstantesListas.COLUMNAS_GRID_ZONA_ASIGNADA;
      this.funcionarioAsignadosDS = new MatTableDataSource<FuncionariosAsignados>(this.DATA);
      this.cacheSpan('zona', x => x.zona);
      this.cacheSpan('cantidad', x => x.zona + x.cantidad);
      this.cacheSpan('funcionario', x => x.zona + x.cantidad + x.funcionarios);

      this.mostrarFuncAsignados = false;
      this.desabilitarBotonFAZ = false;
      this.desabilitarComboFAZ2 = true;
      this.desabilitarBotonFAZM = true;

    } else {
      this.enviarAsignaFuncionarioZona = new AsignaFuncionarioZona();
      this.enviarAsignaFuncionarioZona.tipoAsignacion = this.indTipoAsignacion;
      this.enviarAsignaFuncionarioZona.detallesAsignacion = this.lstZonas;
      this.enviarAsignaFuncionarioZona.numAsignacion = this.funcionarioZonaDetalle.numAsigFuncZona;

      this.asignaFuncionarioZonaService.obtenerFuncionariosDiponiblesPorTipoDeAsignacionAleatoria(this.enviarAsignaFuncionarioZona).subscribe(
        response => {
          console.log(response);
          this.enviarAsignaFuncionarioZona = (response.body as any) as AsignaFuncionarioZona;
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(
            ConstantesCadenas.MENSAJE_EXITOSO,
            "Se realizó la asignación de los funcionarios a las zonas correctamente.",
            "", "", this.callbackAsignar);
        },
        errorResult => {
          if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
            let responseManager: ResponseManager = new ResponseManager();
            this.responseErrorManager = errorResult as ResponseErrorManager;
            responseManager.cod = errorResult.cod;
            responseManager.errors = [this.responseErrorManager];
            this.responseManager = responseManager;
            this.cargarMensajesAsignacionFuncionariosZona(this.responseManager);
          } else {
            this.responseManager = errorResult as ResponseManager;
            this.cargarMensajesAsignacionFuncionariosZona(this.responseManager);
          }
        }

      );
    }

  }

  cargarFuncionariosDisponiblesListaAgrupada(detallesAsignacion: DetalleAsignafuncionarioZona[]) {
    this.funcionariosAsignados = [];

    for (let i = 0; i < detallesAsignacion.length; i++) {
      let funcionarioAsignado: FuncionariosAsignados = new FuncionariosAsignados();
      funcionarioAsignado.cantidad = detallesAsignacion[i].cantidadFuncionarios;
      funcionarioAsignado.zona = detallesAsignacion[i].zona.nombre;

      funcionarioAsignado.funcionarios = this.obtenerFuncionarios(detallesAsignacion[i].funcionarios,
        (this.indTipoAsignacion == ConstantesCadenas.TIPO_ASIGNACION_MANUAL ? true : false));

      this.funcionariosAsignados.push(funcionarioAsignado);
    }

    this.DATA = [];
    this.spans = [];
    this.DATA = this.funcionariosAsignados.reduce((current, next) => {
        next.funcionarios.forEach(x => {
          current.push({ zona: next.zona,
                         cantidad: next.cantidad,
                         funcionarios: x })
        });
        return current;
    }, []);

    this.displayedColumns = ConstantesListas.COLUMNAS_GRID_ZONA_ASIGNADA;
    this.funcionarioAsignadosDS = new MatTableDataSource<FuncionariosAsignados>(this.DATA);
    this.cacheSpan('zona', x => x.zona);
    this.cacheSpan('cantidad', x => x.zona + x.cantidad);
    this.cacheSpan('funcionario', x => x.zona + x.cantidad + x.funcionarios);
  }

  /**
  * Evaluated and store an evaluation of the rowspan for each row.
  * The key determines the column it affects, and the accessor determines the
  * value that should be checked for spanning.
  */
  cacheSpan(key, accessor) {
    for (let i = 0; i < this.DATA.length;) {
      let currentValue = accessor(this.DATA[i]);
      let count = 1;

      // Iterate through the remaining rows to see how many match
      // the current value as retrieved through the accessor.
      for (let j = i + 1; j < this.DATA.length; j++) {
        if (currentValue != accessor(this.DATA[j])) {
          break;
        }

        count++;
      }

      if (!this.spans[i]) {
        this.spans[i] = {};
      }

      // Store the number of similar values that were found (the span)
      // and skip i to the next unique row.
      this.spans[i][key] = count;
      i += count;
    }
  }

  getRowSpan(col, index) {
    return this.spans[index] && this.spans[index][col];
  }

  obtenerFuncionarios(funcionarios: FuncionarioDisponible[], esTipoAsignacionManual: boolean) {
    let resultData: string[] = [];
    for (let i = 0; i < funcionarios.length; i++) {
      if (esTipoAsignacionManual) {
        resultData.push(funcionarios[i].catEmpleado.codPers.toString());
      } else {
        resultData.push(funcionarios[i].catEmpleado.apPate.trim() + " " +
                        funcionarios[i].catEmpleado.apMate.trim() + " " +
                        funcionarios[i].catEmpleado.nombres.trim());
      }
    }
    return resultData;
  }

  callbackGrabar = () : void => {
    this.desabilitarBotonFAZ = false;
    this.desabilitarBotonFAZM = false;
    this.desabilitarComboFAZ = false;
    this.desabilitarComboFAZ2 = false;
    this.estadoOperacionAsignacion$.next("Y");
  };

  grabarAsignacionDeFuncionarioAZonaManual() {
    if (!this.validarFuncionarioAZonaManual()) {
      return false;
    }

    this.enviarAsignaFuncionarioZona = new AsignaFuncionarioZona();
    this.enviarAsignaFuncionarioZona.tipoAsignacion = this.indTipoAsignacion;
    this.enviarAsignaFuncionarioZona.detallesAsignacion = this.obtenerDetallesAsignacion();
    this.enviarAsignaFuncionarioZona.numAsignacion = this.funcionarioZonaDetalle.numAsigFuncZona;

    console.log("****TABLA CONSTRUIDA*******");
    console.log(this.enviarAsignaFuncionarioZona);

    this.asignaFuncionarioZonaService.grabarAsignacionDeFuncionarioAZonaManual(this.enviarAsignaFuncionarioZona).subscribe(
      response => {
        console.log(response);
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(
          ConstantesCadenas.MENSAJE_EXITOSO,
          "Se realizó la asignación de los funcionarios a las zonas correctamente.",
          "", "", this.callbackGrabar);
      },
      errorResult => {
        if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
          let responseManager: ResponseManager = new ResponseManager();
          this.responseErrorManager = errorResult as ResponseErrorManager;
          responseManager.cod = errorResult.cod;
          responseManager.errors = [this.responseErrorManager];
          this.responseManager = responseManager;
          this.cargarMensajesAsignacionFuncionariosZona(this.responseManager);
        } else {
          this.responseManager = errorResult as ResponseManager;
          this.cargarMensajesAsignacionFuncionariosZona(this.responseManager);
        }
      }
    );
  }

  obtenerDetallesAsignacion() {
    let listDetalleAsignaFuncionarioZona: DetalleAsignafuncionarioZona[] = FuncionesGenerales.getInstance().clonarObjeto(this.lstZonas);
    for (let i = 0; i < listDetalleAsignaFuncionarioZona.length; i++) {
      listDetalleAsignaFuncionarioZona[i].funcionarios = [];
      for (let j = 0; j < this.DATA.length; j++) {
        if (this.DATA[j].zona ==  listDetalleAsignaFuncionarioZona[i].zona.nombre.trim()) {
          let catEmpleado: CatEmpleado = new CatEmpleado();
          let funcionarioDisponible: FuncionarioDisponible = new FuncionarioDisponible();
          catEmpleado.codPers = this.DATA[j].funcionarios.toString();
          funcionarioDisponible.catEmpleado = catEmpleado;
          listDetalleAsignaFuncionarioZona[i].funcionarios.push(funcionarioDisponible);
        }
      }
    }
    return listDetalleAsignaFuncionarioZona;
  }

  validarFuncionarioAZonaManual() {
    let tituloErrores: string = "Mensaje de Error: ";
    let errorMensaje;
    let noExisteFuncAsignado: boolean = false;
    for (let i = 0; i < this.DATA.length; i++) {
      if (this.DATA[i].funcionarios.toString() == ConstantesCadenas.SELECCION_FUNCIONARIO) {
        noExisteFuncAsignado = true;
        break;
      }
    }
    if (noExisteFuncAsignado) {
      errorMensaje = "No deben haber casillas sin funcionario asignado";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }
    return true;
  }

  limpiarFuncionariosAZona() {
    this.lstZonas.map(x => { x.cantidadFuncionarios = 0; });
    /*for (let i = 0; i < this.lstZonas.length; i++) {
      this.lstZonas[i].cantidadFuncionarios = 0;
    }*/
  }

  getEstadoOperacionAsignacion$(): Observable<String> {
    return this.estadoOperacionAsignacion$.asObservable();
  }
}
