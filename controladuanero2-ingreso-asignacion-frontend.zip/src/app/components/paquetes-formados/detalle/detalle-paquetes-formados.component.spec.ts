import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetallePaquetesFormadosComponent } from './detalle-paquetes-formados.component';

describe('DetallePaquetesFormadosComponent', () => {
  let component: DetallePaquetesFormadosComponent;
  let fixture: ComponentFixture<DetallePaquetesFormadosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetallePaquetesFormadosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetallePaquetesFormadosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
