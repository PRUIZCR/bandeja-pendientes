import { Component, OnInit } from '@angular/core';
import { Datacatalogo } from 'src/app/models/datacatalogo';
import { Turno } from 'src/app/models/turno';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { Unidaddespacho } from 'src/app/models/unidaddespacho';
import { setTheme } from 'ngx-bootstrap/utils';
import { Horariosorteo } from 'src/app/models/horariosorteo';
import { TmpPaquete } from 'src/app/models/TmpPaquete';
import { TmpPaqueteService } from 'src/app/services/tmpPaquete.service';
import { CatalogoService } from 'src/app/services/catalogo.service';
import { Sorteo } from 'src/app/models/sorteo';
import { SelectionModel } from '@angular/cdk/collections';
import { Anfora } from 'src/app/models/anfora';
import { ConstantesListas } from 'src/app/utils/constanteslistas';
import { MatTableDataSource } from '@angular/material';
import { ResponseManager } from 'src/app/models/responsemanager';
import { ResponseErrorManager } from 'src/app/models/responseerrormanager';
import { ConstantesExcepciones } from 'src/app/utils/constantesExcepciones';
import { FuncionariosdisponiblesService } from 'src/app/services/funcionariosdisponibles.service';
import { FuncionarioDisponible } from 'src/app/models/funcionariodisponible';
import { UnidaddespachoService } from 'src/app/services/unidaddespacho.service';
import { TurnoService } from 'src/app/services/turno.service';
import { HorarioService } from 'src/app/services/horario.service';
import { ReasignacionBloqueService } from 'src/app/services/reasignacion-bloque.service';
import { throws } from 'assert';

@Component({
  selector: 'app-reasignacion-bloque',
  templateUrl: './reasignacion-bloque.component.html',
  styleUrls: ['./reasignacion-bloque.component.css']
})
export class ReasignacionBloqueComponent implements OnInit {

  rolValido : boolean = false;
  vigenciaRFU : boolean = false;
  anforaSeleccionada: string;
  aduanaSeleccionada: string;
  tipoPaqueteSeleccionado: string = "REG";
  turnoSeleccionado: string;
  unidadDespachoSeleccionado: string;
  hayParametrosDeBusqueda: boolean = true;
  hayPaquetes:boolean = false;
  mostrarParamentrosPaquetes:boolean = true;
  fechaVigenteDesde: Date = new Date();
  fechaVigenteHasta: Date = new Date();
  fechaActual: Date;
  horarioSeleccionado: string;
  deshabilitarParametrosBuqueda: boolean = false;
  deshabilitarAduana: boolean = false;
  aduanaSeleccionadaPerfil: string;
  fechaPaqueteStr: string;
  esCargaInicial: boolean;
  paqueteSeleccionado: String;
  funcionarioDisponibleSeleccionado: String;

  txtAduana: string;
  txtAnfora: string;
  txtFecha: string;
  txtHora: string;
  txtHorario: string;
  txtTotalPaquetes: number;
  txtTotalCargaLaboralAsignada: number;
  responseManager: ResponseManager;
  responseErrorManager: ResponseErrorManager;

  objAduanaSeleccionada: Datacatalogo;
  objAnforaSeleccionada: Datacatalogo;
  objUnidadDespachoSeleccionado: Unidaddespacho;
  objHorarioSeleccionado: Horariosorteo;
  objTurnoSeleccionado: Turno;
  objSorteo: Sorteo;
  anforaDS: MatTableDataSource<Anfora>;
  objFuncionarioDisponibleSeleccionado: FuncionarioDisponible;
  objPaqueteSeleccionado: TmpPaquete;

  aduanas: Datacatalogo[];
  anforas: Datacatalogo[];
  turnos: Turno[];
  unidadesDespacho: Unidaddespacho[];
  horarios: Horariosorteo[];
  lstDetallesPaquetes: TmpPaquete[];
  displayedColumns: string[];
  selection: SelectionModel<Anfora>;
  funcionariosDisponibles: FuncionarioDisponible[];
  funcionariosDisponiblesRFU: FuncionarioDisponible[];
  funcionesGenerales: FuncionesGenerales;

  constructor(private tmpPaqueteService: TmpPaqueteService,
              private catalogoService: CatalogoService,
              private funcionariosdisponiblesService: FuncionariosdisponiblesService,
              private unidadDespachoService: UnidaddespachoService,
              private tunoService: TurnoService,
              private horarioService: HorarioService,
              private reasignacionBloqueService: ReasignacionBloqueService) {
    setTheme('bs4');
    this.responseManager = new ResponseManager();
  }

  ngOnInit() {
    let roles: string = sessionStorage.getItem('roles');
    console.log("ROLES: " + roles);
    if (roles.includes("ADU-JEF-GFU") || roles.includes("ADU-JEF-GUS") ){
      this.rolValido = true;
    }
    if (roles.includes("ADUANA-JEFE-RFU") || roles.includes("ADUANA-JEFE-RFU-SINI") ){
      this.rolValido = true;
    } 
    this.hayPaquetes = false;
    this.hayParametrosDeBusqueda = true;
    this.deshabilitarParametrosBuqueda = false;
    this.selection = new SelectionModel<Anfora>(true, []);
    this.txtTotalCargaLaboralAsignada = 0;
    this.txtTotalPaquetes = 0;

    this.catalogoService.listarAduanas().subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.aduanaSeleccionada = result.aduana;
      this.aduanas = result.listaAduanas as Datacatalogo[];
      if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.aduanas)) {
        this.aduanas.map(
          x => (
            x.codDatacat = x.cod_datacat
          )
        );
        this.cargarControles();
      }
    }, error => console.error(error));

    //Validar vigencia RFU
    this.reasignacionBloqueService.vigenciaRFU().subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.vigenciaRFU = result.vigente == "true" ? true : false;
    }, error => console.error(error));

    this.fechaActual = new Date();
    this.txtFecha = ("00" + this.fechaActual.getDate()).slice(-2) + "/" +
                    ("00" + (this.fechaActual.getMonth() + 1)).slice(-2) + "/" +
                    this.fechaActual.getFullYear();
    this.txtHora = ("00" + this.fechaActual.getHours()).slice(-2) + ":" +
                   ("00" + this.fechaActual.getMinutes()).slice(-2) + ":" +
                   ("00" + this.fechaActual.getSeconds()).slice(-2);
    this.funcionesGenerales = FuncionesGenerales.getInstance();

    this.tipoPaqueteSeleccionado = "REG";
  }

  cargarControles() {
    //this.aduanaSeleccionada = this.aduanas[0].cod_datacat;
    console.log(this.aduanas);
    this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == this.aduanaSeleccionada);
    this.unidadesDespacho = [];
    this.cargarUnidadesDespacho(true);
  }

  seleccionarAduana(objSeleccionado) {
    this.aduanaSeleccionada = objSeleccionado.target.value;
    this.turnos = [];
    this.turnoSeleccionado = "";
    if (objSeleccionado.target.value != "") {
      this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == this.aduanaSeleccionada);
      this.cargarUnidadesDespacho(false);
    }
  }

  seleccionarTipoPaquete(objSeleccionado) {
    this.tipoPaqueteSeleccionado = objSeleccionado.target.value;
    //this.turnos = [];
    //this.turnoSeleccionado = "";
    if (objSeleccionado.target.value != "") {
      //this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == this.aduanaSeleccionada);
      //this.cargarUnidadesDespacho(false);
    }
  }

  cargarUnidadesDespacho(cargaInicial: boolean) {
    let campos: string = "numUnidadDespacho,nombre";
    this.unidadDespachoService.listarUnidadesDespacho(this.aduanaSeleccionada,
                                                      ConstantesCadenas.ESTADO_VIGENTE,
                                                      campos).subscribe(result => {
        FuncionesGenerales.getInstance().cerrarModalCargando();
        this.unidadesDespacho = result as Unidaddespacho[];
        //if (this.aduanaSeleccionada != "" && this.unidadesDespacho != null && this.unidadesDespacho != undefined && this.unidadesDespacho.length > 0) {
        if (this.aduanaSeleccionada != "" && FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.unidadesDespacho)) {
          this.unidadesDespacho = this.unidadesDespacho.sort(FuncionesGenerales.getInstance().ordenarPor("numUnidadDespacho", false));
          let defaultUD = this.unidadesDespacho[0].numUnidadDespacho;
          this.unidadDespachoSeleccionado = defaultUD.toString();
          this.objUnidadDespachoSeleccionado = this.unidadesDespacho.find(element => element.numUnidadDespacho == defaultUD);
          if (cargaInicial) {
            this.cargarAnforas(cargaInicial);
          } else {
            this.cargarAnforas(false);
            this.cargarTurnos();
          }

        } else {
          this.turnos = [];
          this.anforas = [];
          this.unidadesDespacho = [];
          this.anforaSeleccionada = "";
          this.turnoSeleccionado = "";
          this.unidadDespachoSeleccionado = "";
          let errorMensaje: string = "No existen unidades de despacho asignadas a la Aduana " + this.objAduanaSeleccionada.des_corta;
          let tituloErrores: string = "Mensaje de Error: ";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                      tituloErrores, errorMensaje, "");
        }
    });
  }

  seleccionarUnidadDespacho(objSeleccionado) {
    this.unidadDespachoSeleccionado = objSeleccionado.target.value;
    if (objSeleccionado.target.value != "") {
      this.objUnidadDespachoSeleccionado = this.unidadesDespacho.find(element => element.numUnidadDespacho == objSeleccionado.target.value);
      this.cargarAnforas(false);
      this.cargarTurnos();
    } else {
      this.turnos = [];
      this.anforas = [];
      this.turnoSeleccionado = "";
      this.anforaSeleccionada = "";
    }
  }

  cargarAnforas(cargaInicial: boolean) {
    this.catalogoService.listarAnforas(this.objUnidadDespachoSeleccionado.numUnidadDespacho).subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.anforas = result as Datacatalogo[];
      //if (this.anforas != null && this.anforas != undefined && this.anforas.length > 0) {
      if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.anforas)) {
        this.anforas.map(
          x => (
            x.codDatacat = x.cod_datacat
          )
        );
        this.anforas.sort(FuncionesGenerales.getInstance().ordenarPor("cod_datacat", false));
        this.anforaSeleccionada = this.anforas[0].cod_datacat;
        if (cargaInicial) {
          this.cargarTurnos();
        }
      }
    }, error => console.error(error));
  }

  cargarTurnos(fechaVigenteDesde?: Date) {
    let campos: string = "numTurno,nombre,hraInicio,hraFin";

    this.tunoService.listarTurnos(this.unidadDespachoSeleccionado,
                                  ConstantesCadenas.ESTADO_VIGENTE,
                                  fechaVigenteDesde != undefined || fechaVigenteDesde != null ? FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(fechaVigenteDesde) : "",
                                  fechaVigenteDesde != undefined || fechaVigenteDesde != null ? FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(fechaVigenteDesde) : "",
                                  campos, "X").subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.turnos = result as Turno[];
      //if (this.unidadDespachoSeleccionado != "" && this.turnos != null && this.turnos != undefined && this.turnos.length > 0) {
      if (this.unidadDespachoSeleccionado != "" && FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.turnos)) {
        this.turnos = this.turnos.sort(FuncionesGenerales.getInstance().ordenarPor("numTurno", false));
        let turnoCombo = this.turnos[0].numTurno;
        this.turnoSeleccionado = turnoCombo.toString();
        this.objTurnoSeleccionado = this.turnos.find(element => element.numTurno == turnoCombo);
        this.cargarHorarios();
      } else {
        this.horarios = [];
        this.turnos = [];
        this.turnoSeleccionado = "";
        this.horarioSeleccionado = "";
        let errorMensaje: string = "No existen turnos asociados a la unidad de despacho " + this.objUnidadDespachoSeleccionado.descripcion;
        let tituloErrores: string = "Mensaje de Error: ";
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    tituloErrores, errorMensaje, "");
      }
    }, error => console.error(error));

  }

  seleccionarTurno(objSeleccionado){
    this.turnoSeleccionado = objSeleccionado.target.value;
    this.horarios = [];
    this.horarioSeleccionado = "";
    if (objSeleccionado.target.value != "") {
      this.objTurnoSeleccionado = this.turnos.find(element => element.numTurno == objSeleccionado.target.value);
      this.cargarHorarios();
    }
  }

  seleccionarAnfora(objSeleccionado) {
    this.anforaSeleccionada = objSeleccionado.target.value;
    this.horarios = [];
    this.horarioSeleccionado = "";
    if (objSeleccionado.target.value != "") {
      this.objAnforaSeleccionada = this.anforas.find(element => element.cod_datacat == objSeleccionado.target.value);
      this.cargarHorarios();
    }
  }

  seleccionarHorario(objSeleccionado) {
    this.horarioSeleccionado = objSeleccionado.target.value;
    if (objSeleccionado.target.value != "") {
      this.objHorarioSeleccionado = this.horarios.find(element => (element.sorteo.numeroSorteo+"-"+element.numSecHorario) == objSeleccionado.target.value);
    }
  }

  changeFechaPaquete() {
    this.horarios = [];
    this.horarioSeleccionado = "";
    this.turnos = [];
    this.turnoSeleccionado = "";
    if(this.tipoPaqueteSeleccionado == "REG"){
      this.cargarTurnos(this.fechaVigenteDesde);
      this.cargarHorarios();
    }
  }

  cargarHorarios() {
    if (this.anforaSeleccionada != undefined && this.anforaSeleccionada != "" &&
        this.turnoSeleccionado != undefined && this.turnoSeleccionado != "" && this.fechaVigenteDesde != undefined) {
      this.horarioService.obtenerhorarios(this.anforaSeleccionada,
                                          this.turnoSeleccionado,
                                          this.fechaVigenteDesde,
                                          0, new Date()).subscribe(result => {
        FuncionesGenerales.getInstance().cerrarModalCargando();
        this.horarios = result as Horariosorteo[];
        //if (this.horarios != null && this.horarios != undefined && this.horarios.length > 0) {
        if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.horarios)) {
            let horarioCombo = this.horarios[0].sorteo.numeroSorteo || this.horarios[0].numSecHorario;
            this.horarioSeleccionado = horarioCombo.toString();
            this.objHorarioSeleccionado = this.horarios.find(element => (element.sorteo.numeroSorteo || element.numSecHorario || '') == horarioCombo)
        } else {
          this.horarioSeleccionado = "";
          let errorMensaje: string = "No existen horarios asociados al turno seleccionado.";
          let tituloErrores: string = "Mensaje de Error: ";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                      tituloErrores, errorMensaje, "");
        }
      }, error => console.error(error));
    }
  }

validarParametrosDeConsulta() {
    let tituloErrores: string = "Mensajes de Error: ";
    let esValido: boolean = false;
    if (this.aduanaSeleccionada == "") {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_DIECISIETE, "");
      return false;
    }
    if (this.fechaVigenteDesde == undefined) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_OCHO, "");
      return false;
    }
    if (!FuncionesGenerales.getInstance().esFechaValida(
         FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteDesde),
                                                        ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO)) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_NUEVE, "");
      return false;
    }
    if(this.tipoPaqueteSeleccionado == "REG"){
      if (this.unidadDespachoSeleccionado == "") {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    tituloErrores, ConstantesExcepciones.EXCEPCION_DIECINUEVE, "");
        return false;
      }
      if (this.turnoSeleccionado == "") {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    tituloErrores, ConstantesExcepciones.EXCEPCION_VEINTIUNO, "");
        return false;
      }
  
      if (this.horarioSeleccionado == "") {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    tituloErrores, ConstantesExcepciones.EXCEPCION_HORARIO_NO_EXISTE, "");
        return false;
      }
    }

    esValido = true;
    return esValido;
  }

  cargarMensajesOptimizacionPaquetes(responseManager: ResponseManager) {
    if (responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO ||
        responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                   "Mensajes de Error: ",
                                                                    "",
                                                                    FuncionesGenerales.getInstance().mostrarTablaDeErrores(this.responseManager.errors));
    }
  }

  limpiarOptimizacionPaquetes(){
    this.ngOnInit();
  }

  consultarPaquetes(){
    if (!this.validarParametrosDeConsulta()) {
      return false;
    }
    if(this.tipoPaqueteSeleccionado == "REG"){
      this.consultarDeclaracionesPaquetes();
      this.fechaPaqueteStr = ("00" + this.fechaVigenteDesde.getDate()).slice(-2) + "/" +
                           ("00" + (this.fechaVigenteDesde.getMonth() + 1)).slice(-2) + "/" +
                            this.fechaVigenteDesde.getFullYear();
      this.txtAduana = this.objAduanaSeleccionada.cod_datacat + " - " + this.objAduanaSeleccionada.des_corta;
      this.txtAnfora = (this.objAnforaSeleccionada != null ? this.objAnforaSeleccionada.des_corta : "");
    }else if(this.tipoPaqueteSeleccionado == "RFU"){
      this.consultarDeclaracionesPaquetesRFU();
      this.fechaPaqueteStr = ("00" + this.fechaVigenteDesde.getDate()).slice(-2) + "/" +
                           ("00" + (this.fechaVigenteDesde.getMonth() + 1)).slice(-2) + "/" +
                            this.fechaVigenteDesde.getFullYear();
      this.txtAduana = this.objAduanaSeleccionada.cod_datacat + " - " + this.objAduanaSeleccionada.des_corta;
      this.txtAnfora = (this.objAnforaSeleccionada != null ? this.objAnforaSeleccionada.des_corta : "");
    }
    
  }

  consultarDeclaracionesPaquetesRFU() {
    console.log("consultarDeclaracionesPaquetesRFU");
    this.tmpPaqueteService.obtenerDetallesPaquetesRFU(this.aduanaSeleccionada,
      this.fechaVigenteDesde, 
      4, //2, // tipo de consulta para reasignacion en bloque,
      new Date(), '', '', '',0
       ).subscribe(response => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.lstDetallesPaquetes = response as TmpPaquete[];
      console.log(this.lstDetallesPaquetes);
      //if (this.lstDetallesPaquetes == null || this.lstDetallesPaquetes == undefined){ /*cuando no existe paquete*/
      if (!FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstDetallesPaquetes)) {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    "Mensaje de Error: ", ConstantesExcepciones.EXCEPCION_PAQUETES_NO_ENCONTRADOS, "");
        return false;
      } else {
        /*remover las declaraciones sin empaquetar*/
        for (let i = 0; i < this.lstDetallesPaquetes.length; i++) {
           if ( this.lstDetallesPaquetes[i].numPaquete == 0) {
                this.lstDetallesPaquetes.splice(i, 1);
           }
        }

        if (this.lstDetallesPaquetes.length == 0) {
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                      "Mensaje de Error: ", ConstantesExcepciones.EXCEPCION_PAQUETES_NO_ENCONTRADOS, "");
          return false;
        }
     }

      this.deshabilitarParametrosBuqueda = true;
      this.hayParametrosDeBusqueda=false;
      this.hayPaquetes = true;
      this.lstDetallesPaquetes.sort((n1,n2)=>{return n1.numeroSecuenciaPaqueteAnfora-n2.numeroSecuenciaPaqueteAnfora});
      this.lstDetallesPaquetes.forEach(x=>{
        if(x.listaDuasAnfora!=undefined && x.listaDuasAnfora.length>0)
        {
          x.cargaLaboralPaquete=x.listaDuasAnfora.reduce((acc,obj,)=>acc+obj.numeroCargaLaboral,0);
          x.allSelected=false;
          x.anforaDS=new MatTableDataSource<Anfora>(x.listaDuasAnfora);
        }
        x.selection = new SelectionModel<Anfora>(true, []);
      });

      this.paqueteSeleccionado = "-1";
      this.funcionarioDisponibleSeleccionado = "-1";


      this.txtTotalCargaLaboralAsignada=this.lstDetallesPaquetes.reduce((acc,obj,)=>acc+ (obj.cargaLaboralPaquete != null && obj.cargaLaboralPaquete != undefined ?  obj.cargaLaboralPaquete: 0) ,0);
      this.txtTotalPaquetes=this.lstDetallesPaquetes.length;
      this.txtHorario = this.objHorarioSeleccionado != null ? this.objHorarioSeleccionado.horaSorteo : "";
      this.displayedColumns = ConstantesListas.COLUMNAS_GRID_DECLARACIONES_REASIGNACION;
      this.selection = new SelectionModel<Anfora>(true, []);

      /*probar con un tipo de fecha*/
      // let fechaPrueba: Date = new Date();
      // let strFechaPrueba: String = "06/05/2019"
      // fechaPrueba.setFullYear(parseInt(strFechaPrueba.split("/")[2]));
      // fechaPrueba.setMonth(parseInt(strFechaPrueba.split("/")[1])-1);
      // fechaPrueba.setDate(parseInt(strFechaPrueba.split("/")[0]));
      // fechaPrueba.setHours(0,0,0);
      // this.obtenerFuncionariosDisponibles(this.objTurnoSeleccionado.numTurno, fechaPrueba);
      /*fin de bloque de pruebas*/
      //Cargar listado de funcionarios disponibles.
      this.obtenerFuncionariosDisponiblesRFU(new Date(), this.aduanaSeleccionada); //this.fechaVigenteDesde

    },
    errorResult => {
      this.deshabilitarParametrosBuqueda = false;
      if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
        let responseManager: ResponseManager = new ResponseManager();
        this.responseErrorManager = errorResult as ResponseErrorManager;
        responseManager.cod = errorResult.cod;
        responseManager.errors = [this.responseErrorManager];
        this.responseManager = responseManager;
        this.cargarMensajesOptimizacionPaquetes(this.responseManager);
      } else {
        this.responseManager = errorResult as ResponseManager;
        this.cargarMensajesOptimizacionPaquetes(this.responseManager);
      }
    });
  }

  consultarDeclaracionesPaquetes() {
    console.log("consultarDeclaracionesPaquetes");
    this.tmpPaqueteService.obtenerDetallesPaquetes(
      (this.objHorarioSeleccionado != null ? this.objHorarioSeleccionado.sorteo.numeroSorteo : 0),
      (this.objHorarioSeleccionado != null ? this.objHorarioSeleccionado.numSecHorario : 0),
      this.anforaSeleccionada,
      4, //2, // tipo de consulta para reasignacion en bloque
      this.fechaVigenteDesde,
      new Date(), "", 0, "","","",this.tipoPaqueteSeleccionado
    ).subscribe(response => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.lstDetallesPaquetes = response as TmpPaquete[];
      //if (this.lstDetallesPaquetes == null || this.lstDetallesPaquetes == undefined){ /*cuando no existe paquete*/
      if (!FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstDetallesPaquetes)) {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    "Mensaje de Error: ", ConstantesExcepciones.EXCEPCION_PAQUETES_NO_ENCONTRADOS, "");
        return false;
      } else {
        /*remover las declaraciones sin empaquetar*/
        for (let i = 0; i < this.lstDetallesPaquetes.length; i++) {
           if ( this.lstDetallesPaquetes[i].numPaquete == 0) {
                this.lstDetallesPaquetes.splice(i, 1);
           }
        }

        if (this.lstDetallesPaquetes.length == 0) {
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                      "Mensaje de Error: ", ConstantesExcepciones.EXCEPCION_PAQUETES_NO_ENCONTRADOS, "");
          return false;
        }
     }

      this.deshabilitarParametrosBuqueda = true;
      this.hayParametrosDeBusqueda=false;
      this.hayPaquetes = true;
      this.lstDetallesPaquetes.sort((n1,n2)=>{return n1.numeroSecuenciaPaqueteAnfora-n2.numeroSecuenciaPaqueteAnfora});
      this.lstDetallesPaquetes.forEach(x=>{
        if(x.listaDuasAnfora!=undefined && x.listaDuasAnfora.length>0)
        {
          x.cargaLaboralPaquete=x.listaDuasAnfora.reduce((acc,obj,)=>acc+obj.numeroCargaLaboral,0);
          x.allSelected=false;
          x.anforaDS=new MatTableDataSource<Anfora>(x.listaDuasAnfora);
        }
        x.selection = new SelectionModel<Anfora>(true, []);
      });

      this.paqueteSeleccionado = "-1";
      this.funcionarioDisponibleSeleccionado = "-1";


      this.txtTotalCargaLaboralAsignada=this.lstDetallesPaquetes.reduce((acc,obj,)=>acc+ (obj.cargaLaboralPaquete != null && obj.cargaLaboralPaquete != undefined ?  obj.cargaLaboralPaquete: 0) ,0);
      //this.txtTotalCargaLaboralAsignada=this.lstDetallesPaquetes.reduce((acc,obj,)=>acc+obj.cargaLaboralPaquete,0);
      this.txtTotalPaquetes=this.lstDetallesPaquetes.length;
      this.txtHorario = this.objHorarioSeleccionado.horaSorteo;
      this.displayedColumns = ConstantesListas.COLUMNAS_GRID_DECLARACIONES_REASIGNACION;
      this.selection = new SelectionModel<Anfora>(true, []);

      /*probar con un tipo de fecha*/
      // let fechaPrueba: Date = new Date();
      // let strFechaPrueba: String = "06/05/2019"
      // fechaPrueba.setFullYear(parseInt(strFechaPrueba.split("/")[2]));
      // fechaPrueba.setMonth(parseInt(strFechaPrueba.split("/")[1])-1);
      // fechaPrueba.setDate(parseInt(strFechaPrueba.split("/")[0]));
      // fechaPrueba.setHours(0,0,0);
      // this.obtenerFuncionariosDisponibles(this.objTurnoSeleccionado.numTurno, fechaPrueba);
      /*fin de bloque de pruebas*/
      //Cargar listado de funcionarios disponibles.
      this.obtenerFuncionariosDisponibles(this.objTurnoSeleccionado.numTurno, this.fechaVigenteDesde, this.aduanaSeleccionada);

    },
    errorResult => {
      this.deshabilitarParametrosBuqueda = false;
      if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
        let responseManager: ResponseManager = new ResponseManager();
        this.responseErrorManager = errorResult as ResponseErrorManager;
        responseManager.cod = errorResult.cod;
        responseManager.errors = [this.responseErrorManager];
        this.responseManager = responseManager;
        this.cargarMensajesOptimizacionPaquetes(this.responseManager);
      } else {
        this.responseManager = errorResult as ResponseManager;
        this.cargarMensajesOptimizacionPaquetes(this.responseManager);
      }
    });
  }

  obtenerFuncionariosDisponibles(turno: number, fechaAsignacion: Date,aduana: String){

    this.funcionariosdisponiblesService.listarFuncionariosDisponibles(
      turno,
      fechaAsignacion,aduana).subscribe(response => {
          FuncionesGenerales.getInstance().cerrarModalCargando();
          this.funcionariosDisponibles = response as FuncionarioDisponible[];          
      },
      errorResult => {
          if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
            let responseManager: ResponseManager = new ResponseManager();
            this.responseErrorManager = errorResult as ResponseErrorManager;
            responseManager.cod = errorResult.cod;
            responseManager.errors = [this.responseErrorManager];
            this.responseManager = responseManager;
            this.cargarMensajesOptimizacionPaquetes(this.responseManager);
          } else {
            this.responseManager = errorResult as ResponseManager;
            this.cargarMensajesOptimizacionPaquetes(this.responseManager);
          }
    });
  }

  obtenerFuncionariosDisponiblesRFU(fechaAsignacion: Date, aduana: String){

    this.funcionariosdisponiblesService.listarFuncionariosDisponiblesRFU(
      fechaAsignacion, aduana).subscribe(response => {
          FuncionesGenerales.getInstance().cerrarModalCargando();
          this.funcionariosDisponiblesRFU = response as FuncionarioDisponible[];
          console.log(this.funcionariosDisponiblesRFU);
      },
      errorResult => {
          if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
            let responseManager: ResponseManager = new ResponseManager();
            this.responseErrorManager = errorResult as ResponseErrorManager;
            responseManager.cod = errorResult.cod;
            responseManager.errors = [this.responseErrorManager];
            this.responseManager = responseManager;
            this.cargarMensajesOptimizacionPaquetes(this.responseManager);
          } else {
            this.responseManager = errorResult as ResponseManager;
            this.cargarMensajesOptimizacionPaquetes(this.responseManager);
          }
    });
  }

  seleccionarPaquete(objSeleccionado) {
    this.paqueteSeleccionado = objSeleccionado.target.value;
    if (objSeleccionado.target.value != "") {
      this.objPaqueteSeleccionado = this.lstDetallesPaquetes.find(element => element.numPaquete == objSeleccionado.target.value);
      if(this.tipoPaqueteSeleccionado == "RFU"){
        //Filtramos los funcionarios segun los paquetes
        this.funcionariosDisponibles = [];
        objFunc: FuncionarioDisponible;
        for(let objFunc of this.funcionariosDisponiblesRFU){
          //en paquetes el RF -> RFU   y RS -> RFU SINI
          //si grupo de trabajo te dice si es GUS -> RFU DE SINI       o      GFU-> RFU 
          if( (this.objPaqueteSeleccionado.sorteo.anfora.codDatacat == "RF" && objFunc.grupoTrabajo.codDatacat == "GFU") ||
          (this.objPaqueteSeleccionado.sorteo.anfora.codDatacat == "RS" && objFunc.grupoTrabajo.codDatacat == "GUS")){
            this.funcionariosDisponibles.push(objFunc);
          } 
        }
      }
    }
  }

  seleccionarFuncionarioDisponible(objSeleccionado) {
    this.funcionarioDisponibleSeleccionado = objSeleccionado.target.value;
    console.log(this.funcionarioDisponibleSeleccionado);
    if (objSeleccionado.target.value != "") {
      this.objFuncionarioDisponibleSeleccionado = this.funcionariosDisponibles.find(element => (element.catEmpleado.codPers) == objSeleccionado.target.value);
    }
  }

  callback = () : void => {
    this.ngOnInit();
  };

  reasinarPaquete(){
    if(this.tipoPaqueteSeleccionado == "REG"){
      if (this.validarDatos()) {
        this.funcionariosdisponiblesService.registrarReasignarPaquete(this.objPaqueteSeleccionado.numPaquete,this.objFuncionarioDisponibleSeleccionado).subscribe(
          response => {
            console.log(response);
            FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(
              ConstantesCadenas.MENSAJE_EXITOSO,
              "El paquete se reasigno correctamente", "", "", this.callback);
          },
          errorResult => {
            if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
              let responseManager: ResponseManager = new ResponseManager();
              this.responseErrorManager = errorResult as ResponseErrorManager;
              responseManager.cod = errorResult.cod;
              responseManager.errors = [this.responseErrorManager];
              this.responseManager = responseManager;
            } else {
              this.responseManager = errorResult as ResponseManager;
            }
            if (this.responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO ||
                this.responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
              FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                            "Mensajes de Error: ",
                                                                            "",
                                                                            FuncionesGenerales.getInstance().mostrarTablaDeErrores(this.responseManager.errors));
            }
          }
        );
      }
    }else if(this.tipoPaqueteSeleccionado == "RFU"){
      console.log("inicio validar rfu");
      if (this.validarDatosRFU()) {
        this.funcionariosdisponiblesService.registrarReasignarPaqueteRFU(this.objPaqueteSeleccionado.numPaquete,this.objFuncionarioDisponibleSeleccionado).subscribe(
          response => {
            console.log(response);
            FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(
              ConstantesCadenas.MENSAJE_EXITOSO,
              "El paquete se reasigno correctamente", "", "", this.callback);
          },
          errorResult => {
            if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
              let responseManager: ResponseManager = new ResponseManager();
              this.responseErrorManager = errorResult as ResponseErrorManager;
              responseManager.cod = errorResult.cod;
              responseManager.errors = [this.responseErrorManager];
              this.responseManager = responseManager;
            } else {
              this.responseManager = errorResult as ResponseManager;
            }
            if (this.responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO ||
                this.responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
              FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                            "Mensajes de Error: ",
                                                                            "",
                                                                            FuncionesGenerales.getInstance().mostrarTablaDeErrores(this.responseManager.errors));
            }
          }
        );
      }
    }
  }

  validarDatos() {
    let tituloErrores: string = "Mensajes de Error: ";
    let errorMensaje;
    if (this.paqueteSeleccionado == "-1" || this.paqueteSeleccionado == "") {
      errorMensaje = "Debe seleccionar paquete a reasignar";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    } else if(this.funcionarioDisponibleSeleccionado == "-1") {
      errorMensaje = "Debe seleccionar funcionario disponible";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    return true;
  }

  validarDatosRFU() {
    let tituloErrores: string = "Mensajes de Error: ";
    let errorMensaje;
    if (this.paqueteSeleccionado == "-1" || this.paqueteSeleccionado == "") {
      errorMensaje = "Debe seleccionar paquete RFU a reasignar";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    } else if(this.funcionarioDisponibleSeleccionado == "-1") {
      errorMensaje = "Debe seleccionar funcionario a reasignar";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    } else if(this.objPaqueteSeleccionado != null && (this.objPaqueteSeleccionado.codigoFuncionario == this.funcionarioDisponibleSeleccionado)) {
      let funcionarioPaqueteSeleccionado = this.objPaqueteSeleccionado.codigoFuncionario + " - ";
      funcionarioPaqueteSeleccionado += this.objPaqueteSeleccionado.catEmpleado.nombres + " " +
                                        this.objPaqueteSeleccionado.catEmpleado.apPate + " " + this.objPaqueteSeleccionado.catEmpleado.apMate

      let numPaquete =    this.objPaqueteSeleccionado.numeroSecuenciaPaqueteAnfora; //numPaquete: 314621,numeroSecuenciaPaqueteAnfora: 3
      errorMensaje = "Funcionario "+funcionarioPaqueteSeleccionado+" ya se encuentra asignado al Paquete de RFU "+numPaquete;
      
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    } 

    return true;
  }

}
