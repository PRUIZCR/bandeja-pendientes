import { Injectable } from '@angular/core';
import { Zona } from 'src/app/models/zona';
import { ConstantesRest } from 'src/app/utils/constantesrest';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ZonaService {

  constructor(private http: HttpClient) { }

  registrarActualizarZona(objZona: Zona): Observable<any> {
    return this.http.post<HttpResponse<Object>>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_GRABAR_ZONA, "1"),
      objZona, { observe: 'response' }).pipe(
        catchError(e => {
          return throwError(e.error);
        })
      );
  }

  listarZonas(unidadDespachoSeleccionado: string,
              estadoSeleccionado: string,
              campos: string) {
    return this.http.get<Zona[]>(FuncionesGenerales.getInstance().reemplazarParametros(
        ConstantesRest.URL_LISTAR_ZONA,
        unidadDespachoSeleccionado,
        estadoSeleccionado,
        campos));
  }
}
