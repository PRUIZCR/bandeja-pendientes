import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { ConstantesRest } from 'src/app/utils/constantesrest';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';

@Injectable({
  providedIn: 'root'
})

export class CatEmpleadoService {

  constructor(private http: HttpClient) { }

  obtenerCatalogoFuncionarios(tipoRegistro: string,
                              unidadDespacho: string,
                              turno: string,
                              grupoFuncionario: string,
                              fechaVigenteDesde: Date,
                              fechaVigenteHasta: Date) : Observable<any> {
    return this.http.get<HttpResponse<Object>>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_LISTAR_CATALOGO_FUNCIONARIOS,
                                                                                    tipoRegistro,
                                                                                    unidadDespacho,
                                                                                    turno,
                                                                                    grupoFuncionario,
                                                                                    fechaVigenteDesde,
                                                                                    fechaVigenteHasta, "",  { observe: 'response' })).pipe(
      catchError(e => {
        return throwError(e.error);
      })
    );
  }

  buscarCatalogoFuncionarios(aduanaSeleccionada: string,
                             objRegistro: string,
                             objRegistroAP: string,
                             objGrupoTrabajo?: string,
                             filtroFuncionarioPorTurno?: string,
                             objRegimen?: string) : Observable<any> {
    objGrupoTrabajo = objGrupoTrabajo == undefined || objGrupoTrabajo.trim() == '' ? '' : objGrupoTrabajo;
    filtroFuncionarioPorTurno = filtroFuncionarioPorTurno == undefined || filtroFuncionarioPorTurno.trim() == '' ? '' : filtroFuncionarioPorTurno;
    objRegimen = objRegimen == undefined || objRegimen.trim() == '' ? '' : objRegimen;
    return this.http.get<HttpResponse<Object>>(FuncionesGenerales.getInstance().reemplazarParametros(
      ConstantesRest.URL_BUSCAR_FUNCIONARIO,
      aduanaSeleccionada,
      objRegistro,
      objRegistroAP,
      objGrupoTrabajo,
      filtroFuncionarioPorTurno,
      objRegimen,
      "",  { observe: 'response' })).pipe(
      catchError(e => {
         return throwError(e.error);
      })
     );
   }
}
