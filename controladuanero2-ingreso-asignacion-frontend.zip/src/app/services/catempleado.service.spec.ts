import { TestBed } from '@angular/core/testing';

import { CatEmpleadoService } from './catempleado.service';

describe('CatalogofuncionarioService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CatEmpleadoService = TestBed.get(CatEmpleadoService);
    expect(service).toBeTruthy();
  });
});
