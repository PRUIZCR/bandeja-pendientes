export interface Localanexo {
    spr_correl: string,
    direccion_desc: string
}
