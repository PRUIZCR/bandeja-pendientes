import { CatEmpleado } from './catempleado';

export class FuncionarioAnteriorRF {
  catEmpleado: CatEmpleado;
  numCorredocUS: number;
}
