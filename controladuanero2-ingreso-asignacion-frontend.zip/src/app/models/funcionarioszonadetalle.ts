export class FuncionariosZonaDetalle {
  nombreTurno: string;
  anfora: string;
  id: number;
  title: string;
  numAsigFuncZona: number;
  indice: number;
  indEstado: string;
  color: string;
  constructor() { }
}
