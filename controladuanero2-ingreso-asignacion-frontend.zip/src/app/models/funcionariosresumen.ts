export class FuncionariosResumen {
  codigo: string;
  fecInicio: Date;
  fecFin: Date;
  apellidoPaterno: string;
  apellidoMaterno: string;
  nombres: string;
  saved: boolean;
  motivo: string;
  /*columnaRetirar: string;
  columnaModificarVigencia: string;
  columnaNuevaVigencia: string;*/
  constructor() { }
}
