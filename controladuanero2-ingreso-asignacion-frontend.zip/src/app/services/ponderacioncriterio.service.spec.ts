import { TestBed } from '@angular/core/testing';

import { PonderacioncriterioService } from './ponderacioncriterio.service';

describe('PonderacioncriterioService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PonderacioncriterioService = TestBed.get(PonderacioncriterioService);
    expect(service).toBeTruthy();
  });
});
