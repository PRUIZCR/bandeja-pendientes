import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FuncionariosDetalle } from 'src/app/models/funcionariosdetalle';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { ConstantesListas } from 'src/app/utils/constanteslistas';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { MatTableDataSource } from '@angular/material';
import { MatSort  } from '@angular/material/sort';
import { MatPaginator  } from '@angular/material/paginator';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { FuncionarioDisponible } from 'src/app/models/funcionariodisponible';

@Component({
  selector: 'app-turno-funcionarios',
  templateUrl: './turno-funcionarios.component.html',
  styleUrls: ['./turno-funcionarios.component.css']
})
export class TurnoFuncionariosComponent implements OnInit {
  @ViewChild('childModal') childModal: ModalDirective;
  @ViewChild('matFR', {read: MatPaginator}) paginatorFR: MatPaginator;
  @ViewChild(MatSort) sortFR: MatSort;
  @ViewChild('matFD', {read: MatPaginator}) paginatorFD: MatPaginator;
  @ViewChild(MatSort) sortFD: MatSort;
  tituloRegistroFuncionario: string;
  unidadDespachoSeleccionado: string;
  aduanaSeleccionada: string;
  grupoFuncionarioSeleccionado:  string;
  funcionarios: FuncionariosDetalle;
  funcionariosRegistrados: FuncionarioDisponible[];
  funcionariosDisponibles: FuncionarioDisponible[];

  funcionarioRegistradoDS: MatTableDataSource<FuncionarioDisponible>;
  funcionarioDisponibleDS: MatTableDataSource<FuncionarioDisponible>;
  displayedColumnsFR: string[];
  displayedColumnsFD: string[];
  private estadoOperacion$ = new Subject<FuncionariosDetalle>();

  constructor() {

  }

  ngOnInit() { }

  cargarFuncionariosRegistrados(funcionarioDetalle: FuncionariosDetalle,
                                fechaEvento: Date,
                                aduanaSeleccionada: string,
                                unidadDespachoSeleccionado: string,
                                grupoFuncionarioSeleccionado: string) {
    this.funcionarios = FuncionesGenerales.getInstance().clonarObjeto(funcionarioDetalle);
    this.funcionarios.start = FuncionesGenerales.getInstance().convertirFormatoAnnioMesDiaComoCadena(fechaEvento);
    this.funcionariosRegistrados = this.obtenerFuncionariosRegistradosSIDisponibles(this.funcionarios);
    this.funcionariosDisponibles = this.obtenerFuncionariosDisponiblesNoRegistrados(this.funcionarios);
    this.tituloRegistroFuncionario = funcionarioDetalle.turno.indPermanente && funcionarioDetalle.turno.indPermanente === '1' ?
        FuncionesGenerales.getInstance().reemplazarParametros(ConstantesCadenas.TITULO_FUNCIONARIO_REGISTRADO_TURNO_SIN_HORARIO,
          FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(fechaEvento))
        : FuncionesGenerales.getInstance().reemplazarParametros(ConstantesCadenas.TITULO_FUNCIONARIO_REGISTRADO_TURNO,
          funcionarioDetalle.turno.nombre, FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(fechaEvento));
    this.aduanaSeleccionada = aduanaSeleccionada;
    this.unidadDespachoSeleccionado = unidadDespachoSeleccionado;
    this.grupoFuncionarioSeleccionado = grupoFuncionarioSeleccionado;

    this.displayedColumnsFR = ConstantesListas.COLUMNAS_GRID_FUNCIONARIO_REGISTRADO;
    this.displayedColumnsFD = ConstantesListas.COLUMNAS_GRID_FUNCIONARIO_DISPONIBLE;

    this.setearMatTableDataSource();
    this.childModal.show();
  }

  obtenerFuncionariosDisponiblesNoRegistrados(funcionariosRegistrados: FuncionariosDetalle) {
    return funcionariosRegistrados.funcionarios.filter(x => (x.estado === '0'));
  }

  obtenerFuncionariosRegistradosSIDisponibles(funcionariosRegistrados: FuncionariosDetalle) {
    return funcionariosRegistrados.funcionarios.filter(x => (x.estado === '1'));
  }

  cerrarTurnoDeFuncionarios() {
    this.childModal.hide();
  }

  retirarFuncionario(fregistrods: FuncionarioDisponible) {
    this.funcionariosDisponibles.push(fregistrods);
    this.funcionariosRegistrados = this.funcionariosRegistrados.filter(x => x.catEmpleado.codPers != fregistrods.catEmpleado.codPers);
    this.setearMatTableDataSource();
    console.log(this.funcionariosDisponibles);
    console.log(this.funcionariosRegistrados);
  }

  agregarFuncionario(fdisponibleds: FuncionarioDisponible) {
    this.funcionariosRegistrados.push(fdisponibleds);
    this.funcionariosDisponibles = this.funcionariosDisponibles.filter(x => x.catEmpleado.codPers != fdisponibleds.catEmpleado.codPers);
    this.setearMatTableDataSource();
    console.log(this.funcionariosDisponibles);
    console.log(this.funcionariosRegistrados);
  }

  registrarTurnoDeFuncionarios() {
    // Actualizar datos de Registrados
    this.funcionarios.funcionarios.map(
      x => {
        this.funcionariosRegistrados.map(
          fr => {
            if (x.catEmpleado.codPers === fr.catEmpleado.codPers) {
              x.estado = '1';
            }
          }
        );
      }
    );

    // Actualizar datos de Disponibles
    this.funcionarios.funcionarios.map(
      y => {
        this.funcionariosDisponibles.map(
          fd => {
            if (y.catEmpleado.codPers === fd.catEmpleado.codPers) {
              y.estado = '0';
            }
          }
        );
      }
    );

    this.cerrarTurnoDeFuncionarios();
    this.estadoOperacion$.next(this.funcionarios);
  }

  setearMatTableDataSource() {
    this.funcionarioRegistradoDS = new MatTableDataSource<FuncionarioDisponible>(this.funcionariosRegistrados);
    this.funcionarioRegistradoDS.sort = this.sortFR;
    this.funcionarioRegistradoDS.paginator = this.paginatorFR;

    this.funcionarioDisponibleDS = new MatTableDataSource<FuncionarioDisponible>(this.funcionariosDisponibles);
    this.funcionarioDisponibleDS.sort = this.sortFD;
    this.funcionarioDisponibleDS.paginator = this.paginatorFD;
  }

  getEstadoOperacion$(): Observable<FuncionariosDetalle> {
    return this.estadoOperacion$.asObservable();
  }
}
