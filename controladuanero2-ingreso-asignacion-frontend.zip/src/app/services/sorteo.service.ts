import { Injectable } from '@angular/core';
import { Sorteo } from 'src/app/models/sorteo';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { ConstantesRest } from 'src/app/utils/constantesrest';
import { catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';
import { FuncionesGenerales } from '../utils/funcionesgenerales';

@Injectable({
  providedIn: 'root'
})

export class SorteoService {

  constructor(private http: HttpClient) { }

  registrarActualizarSorteo(objSorteo: Sorteo): Observable<any> {
    return this.http.post<HttpResponse<Object>>(ConstantesRest.URL_GRABAR_SORTEO, objSorteo, { observe: 'response' }).pipe(
        catchError(e => {
          return throwError(e.error);
        })
      );
  }

  obtenerSorteo(numeroSorteo: number) {
    let campos: string = "numSorteo,turno,unidadDespacho,anfora,fechaInicio,fechaFin,indIncluirFeriado,numCargaMaxima,cantidadHorarios,horarios";
    return this.http.get<Sorteo[]>(FuncionesGenerales.getInstance().reemplazarParametros(
        ConstantesRest.URL_LISTAR_SORTEOS,
        numeroSorteo,
        '-1',
        '',
        new Date(),
        new Date(),
        campos));
  }

  listarSorteos(objSorteo: Sorteo) {
    let campos: string = "numSorteo,turno,unidadDespacho,anfora,fechaInicio,fechaFin,numCargaMaxima,horarios,tipoSorteo";
    return this.http.get<Sorteo[]>(FuncionesGenerales.getInstance().reemplazarParametros(
        ConstantesRest.URL_LISTAR_SORTEOS,
        "-1",
        objSorteo.turno.numTurno,
        objSorteo.anfora.codDatacat,
        objSorteo.fechaInicioVigencia,
        objSorteo.fechaFinVigencia,
        campos));
  }

  reporteSorteosYAsignacion(tipoReporte: string, campos: string, objSorteo: Sorteo) {
    return this.http.get<any>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_EXPORTAR_REPORTE_SORTEOS_ASIGNACION,
                                                                                    tipoReporte,
                                                                                    objSorteo.turno.numTurno,
                                                                                    objSorteo.anfora.codDatacat,
                                                                                    objSorteo.fechaInicioVigencia,
                                                                                    objSorteo.fechaFinVigencia, campos)).pipe(
      catchError(e => {
        return throwError(e.error);
      })
    );
  }
}
