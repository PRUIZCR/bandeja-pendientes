import { Observable } from 'rxjs/Observable';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { CatalogoService } from 'src/app/services/catalogo.service';
import { UnidaddespachoService } from 'src/app/services/unidaddespacho.service';
import { Datacatalogo } from 'src/app/models/datacatalogo';
import { Unidaddespacho } from 'src/app/models/unidaddespacho';
import { TurnoService } from 'src/app/services/turno.service';
import { Turno } from 'src/app/models/turno';
import { HorarioService } from 'src/app/services/horario.service';
import { Horariosorteo } from 'src/app/models/horariosorteo';
import { ResponseManager } from 'src/app/models/responsemanager';
import { CatEmpleado } from 'src/app/models/catempleado';
import { ConsultaSeleccionfuncionariosComponent } from 'src/app/components/seleccionfuncionarios/consulta/consulta-seleccionfuncionarios.component';
import { CatEmpleadoService } from 'src/app/services/catempleado.service';
import { ResponseErrorManager } from 'src/app/models/responseerrormanager';
import { TmpPaqueteService } from 'src/app/services/tmpPaquete.service';
import { TmpPaquete } from 'src/app/models/TmpPaquete';
import { ReporteHorario } from 'src/app/models/reportehorario';
import { Router } from '@angular/router';
import { ReporteAsignacion, TipoPaquete } from 'src/app/models/reporteasignacion';
import { Sorteo } from 'src/app/models/sorteo';
import { Zona } from 'src/app/models/zona';
import { ZonaService } from 'src/app/services/zona.service';
import { GrupoAlmacen } from 'src/app/models/grupoalmacen';
import { AlmacenService } from 'src/app/services/almacen.service';
import { readyException } from 'jquery';
import { interceptingHandler } from '@angular/common/http/src/module';
import { Localanexo } from 'src/app/models/localanexo';
import { Tipo } from '../../paquetes-formados/consulta/consulta-paquetes-formados.component';

@Component({
  selector: 'app-reporte-asignacion-bloque',
  templateUrl: './reporte-asignacion-bloque.component.html',
  styleUrls: ['./reporte-asignacion-bloque.component.css']
})
export class ReporteAsignacionBloqueComponent implements OnInit {
  @ViewChild(ConsultaSeleccionfuncionariosComponent) child: ConsultaSeleccionfuncionariosComponent;
  desabilitarBotonReporte: boolean = true;
  fechaHasta: Date;
  fechaDesde: Date;
  aduanas: Datacatalogo[];
  objAduanaSeleccionada: Datacatalogo;
  aduanaSeleccionada: string;
  unidadDespacho: Unidaddespacho;
  lstUnidadDespacho: Unidaddespacho[];
  objUnidadDespachoSeleccionado: Unidaddespacho;
  unidadDespachoSeleccionado: string;
  turnos: Turno[];
  objTurnoSeleccionado: Turno;
  turnoSeleccionado: string;
  anforas: Datacatalogo[];
  anforaSeleccionada: string;
  zonas: Zona[];
  zonaSeleccionada: string;
  objZona: Zona;
  lstLocales: Localanexo[];
  codLocalSeleccionado: string;
  objAnforaSeleccionada: Datacatalogo;
  listaHorarioSorteo: Horariosorteo[];
  objHorarioSorteo: Horariosorteo;
  horarioSorteoSeleccionado: string;
  rucAlmacen: string;
  disabledLocal: boolean = true; 
  desabilitarCriterioRegistro: boolean = true;
  habilitarSeleccion: boolean = false;
  objRegistro: string;
  objRegistroAP: string;
  habilitarAgregarFuncionarios: boolean = false;
  desabilitarCriterioAP: boolean = true;
  lstCatEmpleado: CatEmpleado[];
  responseErrorManager: ResponseErrorManager;
  responseManager: ResponseManager;
  estadoOperacion$: Observable<CatEmpleado>;
  objCatEmpleado: CatEmpleado;
  listDetallePaquetes: TmpPaquete[];
  lstReporteHorario: ReporteHorario[];
  funcionesGenerales: FuncionesGenerales;
  esVigenteRfu: boolean = false;
  listaTipoPaquetes: Tipo[] = [
    {id: "0", descripcion: "Paquetes de régimen"},
    {id: "1", descripcion: "Paquetes de reconocimiento físico único"},
  ];
  tipoPaqueteSeleccionado: string = ConstantesCadenas.TIPO_PAQUETE_REGIMEN;
  habilitarCambiosRfu: boolean = false;

  constructor(private catalogoService: CatalogoService,
              private unidadDespachoService: UnidaddespachoService,
              private zonaService: ZonaService, 
              private almacenService: AlmacenService,
              private turnoService: TurnoService,
              private horarioService: HorarioService,
              private catEmpleadoService: CatEmpleadoService,
              private router: Router,
              private tmpPaqueteService: TmpPaqueteService) { }

  ngOnInit() {
    this.fechaDesde = new Date();
    this.fechaHasta = new Date();
    this.unidadDespacho = new Unidaddespacho();
    this.unidadDespacho.numUnidadDespacho = -1;
    this.catalogoService.listarAduanas().subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.aduanaSeleccionada = result.aduana;
      this.aduanas = result.listaAduanas as Datacatalogo[];
      if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.aduanas)) {
        this.cargarControles();
      }
    }, error => console.error(error));
    this.objRegistro = "";
    this.objRegistroAP = "";
    this.rucAlmacen = "";

    this.estadoOperacion$ = this.child.getEstadoOperacion$();
    this.estadoOperacion$.subscribe(x => {
      if (x != null && Object.entries(x).length != 0) {
        this.objCatEmpleado = x as CatEmpleado;
        this.mostrarFiltroFuncionarios(this.objCatEmpleado);
        this.habilitarSeleccion = true;
        this.habilitarAgregarFuncionarios = true;
      } else {
        this.objCatEmpleado = null;
      }
     }
    );

    this.tmpPaqueteService.consultarVigencia().subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.esVigenteRfu = result.vigente;
    }, error => console.error(error));

    this.funcionesGenerales = FuncionesGenerales.getInstance();
  }

  validaConsultaReporte() {
    let errorMensaje: string = "";
    let tituloErrores: string = "Mensajes de Error: ";

    if (this.unidadDespachoSeleccionado == undefined ||
        this.unidadDespachoSeleccionado == null ||
        this.unidadDespachoSeleccionado == "") {
      errorMensaje = 'Seleccione la unidad de despacho.';
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (this.turnoSeleccionado == undefined ||
        this.turnoSeleccionado == null ||
        this.turnoSeleccionado == "") {
      errorMensaje = 'Seleccione el turno.';
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (this.anforaSeleccionada == undefined ||
        this.anforaSeleccionada == null ||
        this.anforaSeleccionada == "") {
      errorMensaje = 'Seleccione la anfora.';
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (this.horarioSorteoSeleccionado == undefined ||
        this.horarioSorteoSeleccionado == null ||
        this.horarioSorteoSeleccionado == "") {
      errorMensaje = 'Seleccione el horario del sorteo.';
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (this.fechaDesde == undefined || this.fechaDesde == null) {
      errorMensaje = 'Ingrese fecha de inicio.';
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (this.fechaHasta == undefined || this.fechaHasta == null) {
      errorMensaje = 'Ingrese fecha de fin.';
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (this.rucAlmacen != null && this.rucAlmacen != undefined && this.rucAlmacen.toString() != "") {
      if (this.rucAlmacen.toString().length > 11 || this.rucAlmacen.toString().length < 11) {
        errorMensaje = "El ruc del almacen debe tener 11 dígitos.";
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    tituloErrores, errorMensaje, "");
        return false;
      }

      if (!FuncionesGenerales.getInstance().rucValido(parseInt(this.rucAlmacen.toString())) &&
          !(parseInt(this.rucAlmacen.toString()) % 1 === 0)) {
        errorMensaje = "El ruc del almacen debe tener 11 dígitos.";
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    tituloErrores, errorMensaje, "");
        return false;
      }

      if (parseInt(this.rucAlmacen.toString()) <= 0) {
        errorMensaje = "El ruc del almacen debe tener 11 dígitos.";
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    tituloErrores, errorMensaje, "");
        return false;
      }
    }

    if ((this.objRegistro.length > 0 && this.objRegistroAP.length === 0) || (this.objRegistro.length === 0 && this.objRegistroAP.length > 0) ) {
      errorMensaje = "Ingrese funcionario válido.";
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    tituloErrores, errorMensaje, "");
        return false;
    }

    return true;
  }

  validaConsultaReporteRfu() {
    let errorMensaje: string = "";
    let tituloErrores: string = "Mensajes de Error: ";

    if (this.fechaDesde == undefined || this.fechaDesde == null) {
      errorMensaje = 'Ingrese fecha de inicio.';
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (this.fechaHasta == undefined || this.fechaHasta == null) {
      errorMensaje = 'Ingrese fecha de fin.';
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      return false;
    }

    if (this.rucAlmacen != null && this.rucAlmacen != undefined && this.rucAlmacen.toString() != "") {
      if (this.rucAlmacen.toString().length > 11 || this.rucAlmacen.toString().length < 11) {
        errorMensaje = "El ruc del almacen debe tener 11 dígitos.";
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    tituloErrores, errorMensaje, "");
        return false;
      }

      if (!FuncionesGenerales.getInstance().rucValido(parseInt(this.rucAlmacen.toString())) &&
          !(parseInt(this.rucAlmacen.toString()) % 1 === 0)) {
        errorMensaje = "El ruc del almacen debe tener 11 dígitos.";
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    tituloErrores, errorMensaje, "");
        return false;
      }

      if (parseInt(this.rucAlmacen.toString()) <= 0) {
        errorMensaje = "El ruc del almacen debe tener 11 dígitos.";
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    tituloErrores, errorMensaje, "");
        return false;
      }
    }

    if ((this.objRegistro.length > 0 && this.objRegistroAP.length === 0) || (this.objRegistro.length === 0 && this.objRegistroAP.length > 0) ) {
      errorMensaje = "Ingrese funcionario válido.";
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    tituloErrores, errorMensaje, "");
        return false;
    }
    
    return true;
  }

  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;

  }

  consultarReporte() {
    let codLocal = (this.codLocalSeleccionado != null && this.codLocalSeleccionado != null ? this.codLocalSeleccionado : "");
    let codZona = (this.zonaSeleccionada != null ? this.zonaSeleccionada : "" );
    console.log("Local Anexo:"+ codLocal);
    console.log("RUC:"+this.rucAlmacen);
    console.log("Zona:"+codZona);
    if(this.tipoPaqueteSeleccionado === ConstantesCadenas.TIPO_PAQUETE_REGIMEN){
      if (!this.validaConsultaReporte()) {
        return false;
      }
    } else {
      if(!this.validaConsultaReporteRfu()){
        return false;
      }
    }
    
    if(this.tipoPaqueteSeleccionado == ConstantesCadenas.TIPO_PAQUETE_REGIMEN){
      this.tmpPaqueteService.obtenerDetallesPaquetes(this.objHorarioSorteo.sorteo.numeroSorteo,
        this.objHorarioSorteo.numSecHorario,
        this.objAnforaSeleccionada.cod_datacat,
        4,
        this.fechaDesde,
        this.fechaHasta,
        this.rucAlmacen == null || this.rucAlmacen == undefined ? "" : this.rucAlmacen,
        this.horarioSorteoSeleccionado == "" ? parseInt(this.turnoSeleccionado) : 0,
        this.objRegistro,codZona,codLocal, '').subscribe(result => {
          FuncionesGenerales.getInstance().cerrarModalCargando();
          let reporteAsignacion: ReporteAsignacion = new ReporteAsignacion();
          this.listDetallePaquetes = result as TmpPaquete[];
          //if (this.listDetallePaquetes != null && this.listDetallePaquetes != undefined && this.listDetallePaquetes.length > 0) {
          if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.listDetallePaquetes)) {
          this.listDetallePaquetes = this.listDetallePaquetes.sort(FuncionesGenerales.getInstance().ordenarPor("numeroSecuenciaPaqueteAnfora", false));
          this.lstReporteHorario = this.agruparListaPorPaquete(this.listDetallePaquetes);
          reporteAsignacion.listaReporteHorarios = this.lstReporteHorario;
          reporteAsignacion.codAnfora = this.objAnforaSeleccionada.cod_datacat;
          reporteAsignacion.codFuncionario = this.objRegistro;
          reporteAsignacion.strFechaDesde = FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaDesde);
          reporteAsignacion.strFechaHasta = FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaHasta);
          reporteAsignacion.rucAlmacen = this.rucAlmacen;
          reporteAsignacion.numTurno = parseInt(this.turnoSeleccionado);
          reporteAsignacion.numHorario = this.objHorarioSorteo.numSecHorario;
          reporteAsignacion.numSorteo = this.objHorarioSorteo.sorteo.numeroSorteo;
          reporteAsignacion.numZona = ($("#selZona").val() != null && $("#selZona").val() != "-1") ? Number($("#selZona").val()) : -1 ;
          reporteAsignacion.codLocal = ($("#selLocal").val() != null && $("#selLocal").val() != "-1") ? $("#selLocal").val().toString() : "" ;
          // this.reporteAsignacion.listaReporteHorarios
          sessionStorage.setItem('reporteAsignacion', JSON.stringify(reporteAsignacion));
          this.router.navigate(['/lista-asignacion-bloque/', JSON.stringify("1"), {esVigenteRfu: this.esVigenteRfu}]);
          } else {
          let tituloErrores: string = "Mensaje de Error: ";
          let errorMensaje = "No hay datos disponibles para la consulta.";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                    tituloErrores, errorMensaje, "");
          }
          }, error => console.log(error));
    } else {
      this.tmpPaqueteService.obtenerDetallesPaquetesRFU(
        this.aduanaSeleccionada,
        this.fechaDesde,
        6,
        this.fechaHasta,
        this.rucAlmacen == null || this.rucAlmacen == undefined ? "" : this.rucAlmacen,
        codLocal,
        this.objRegistro,0).subscribe(result => {
          FuncionesGenerales.getInstance().cerrarModalCargando();
          let reporteAsignacion: ReporteAsignacion = new ReporteAsignacion();
          this.listDetallePaquetes = result as TmpPaquete[];
          if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.listDetallePaquetes)) {
          this.listDetallePaquetes = this.listDetallePaquetes.sort(FuncionesGenerales.getInstance().ordenarPor("numeroSecuenciaPaqueteAnfora", false));
          this.lstReporteHorario = this.agruparListaPorPaquete(this.listDetallePaquetes);
          reporteAsignacion.listaReporteHorarios = this.lstReporteHorario;
          // reporteAsignacion.codAnfora = this.objAnforaSeleccionada.cod_datacat;
          reporteAsignacion.codAduana = this.aduanaSeleccionada;
          reporteAsignacion.tipoPaquete = this.tipoPaqueteSeleccionado === ConstantesCadenas.TIPO_PAQUETE_RFU ? TipoPaquete.TIPO_PAQUETE_RFU: TipoPaquete.TIPO_PAQUETE_REGIMEN;
          reporteAsignacion.codFuncionario = this.objRegistro;
          reporteAsignacion.strFechaDesde = FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaDesde);
          reporteAsignacion.strFechaHasta = FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaHasta);
          reporteAsignacion.rucAlmacen = this.rucAlmacen;
          // reporteAsignacion.numTurno = parseInt(this.turnoSeleccionado);
          // reporteAsignacion.numHorario = this.objHorarioSorteo.numSecHorario;
          // reporteAsignacion.numSorteo = this.objHorarioSorteo.sorteo.numeroSorteo;
          // reporteAsignacion.numZona = ($("#selZona").val() != null && $("#selZona").val() != "-1") ? Number($("#selZona").val()) : -1 ;
          reporteAsignacion.codLocal = ($("#selLocal").val() != null && $("#selLocal").val() != "-1") ? $("#selLocal").val().toString() : "" ;
          sessionStorage.setItem('reporteAsignacion', JSON.stringify(reporteAsignacion));
          this.router.navigate(['/lista-asignacion-bloque/', JSON.stringify("1"), {esVigenteRfu: this.esVigenteRfu}]);
          } else {
          let tituloErrores: string = "Mensaje de Error: ";
          let errorMensaje = "No hay datos disponibles para la consulta.";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                    tituloErrores, errorMensaje, "");
          }
          }, error => console.log(error));
    }
  }

  agruparListaPorPaquete(listDetallePaquetes: TmpPaquete[]) {
    let lstPaquetes: ReporteHorario[] = [];
    listDetallePaquetes.map(
      x => {
        let tmpAduana = this.objAduanaSeleccionada.cod_datacat;
        let tmpAnfora = this.objAnforaSeleccionada.cod_datacat;
        let reporte: ReporteHorario = lstPaquetes.find(function(elemento) {
          return (elemento.aduana.cod_datacat == tmpAduana &&
                  elemento.anfora.cod_datacat == tmpAnfora &&
                  elemento.horario == x.desHorario &&
                  FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(elemento.fecha) ==
                  FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(x.fecPP) &&
                  elemento.sorteo.numeroSorteo == x.sorteo.numeroSorteo);
        });

        if (reporte != undefined && reporte != null) {
          reporte.listDetallePaquetes.push(x);
        } else {
          reporte = new ReporteHorario();
          reporte.aduana = this.objAduanaSeleccionada;
          reporte.anfora = this.objAnforaSeleccionada;
          reporte.horario = x.desHorario;
          reporte.sorteo = x.sorteo;
          reporte.fecha = x.fecPP;
          reporte.listDetallePaquetes = [x];
          lstPaquetes.push(reporte);
        }
      }
    );
    console.log(lstPaquetes);
    return lstPaquetes;
  }

  seleccionarAduana(objSeleccionado) {
    this.aduanaSeleccionada = objSeleccionado.target.value;
    if (objSeleccionado.target.value != "") {
      this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == objSeleccionado.target.value);
      this.cargarUnidadesDespacho();
    }
  }

  seleccionarUnidadDespacho(objSeleccionado) {
    this.unidadDespachoSeleccionado = objSeleccionado.target.value;
    if (objSeleccionado.target.value != "") {
      this.objUnidadDespachoSeleccionado = this.lstUnidadDespacho.find(element => element.numUnidadDespacho == objSeleccionado.target.value);
      this.cargarTurnos();
      this.cargarAnforas();
      this.cargarZonas();
    }
  }

  seleccionarTurno(objSeleccionado) {
    this.turnoSeleccionado = objSeleccionado.target.value;
    if (objSeleccionado.target.value != "") {
      this.objTurnoSeleccionado = this.turnos.find(element => element.numTurno == objSeleccionado.target.value);
      this.cargarHorarios();
    }
  }

  seleccionarHorario(objSeleccionado) {
    this.horarioSorteoSeleccionado = objSeleccionado.target.value;
    if (this.horarioSorteoSeleccionado != "" && this.horarioSorteoSeleccionado != "-1") {
      this.objHorarioSorteo = this.listaHorarioSorteo.find(element => (element.sorteo.numeroSorteo+"-"+element.numSecHorario) == objSeleccionado.target.value);
    }else if(this.horarioSorteoSeleccionado == "-1"){
      this.objHorarioSorteo = new Horariosorteo();
      this.objHorarioSorteo.sorteo = new Sorteo();
      this.objHorarioSorteo.sorteo.numeroSorteo = -1;
      this.objHorarioSorteo.numSecHorario = -1;
    }
  }

  
  seleccionarZona(objSeleccionado) {
    this.zonaSeleccionada = objSeleccionado.target.value;
    this.limpiarRucLocal();
    this.changeRucAlmacen();
  }
  seleccionarLocal(objSeleccionado){
    this.codLocalSeleccionado = objSeleccionado.target.value;
  }

  limpiarRucLocal(){
    this.lstLocales = [];
    this.disabledLocal = true;
    this.codLocalSeleccionado = "-1";
    this.rucAlmacen="";
  }

  changeRucAlmacen(){
    this.disabledLocal = true;
    $("#selLocal").val("-1");
    let ruc = $("#selRucAlmacen").val().toString();
    if(!this.habilitarCambiosRfu){
      if(ruc.toString().length == 11 && (this.zonaSeleccionada != null && this.zonaSeleccionada != '-1' ) ){
          this.almacenService.listarLocalesPorZonaRuc(Number(this.unidadDespachoSeleccionado),
              Number(this.zonaSeleccionada),ruc.toString()).subscribe(result => {
            FuncionesGenerales.getInstance().cerrarModalCargando();
            this.lstLocales = result != null ? result as Localanexo[] : [];
            if(this.lstLocales.length > 0){
              this.disabledLocal = false;            
            }
          }); 
      }  
    } else {      
      this.almacenService.listarLocalesPorRuc(ruc.toString()).subscribe(result => {
        FuncionesGenerales.getInstance().cerrarModalCargando();
        this.lstLocales = result != null ? result as Localanexo[] : [];
        if(this.lstLocales.length > 0){
          this.disabledLocal = false;            
        }
      }); 
    }  
  }

  cargarControles() {
    //this.aduanaSeleccionada = this.aduanas[0].cod_datacat;
    this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == this.aduanaSeleccionada);
    this.unidadDespacho.aduana = this.objAduanaSeleccionada;
    this.cargarUnidadesDespacho();
  }

  cargarUnidadesDespacho() {
    let campos: string = "numUnidadDespacho,nombre";
    this.unidadDespachoService.listarUnidadesDespacho(this.aduanaSeleccionada,
                                                      ConstantesCadenas.ESTADO_VIGENTE,
                                                      campos).subscribe(result => {
     FuncionesGenerales.getInstance().cerrarModalCargando();
     this.lstUnidadDespacho = result as Unidaddespacho[];
     //if (this.aduanaSeleccionada != "" && this.lstUnidadDespacho != null && this.lstUnidadDespacho != undefined) {
     if (this.aduanaSeleccionada != "" && FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstUnidadDespacho)) {
       this.lstUnidadDespacho = this.lstUnidadDespacho.sort(FuncionesGenerales.getInstance().ordenarPor("numUnidadDespacho", false));
       this.unidadDespachoSeleccionado = this.lstUnidadDespacho[0].numUnidadDespacho.toString();
       this.objUnidadDespachoSeleccionado = this.lstUnidadDespacho.find(element => element.numUnidadDespacho == parseInt(this.unidadDespachoSeleccionado));
       this.objUnidadDespachoSeleccionado.aduana = this.objAduanaSeleccionada;
       this.cargarTurnos();
       this.cargarAnforas();
       this.cargarZonas();
     } else {
       this.lstUnidadDespacho = [];
       let tituloErrores: string = "Mensaje de Error: ";
       let errorMensaje: string = "No existen unidades de despacho asignadas a la Aduana " + this.objAduanaSeleccionada.des_corta;
       FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                     tituloErrores, errorMensaje, "");
     }
    }, error => console.error(error));
  }

  seleccionarAnfora(objSeleccionado) {
    this.anforaSeleccionada = objSeleccionado.target.value;
    if (objSeleccionado.target.value != "") {
      this.objAnforaSeleccionada = this.anforas.find(element => element.cod_datacat == this.anforaSeleccionada);
      this.cargarHorarios();
    }
  }

  cargarAnforas() {
    if (this.objUnidadDespachoSeleccionado.numUnidadDespacho == -1) {
      this.anforas = [];
      this.anforaSeleccionada = "";
    } else {
      this.catalogoService.listarAnforas(this.objUnidadDespachoSeleccionado.numUnidadDespacho).subscribe(result => {
        FuncionesGenerales.getInstance().cerrarModalCargando();
        this.anforas = result as Datacatalogo[];
        //if (this.anforas != null && this.anforas != undefined && this.anforas.length > 0) {
        if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.anforas)) {
          this.anforas = this.anforas.sort(FuncionesGenerales.getInstance().ordenarPor("cod_datacat", false));
          this.anforaSeleccionada = this.anforas[0].cod_datacat;
          this.objAnforaSeleccionada = this.anforas.find(element => element.cod_datacat == this.anforaSeleccionada);
          this.cargarHorarios();
        }
      }, error => console.error(error));
    }
  }

  cargarZonas() {
    if (this.objUnidadDespachoSeleccionado.numUnidadDespacho == -1) {
      this.zonas = [];
    } else {
      this.zonaService.listarZonas(this.unidadDespachoSeleccionado + '', ConstantesCadenas.ESTADO_ACTIVO, "numZona,nombre").subscribe(result => {
        FuncionesGenerales.getInstance().cerrarModalCargando();
        this.zonas = result as Zona[];
        if (!FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.zonas)) {
          this.zonas = [];
        }        
      }, error => console.error(error));
    }
    this.limpiarRucLocal();
    this.zonaSeleccionada = null;
  }

  cargarTurnos() {
    if(this.objUnidadDespachoSeleccionado.numUnidadDespacho == -1){
      this.turnos = [];
      this.turnoSeleccionado = "";
    }else{
      let campos: string = "numTurno,nombre,hraInicio,hraFin";
      this.turnoService.listarTurnos(this.objUnidadDespachoSeleccionado.numUnidadDespacho.toString(),
                                     ConstantesCadenas.ESTADO_VIGENTE, "", "",
                                     campos).subscribe(result => {
       FuncionesGenerales.getInstance().cerrarModalCargando();
       this.turnos = result as Turno[];
       //if (this.turnos != null && this.turnos != undefined && this.turnos.length > 0) {
       if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.turnos)) {
         this.turnos = this.turnos.sort(FuncionesGenerales.getInstance().ordenarPor("hraInicio", false));
         this.turnoSeleccionado = this.turnos[0].numTurno.toString();
         this.objTurnoSeleccionado = this.turnos.find(element => element.numTurno == parseInt(this.turnoSeleccionado));
         this.cargarHorarios();
       } else{
         this.turnos = [];
         this.turnoSeleccionado = "";
         let tituloErrores: string = "Mensaje de Error: ";
         let errorMensaje = "La unidad de despacho seleccionada no tiene turnos asociados.";
         FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                       tituloErrores, errorMensaje, "");
       }
      }, error => console.error(error));
    }
  }

  cambioFecha() {
    if(this.tipoPaqueteSeleccionado === ConstantesCadenas.TIPO_PAQUETE_REGIMEN){
      this.cargarHorarios();
    }
  }

  buscarCatalogoFuncionarios(hayFuncionario: boolean) {
    let habilitarBusqueda: boolean = true;
    let registro: string = '';
    let registroAP: string = '';
    if (this.habilitarSeleccion) {
      registro = this.objRegistro;
      registroAP = this.objRegistroAP;
      if (this.desabilitarCriterioRegistro) {
        registroAP = '';
        habilitarBusqueda = true;
      } else {
        registro = '';
        if (registroAP == '') {
          habilitarBusqueda = false;
          this.habilitarSeleccion = false;
          this.objRegistro = registro;
          this.desabilitarCriterioRegistro = true;
        } else {
          habilitarBusqueda = true;
        }
      }
    } else {
      if (this.objRegistro.length > 0 && this.objRegistroAP.length == 0) {
        if (this.desabilitarCriterioRegistro) {
          this.desabilitarCriterioRegistro = true;
          this.desabilitarCriterioAP = false;
        } else {
          this.desabilitarCriterioRegistro = true;
          this.desabilitarCriterioAP = true;
          this.objRegistro = '';
          habilitarBusqueda = false;
        }
      } else if (this.objRegistroAP.length > 0 && this.objRegistro.length == 0) {
        if (this.desabilitarCriterioAP) {
          this.desabilitarCriterioRegistro = false;
          this.desabilitarCriterioAP = true;
        } else {
          this.desabilitarCriterioRegistro = true;
          this.desabilitarCriterioAP = true;
          this.objRegistroAP = '';
          habilitarBusqueda = false;
        }
      } else if (this.objRegistroAP.length == 0 && this.objRegistro.length == 0) {
        this.desabilitarCriterioRegistro = true;
        this.desabilitarCriterioAP = true;
        this.objRegistro = '';
        this.objRegistroAP = '';
        habilitarBusqueda = false;
      } else if (this.objRegistroAP.length > 0 && this.objRegistro.length > 0) {
        if (this.desabilitarCriterioAP) {
          this.objRegistro = '';
        } else {
          this.objRegistroAP = '';
        }
        habilitarBusqueda = true;
      }
      registro = this.objRegistro;
      registroAP = this.objRegistroAP;
    }
    if (habilitarBusqueda) {
      this.catEmpleadoService.buscarCatalogoFuncionarios(
        this.aduanaSeleccionada,
        registro,
        registroAP
      ).subscribe(response => {
        FuncionesGenerales.getInstance().cerrarModalCargando();
        this.lstCatEmpleado = response as CatEmpleado[];
        this.validarFuncionariosResumen(this.lstCatEmpleado);
        if (hayFuncionario) {
          this.habilitarAgregarFuncionarios = true;
        }
      },
      errorResult => {
        this.habilitarSeleccion = false;
        if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
          let responseManager: ResponseManager = new ResponseManager();
          this.responseErrorManager = errorResult as ResponseErrorManager;
          responseManager.cod = errorResult.cod;
          responseManager.errors = [this.responseErrorManager];
          this.responseManager = responseManager;
          this.cargarMensajesReporteAsignacionBloque(this.responseManager);
        } else {
          this.responseManager = errorResult as ResponseManager;
          this.cargarMensajesReporteAsignacionBloque(this.responseManager);
        }
      });
    }
  }

  cargarMensajesReporteAsignacionBloque(responseManager: ResponseManager) {
    if (responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO ||
        responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                   'Mensajes de Error: ',
                                                                    '',
                                                                    FuncionesGenerales.getInstance().mostrarTablaDeErrores(this.responseManager.errors));
    }
  }

  validarFuncionariosResumen(lstCatEmpleado: CatEmpleado[]) {
    let errorMensaje: string = '';
    let tituloErrores: string = 'Mensaje de Error: ';
    let esValido: boolean = false;
    if (lstCatEmpleado.length == 0) {
      errorMensaje = 'No se encontraron funcionarios con los datos ingresados';
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, '');
      return false;
    }
    if (lstCatEmpleado.length == 1) {
      this.mostrarFiltroFuncionarios(lstCatEmpleado[0]);
      this.habilitarAgregarFuncionarios = true;
      return false;
    }
    this.child.mostrarSeleccionDeFuncionarios(lstCatEmpleado);
    esValido = true;
    return esValido;
  }

  mostrarFiltroFuncionarios(objCatEmpleado: CatEmpleado) {
    this.objRegistro = objCatEmpleado.codPers;
    this.objRegistroAP = objCatEmpleado.apMate.trim() + ' ' +
                         objCatEmpleado.apPate.trim() + ' ' +
                         objCatEmpleado.nombres.trim();
  }

  cargarHorarios() {
    if (this.anforaSeleccionada != "" &&
        this.turnoSeleccionado != "" &&
        this.fechaDesde != undefined && this.fechaDesde != null &&
        this.fechaHasta != undefined && this.fechaHasta != null) {
      this.horarioService.obtenerhorarios(this.anforaSeleccionada,
                                          this.turnoSeleccionado,
                                          this.fechaDesde,
                                          parseInt(ConstantesCadenas.TIPO_PARAMETRO_REPORTE_ASIGNACION_BLOQUE),
                                          this.fechaHasta).subscribe(result => {
       FuncionesGenerales.getInstance().cerrarModalCargando();
       this.listaHorarioSorteo = result as Horariosorteo[];
       console.log(this.listaHorarioSorteo)
       //if (this.listaHorarioSorteo != null && this.listaHorarioSorteo != undefined && this.listaHorarioSorteo.length > 0) {
       if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.listaHorarioSorteo)) {
         this.listaHorarioSorteo = this.listaHorarioSorteo.sort(FuncionesGenerales.getInstance().ordenarPor("horaCorte", false));
          if(this.listaHorarioSorteo.length > 1){
            this.horarioSorteoSeleccionado = "-1";
            this.objHorarioSorteo = new Horariosorteo();
            this.objHorarioSorteo.sorteo = new Sorteo();
            this.objHorarioSorteo.sorteo.numeroSorteo = -1;
            this.objHorarioSorteo.numSecHorario = -1;
          }else{
            let horarioCombo = this.listaHorarioSorteo[0].sorteo.numeroSorteo || this.listaHorarioSorteo[0].numSecHorario;
            this.horarioSorteoSeleccionado = horarioCombo.toString();
            this.objHorarioSorteo = this.listaHorarioSorteo.find(element => (element.sorteo.numeroSorteo || element.numSecHorario || '') == horarioCombo);
          }
       } else {

         this.listaHorarioSorteo = [];
         let tituloErrores: string = "Mensaje de Error: ";
         let errorMensaje = "Los criterios seleccionados no tienen horario de sorteo.";
         FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                       tituloErrores, errorMensaje, "");
       }

      }, errorResult => {
        this.listaHorarioSorteo = [];
        if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
          let responseManager: ResponseManager = new ResponseManager();
          this.responseErrorManager = errorResult as ResponseErrorManager;
          responseManager.cod = errorResult.cod;
          responseManager.errors = [this.responseErrorManager];
          this.responseManager = responseManager;
          this.cargarMensajesReporteAsignacionBloque(this.responseManager);
        } else {
          this.responseManager = errorResult as ResponseManager;
          this.cargarMensajesReporteAsignacionBloque(this.responseManager);
        }
      });
    }
  }

  changeTipoPaquete(objPaqueteSeleccionado) {
    this.limpiarRucLocal();
    const paqueteSeleccionado = objPaqueteSeleccionado.target.value;
    this.tipoPaqueteSeleccionado = (paqueteSeleccionado && paqueteSeleccionado !=="") ? paqueteSeleccionado : ConstantesCadenas.TIPO_PAQUETE_REGIMEN;
    this.habilitarCambiosRfu = this.tipoPaqueteSeleccionado === ConstantesCadenas.TIPO_PAQUETE_RFU;
  }
  
}
