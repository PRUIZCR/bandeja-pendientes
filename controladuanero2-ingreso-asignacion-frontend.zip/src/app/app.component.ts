import { Component, OnInit } from '@angular/core';
import { Usuariobean } from './models/usuariobean';
import { ConstantesCadenas } from './utils/constantescadenas';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'controladuanero2-ingreso-asignacion-frontend';

  ngOnInit() {
    sessionStorage.setItem('versionPase', 'PAS20201U220400031');
    sessionStorage.setItem('usuariobean', sessionStorage.getItem('usuariobean').replace(/(\r\n|\n|\r)/gm, ""));
    // Actualizamos valor del JWT
    let datoToken = JSON.parse(sessionStorage.getItem('token'));
    sessionStorage.setItem('token', datoToken.access_token);
    // Obtenemos la lista de roles como cadena separada por comas
    let usuario: Usuariobean = JSON.parse(sessionStorage.getItem('usuariobean'));
    let roles:  string = ConstantesCadenas.ROLES_DEFAULT_NORMATIVO + ",";
    let tieneRolJefeSupervisor = "0";
    let tieneRolJefeRFU = "0";
    Object.keys(usuario.map).map((key)=>{
      if(key.trim() == "roles"){
        Object.keys(usuario.map[key]).map((key2)=>{
          roles = roles + key2 + ",";
          if(ConstantesCadenas.ROLES_JEFE_SUPERVISOR.indexOf(key2) > -1)
            tieneRolJefeSupervisor = "1";
          if(ConstantesCadenas.ROLES_JEFE_RFU.indexOf(key2) > -1)
            tieneRolJefeRFU = "1";
        });
      }
    });
    sessionStorage.setItem('roles', roles);
    sessionStorage.setItem('esJefeSupervisor', tieneRolJefeSupervisor);
    sessionStorage.setItem('esJefeRFU', tieneRolJefeRFU);
  }
}
