import { Component, OnInit } from '@angular/core';
import { Datacatalogo } from 'src/app/models/datacatalogo';
import { Unidaddespacho } from 'src/app/models/unidaddespacho';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { CriterioAsigEspeService } from 'src/app/services/criterioasigespe.service'
import { setTheme } from 'ngx-bootstrap/utils';
import { ResponseErrorManager } from 'src/app/models/responseerrormanager';
import { ResponseManager } from 'src/app/models/responsemanager';
import { CriterioAsigEspe } from "src/app/models/criterioasigespe";
import { MatTableDataSource } from '@angular/material';
import { ConstantesListas } from 'src/app/utils/constanteslistas';
import { CatalogoService } from 'src/app/services/catalogo.service';
import { UnidaddespachoService } from 'src/app/services/unidaddespacho.service';

@Component({
  selector: 'app-ponderacion-criterio',
  templateUrl: './ponderacion-criterio.component.html',
  styleUrls: ['./ponderacion-criterio.component.css']
})
export class PonderacionCriterioComponent implements OnInit {
  aduanaSeleccionada: string;
  objAduanaSeleccionada: Datacatalogo;
  aduanas: Datacatalogo[];
  lstUnidadDespacho: Unidaddespacho[];
  unidadDespachoSeleccionado: string;
  objUnidadDespachoSeleccionado: Unidaddespacho;
  lstCriterioAsigEspe: CriterioAsigEspe[];
  criteriosDS: MatTableDataSource<CriterioAsigEspe>;
  displayedColumns: string[];
  responseErrorManager: ResponseErrorManager;
  responseManager: ResponseManager;
  esSoloConsulta: boolean;

  constructor(private catalogoService: CatalogoService,
              private criterioAsigEspeService: CriterioAsigEspeService,
              private unidadDespachoService: UnidaddespachoService) {
    setTheme('bs4');
  }

  ngOnInit() {
    this.esSoloConsulta = sessionStorage.getItem('esJefeSupervisor') == '0';
    this.catalogoService.listarAduanas().subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.aduanaSeleccionada = result.aduana;
      this.aduanas = result.listaAduanas as Datacatalogo[];
      if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.aduanas)) {
        this.cargarControles();
      }
    }, error => console.error(error));
  }

  cargarControles() {
    this.lstUnidadDespacho = [];
    //this.aduanaSeleccionada = this.aduanas[0].cod_datacat;
    this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == this.aduanaSeleccionada);
    this.cargarUnidadesDespacho();
  }

  seleccionarAduana(objSeleccionado) {
    this.aduanaSeleccionada = objSeleccionado.target.value;
    if (objSeleccionado.target.value != "") {
      this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == objSeleccionado.target.value);
      this.cargarUnidadesDespacho();
    }
  }

  cargarUnidadesDespacho() {
    let campos: string = "numUnidadDespacho,nombre";
    this.unidadDespachoService.listarUnidadesDespacho(this.aduanaSeleccionada,
                                                      ConstantesCadenas.ESTADO_VIGENTE,
                                                      campos).subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.lstUnidadDespacho = result as Unidaddespacho[];
      if (this.aduanaSeleccionada != "" && FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstUnidadDespacho)) {
        //this.lstUnidadDespacho != null && this.lstUnidadDespacho != undefined && this.lstUnidadDespacho.length > 0) {
        this.lstUnidadDespacho = this.lstUnidadDespacho.sort(FuncionesGenerales.getInstance().ordenarPor("numUnidadDespacho", false));
        this.unidadDespachoSeleccionado = this.lstUnidadDespacho[0].numUnidadDespacho.toString();
        this.objUnidadDespachoSeleccionado = this.lstUnidadDespacho[0];
        this.cargarCriterios();
      } else {
        this.lstUnidadDespacho = [];
        this.lstCriterioAsigEspe = [];
        this.displayedColumns = ConstantesListas.COLUMNAS_GRID_CRITERIOS_PONDERADO;
        this.criteriosDS = new MatTableDataSource<CriterioAsigEspe>(this.lstCriterioAsigEspe);
        let tituloErrores: string = "Mensaje de Error: ";
        let errorMensaje: string = "No existen unidades de despacho asignadas a la Aduana " + this.objAduanaSeleccionada.des_corta;
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                      tituloErrores, errorMensaje, "");
      }
    }, error => console.error(error));
  }

  seleccionarUnidadDespacho(objSeleccionado) {
    this.unidadDespachoSeleccionado = objSeleccionado.target.value;
    if (objSeleccionado.target.value != "") {
      this.objUnidadDespachoSeleccionado = this.lstUnidadDespacho.find(element => element.numUnidadDespacho == objSeleccionado.target.value);
      this.cargarCriterios();
    } else {
      this.lstCriterioAsigEspe = [];
      this.displayedColumns = ConstantesListas.COLUMNAS_GRID_CRITERIOS_PONDERADO;
      this.criteriosDS = new MatTableDataSource<CriterioAsigEspe>(this.lstCriterioAsigEspe);
    }
  }

  cargarCriterios() {
    let campos = "codTipoCriterio,nombreTipoCriterio,codCriterio,nombreCriterio,numUnidadDespacho,fecInicioVigencia,fecFinVigencia,porcentaje,peso,observacion,historial,codUsuarioModifica";
    this.criterioAsigEspeService.listarCriteriosDeAsignacion(this.unidadDespachoSeleccionado,
                                                            campos).subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.lstCriterioAsigEspe = result as CriterioAsigEspe[];
      if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstCriterioAsigEspe)) {
        this.lstCriterioAsigEspe = this.obtenerAgrupacionDeCriterios(this.lstCriterioAsigEspe);
      } else {
        this.lstCriterioAsigEspe = [];
      }
      this.displayedColumns = ConstantesListas.COLUMNAS_GRID_CRITERIOS_PONDERADO;
      this.criteriosDS = new MatTableDataSource<CriterioAsigEspe>(this.lstCriterioAsigEspe);
    }, error => console.error(error));
  }

  obtenerAgrupacionDeCriterios(lstAgrupadaCriterioAsigEspe: CriterioAsigEspe[]) {
    if (lstAgrupadaCriterioAsigEspe.length > 0) {
      return <CriterioAsigEspe[]>Array.from(new Set(lstAgrupadaCriterioAsigEspe.map(
          x => x.criterio.desDatacat
        ))).map(x => lstAgrupadaCriterioAsigEspe.find(y => y.criterio.desDatacat == x));
    } else {
      lstAgrupadaCriterioAsigEspe = [];
    }
    return lstAgrupadaCriterioAsigEspe;
  }

  limpiarPonderacion() {
    for (var i = 0; i < this.lstCriterioAsigEspe.length; i++) {
      this.lstCriterioAsigEspe[i].porCriterio = "";
    }
  }

  registrarCriterioPonderacion() {
    if (!this.validarCriterioPonderacion(this.lstCriterioAsigEspe)) {
      return false;
    }
    this.registrarPonderacion();
  }

  callback = () : void => {
    this.cargarCriterios();
  };

  registrarPonderacion() {
    this.criterioAsigEspeService.registrarPonderacion(this.lstCriterioAsigEspe, this.unidadDespachoSeleccionado).subscribe(
      response => {
        console.log(response);
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(
          ConstantesCadenas.MENSAJE_EXITOSO,
          "Los criterios de ponderación se registraron correctamente.",
          "", "", this.callback);
      },
      errorResult => {
        if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
          let responseManager: ResponseManager = new ResponseManager();
          this.responseErrorManager = errorResult as ResponseErrorManager;
          responseManager.cod = errorResult.cod;
          responseManager.errors = [this.responseErrorManager];
          this.responseManager = responseManager;
          this.cargarMensajesServicioCriterioPonderacion(this.responseManager);
        } else {
          this.responseManager = errorResult as ResponseManager;
          this.cargarMensajesServicioCriterioPonderacion(this.responseManager);
        }
      }
    );
  }

  cargarMensajesServicioCriterioPonderacion(responseManager: ResponseManager) {
    if (responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO ||
        responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                   "Mensajes de Error: ",
                                                                    "",
                                                                    FuncionesGenerales.getInstance().mostrarTablaDeErrores(this.responseManager.errors));
    }
  }

  validarCriterioPonderacion(lstCriterioAsigEspe: CriterioAsigEspe[]) {
    let errorMensaje: string = "";
    let tituloErrores: string = "Mensajes de Error: ";
    let esValido: boolean = false;
    let cantidadCriterios: number = 0;
    let porCriterio: number = 0;
    for (let i = 0; i < lstCriterioAsigEspe.length; i++) {
      if (lstCriterioAsigEspe[i].porCriterio === "") {
        errorMensaje = "Complete todos valores de los porcentajes de ponderación.";
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    tituloErrores, errorMensaje, "");
        esValido = false;
        break;
      }

      if(isNaN(parseInt(lstCriterioAsigEspe[i].porCriterio))){
        porCriterio = 0;
      } else {
        porCriterio = parseInt(lstCriterioAsigEspe[i].porCriterio);
      }

      if (!(porCriterio >= 0 &&
            porCriterio < 99)) {
        errorMensaje = "El valor del porcentajes de ponderación debe de ser mayor o igual a 0 y menor o igual a 99.";
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    tituloErrores, errorMensaje, "");
        esValido = false;
        break;
      }      
      
      cantidadCriterios += porCriterio;
    }

    if (cantidadCriterios != 100) {
      errorMensaje = "Ponderaciones consignadas no suman el 100%, sírvase verificar.";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, "");
      esValido = false;
    } else {
      esValido = true;
    }

    if (!esValido) {
      return false;
    }
    return esValido;
  }

}
