import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsultaFuncionarioZonaComponent } from './consulta-funcionario-zona.component';

describe('ConsultaFuncionarioZonaComponent', () => {
  let component: ConsultaFuncionarioZonaComponent;
  let fixture: ComponentFixture<ConsultaFuncionarioZonaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsultaFuncionarioZonaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsultaFuncionarioZonaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
