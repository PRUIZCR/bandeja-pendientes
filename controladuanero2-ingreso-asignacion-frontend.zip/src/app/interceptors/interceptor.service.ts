import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Usuariobean } from 'src/app/models/usuariobean';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { FuncionesGenerales } from '../utils/funcionesgenerales';

@Injectable()
export class InterceptorService implements HttpInterceptor {

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
      FuncionesGenerales.getInstance().mostrarModalCargando();

      let usuario: Usuariobean = JSON.parse(sessionStorage.getItem('usuariobean'));
      const proxyReq = req.clone({
          url: req.url + (req.url.indexOf("?") >= 0 ? "&" : "?" ) + "usuario=" + usuario.login,
          headers: (req.method == ConstantesCadenas.METHOD_HTTP_POST || req.method == ConstantesCadenas.METHOD_HTTP_PUT  || req.method == ConstantesCadenas.METHOD_HTTP_GET ?
                    req.headers.set("Authorization", "Bearer " + sessionStorage.getItem("token")) :
                    req.headers)
      });
      return next.handle(proxyReq);
    }

    replacer(key,value){
        if (key=="visibilidad") return undefined;
        else return value;
    }
}