import { Component, OnInit, ViewChild } from '@angular/core';
import { CriterioAsigEspe } from "src/app/models/criterioasigespe";
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { ConstantesListas } from 'src/app/utils/constanteslistas';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { MatTableDataSource } from '@angular/material';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { MatSort  } from '@angular/material/sort';
import { MatPaginator  } from '@angular/material/paginator';

@Component({
  selector: 'app-ponderacion-historico',
  templateUrl: './ponderacion-historico.component.html',
  styleUrls: ['./ponderacion-historico.component.css']
})
export class PonderacionHistoricoComponent implements OnInit {
  @ViewChild('childModal') childModal: ModalDirective;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  tituloPonderacionHistorico: string;
  nombreCriterio: string;
  historialCriteriosDS: MatTableDataSource<CriterioAsigEspe>;
  displayedColumns: string[];
  funcionesGenerales: FuncionesGenerales;

  constructor() {
     this.funcionesGenerales = FuncionesGenerales.getInstance();
  }

  ngOnInit() { }

  verHistorico(lstAgrupadaCriterioAsigEspe: CriterioAsigEspe[], nombreCriterio: string) {
    this.tituloPonderacionHistorico = ConstantesCadenas.TITULO_HISTORICO_PONDERACION_CRITERIOS;
    this.nombreCriterio = nombreCriterio;
    this.displayedColumns = ConstantesListas.COLUMNAS_GRID_HISTORICO_PONDERACION_CRITERIOS;
    lstAgrupadaCriterioAsigEspe = lstAgrupadaCriterioAsigEspe.sort(FuncionesGenerales.getInstance().ordenarPor("porCriterio", false));
    lstAgrupadaCriterioAsigEspe = lstAgrupadaCriterioAsigEspe.sort(FuncionesGenerales.getInstance().ordenarPor("fechaModifica", false));
    this.historialCriteriosDS = new MatTableDataSource<CriterioAsigEspe>(lstAgrupadaCriterioAsigEspe);
    this.historialCriteriosDS.sort = this.sort;
    this.historialCriteriosDS.paginator = this.paginator;
    this.childModal.show();
  }

  cerrarPonderacionHistorico() {
    this.childModal.hide();
  }

}
