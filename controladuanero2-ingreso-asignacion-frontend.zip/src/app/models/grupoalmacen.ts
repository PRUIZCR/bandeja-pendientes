import { Zona } from './zona';

export class GrupoAlmacen {
  numDocumento: string;
  tipoDocumento: string;
  codLocalAnexo: string;
  codTipoGrupo: string;
  codGrupo: string;
  codOperador: string;
  nombreAlmacen: string;
  nombreRazonSocial: string;
  direccion: string;
  codUbigeo: string;
  descUbigeo: string;
  fechaInicioVigencia: Date;
  fechaFinVigencia: Date;
  indicadorEliminacion: string;
  codAduana: string;
  codOperadorDepAduanero: string;
  zona: Zona;
  constructor() { }
}
