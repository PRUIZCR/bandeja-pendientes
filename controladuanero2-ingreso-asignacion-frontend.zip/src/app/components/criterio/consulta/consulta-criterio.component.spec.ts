import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsultaCriterioComponent } from './consulta-criterio.component';

describe('ConsultaCriterioComponent', () => {
  let component: ConsultaCriterioComponent;
  let fixture: ComponentFixture<ConsultaCriterioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsultaCriterioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsultaCriterioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
