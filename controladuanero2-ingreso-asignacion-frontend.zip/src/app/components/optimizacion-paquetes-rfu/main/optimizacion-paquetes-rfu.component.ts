import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { SelectionModel } from '@angular/cdk/collections';
import { TmpPaqueteService } from 'src/app/services/tmpPaquete.service';
import { setTheme } from 'ngx-bootstrap/utils';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { ConstantesExcepciones } from 'src/app/utils/constantesExcepciones';
import { ConstantesListas } from 'src/app/utils/constanteslistas';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { Unidaddespacho } from 'src/app/models/unidaddespacho';
import { TmpPaquete } from 'src/app/models/TmpPaquete';
import { Datacatalogo } from 'src/app/models/datacatalogo';
import { Turno } from 'src/app/models/turno';
import { Horariosorteo } from 'src/app/models/horariosorteo';
import { ResponseManager } from 'src/app/models/responsemanager';
import { ResponseErrorManager } from 'src/app/models/responseerrormanager';
import { MatTableDataSource } from '@angular/material';
import { Anfora } from 'src/app/models/anfora';
import { CatalogoService } from 'src/app/services/catalogo.service';
import { UnidaddespachoService } from 'src/app/services/unidaddespacho.service';
import { TurnoService } from 'src/app/services/turno.service';
import { HorarioService } from 'src/app/services/horario.service';
import Swal from 'sweetalert2';
import { Zona } from 'src/app/models/zona';
import { environment } from 'src/environments/environment';
import { print } from 'util';

@Component({
  selector: 'app-optimizacion-paquetes-rfu',
  templateUrl: './optimizacion-paquetes-rfu.component.html',
  styleUrls: ['./optimizacion-paquetes-rfu.component.css']
})
export class OptimizacionPaquetesRFUComponent implements OnInit {
  txtFecha: string;
  txtHora: string;
  txtAduana: string;
  txtFechaHoraCorte: string;
  txtFechaHoraSorteo: string;
  txtAnfora: string;
  txtTotalPaquetes: number;
  txtTotalCargaLaboralAsignada: string;
  txtNumSecPaquete:number;
  txtTotalCargaLaboralPaquete: string;
  txtCantidadDeclaraciones:number;
  fechaActual: Date;
  lstAduanas: Datacatalogo[];
  lstAnfora: Datacatalogo[];
  lstUnidadDespacho: Unidaddespacho[];
  lstTurnos: Turno[];
  lstHorarios: Horariosorteo[];
  lstDetallesPaquetes: TmpPaquete[];
  estadoOperacionFuncionario$: Observable<TmpPaquete>;
  aduanaSeleccionada: string;
  unidadDespachoSeleccionado: string;
  anforaSeleccionada: string;
  turnoSeleccionado: string;
  horarioSeleccionado: string;
  objAduanaSeleccionada: Datacatalogo;
  objAnforaSeleccionada: Datacatalogo;
  objUnidadDespachoSeleccionado: Unidaddespacho;
  objTurnoSeleccionado: Turno;
  objHorarioSeleccionado: Horariosorteo;
  objTmpPaqueteSeleccionado: TmpPaquete;
  fechaVigenteDesde: Date = new Date();
  hayPaquetes: boolean = false;
  hayParametrosDeBusqueda: boolean=true;
  deshabilitarParametrosBuqueda: boolean = false;
  responseManager: ResponseManager;
  responseErrorManager: ResponseErrorManager;
  fechaPaqueteStr: string;
  anforaDS: MatTableDataSource<Anfora>;
  anforasSinAsignar:Anfora[];
  displayedColumns: string[];
  idNuevoPaquete: number;
  selection: SelectionModel<Anfora>;
  funcionesGenerales: FuncionesGenerales;
  fechaMinima: Date;
  numeroSecuenciaPaqueteMaximo: number;
  txtFechaformacionPaquete: string;

  constructor(private tmpPaqueteService: TmpPaqueteService,
              private unidadDespachoService: UnidaddespachoService,
              private turnoService: TurnoService,
              private horarioService: HorarioService,
              private catalogoService: CatalogoService)
    {
      setTheme('bs4');
      this.responseManager = new ResponseManager();
    }
  ngOnInit() {
    this.fechaMinima = new Date();
    this.hayPaquetes = false;
    this.deshabilitarParametrosBuqueda=sessionStorage.getItem('esJefeRFU') == '0';//false;
    this.anforasSinAsignar=[];
    this.selection = new SelectionModel<Anfora>(true, []);
    this.lstDetallesPaquetes=[];
    this.anforaDS=new MatTableDataSource<Anfora>(this.anforasSinAsignar);
    this.idNuevoPaquete=-1;
    this.txtTotalCargaLaboralAsignada="0";
    this.txtTotalPaquetes=0;
    this.txtNumSecPaquete=0;
    this.txtCantidadDeclaraciones=0;
    this.txtTotalCargaLaboralPaquete="0";
    this.catalogoService.listarAduanas().subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.aduanaSeleccionada = result.aduana;
      this.lstAduanas = result.listaAduanas as Datacatalogo[];
      if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstAduanas)) {
        this.cargarControles();
      }
    }, error => console.error(error));
    this.fechaActual = new Date();
    this.txtFecha = ("00" + this.fechaActual.getDate()).slice(-2) + "/" +
                    ("00" + (this.fechaActual.getMonth() + 1)).slice(-2) + "/" +
                    this.fechaActual.getFullYear();
    this.txtHora = ("00" + this.fechaActual.getHours()).slice(-2) + ":" +
                   ("00" + this.fechaActual.getMinutes()).slice(-2) + ":" +
                   ("00" + this.fechaActual.getSeconds()).slice(-2);
    this.funcionesGenerales = FuncionesGenerales.getInstance();
  }
  cargarControles() {
    //this.aduanaSeleccionada = this.lstAduanas[0].cod_datacat;
    this.objAduanaSeleccionada = this.lstAduanas.find(element => element.cod_datacat == this.aduanaSeleccionada);
    this.lstUnidadDespacho = [];
    this.unidadDespachoSeleccionado = "";
    //this.cargarUnidadesDespacho();
  }
  seleccionarAduana(objSeleccionado) {
    this.aduanaSeleccionada = objSeleccionado.target.value;
    this.lstUnidadDespacho = [];
    this.lstTurnos = [];
    this.lstAnfora = [];
    this.unidadDespachoSeleccionado = "";
    this.turnoSeleccionado = "";
    this.anforaSeleccionada = "";
    if (objSeleccionado.target.value != "") {
      this.objAduanaSeleccionada = this.lstAduanas.find(element => element.cod_datacat == objSeleccionado.target.value);
      this.cargarUnidadesDespacho();
    }
  }
  cargarUnidadesDespacho() {
    let campos: string = "numUnidadDespacho,nombre";
    this.unidadDespachoService.listarUnidadesDespacho(this.aduanaSeleccionada,
                                                      ConstantesCadenas.ESTADO_VIGENTE,
                                                      campos).subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.lstUnidadDespacho = result as Unidaddespacho[];
      if (this.aduanaSeleccionada != "" && FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstUnidadDespacho)) {
      //this.lstUnidadDespacho != null && this.lstUnidadDespacho != undefined && this.lstUnidadDespacho.length > 0) {
        this.lstUnidadDespacho = this.lstUnidadDespacho.sort(FuncionesGenerales.getInstance().ordenarPor("numUnidadDespacho", false));
        let defaultUD = this.lstUnidadDespacho[0].numUnidadDespacho;
        this.unidadDespachoSeleccionado = defaultUD.toString();
        this.objUnidadDespachoSeleccionado = this.lstUnidadDespacho.find(element => element.numUnidadDespacho == defaultUD);
        this.cargarAnforas();
        this.cargarTurnos();
      } else {
        this.lstUnidadDespacho = [];
        this.lstTurnos = [];
        this.lstAnfora = [];
        this.unidadDespachoSeleccionado = "";
        this.turnoSeleccionado = "";
        this.anforaSeleccionada = "";
        let errorMensaje: string = "No existen unidades de despacho asignadas a la Aduana " + this.objAduanaSeleccionada.des_corta;
        let tituloErrores: string = "Mensajes de Advertencia: ";
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA,tituloErrores, errorMensaje, "");
     }
    }, error => console.error(error));
  }
  seleccionarUnidadDespacho(objSeleccionado) {
    this.unidadDespachoSeleccionado = objSeleccionado.target.value;
    this.lstTurnos = [];
    this.lstAnfora = [];
    this.turnoSeleccionado = "";
    if (objSeleccionado.target.value != "") {
      this.objUnidadDespachoSeleccionado = this.lstUnidadDespacho.find(element => element.numUnidadDespacho == objSeleccionado.target.value);
      this.cargarAnforas();
      this.cargarTurnos();
    }
  }
  cargarAnforas() {
    this.lstHorarios = [];
    this.horarioSeleccionado = "";
    this.lstAnfora = [];
    this.anforaSeleccionada = "";
    this.catalogoService.listarAnforas(this.objUnidadDespachoSeleccionado.numUnidadDespacho).subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.lstAnfora = result as Datacatalogo[];
      if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstAnfora)) {
        this.objAnforaSeleccionada = this.lstAnfora[0]; //.find(element => element.cod_datacat == objSeleccionado.target.value);
        this.anforaSeleccionada = this.objAnforaSeleccionada.cod_datacat;
        this.cargarHorarios();
      } else {
        this.lstHorarios = [];
        this.horarioSeleccionado = "";
        let errorMensaje: string = "No existen anforas asociadas a la unidad de despacho " + this.objUnidadDespachoSeleccionado.descripcion;
        let tituloErrores: string = "Mensajes de Advertencia: ";
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA,tituloErrores, errorMensaje, "");
      }
    }, error => console.error(error));
  }
  cargarTurnos(fechaVigenteDesde?: Date) {
    let campos: string = "numTurno,nombre,hraInicio,hraFin";
    this.turnoService.listarTurnos(this.unidadDespachoSeleccionado,ConstantesCadenas.ESTADO_VIGENTE,
                                   fechaVigenteDesde != undefined || fechaVigenteDesde != null ? FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(fechaVigenteDesde) : "",
                                   fechaVigenteDesde != undefined || fechaVigenteDesde != null ? FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(fechaVigenteDesde) : "",
                                   campos, "X").subscribe(result =>{
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.lstTurnos = result as Turno[];
      if (this.unidadDespachoSeleccionado != "" && FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstTurnos)) {
        //this.lstTurnos != null && this.lstTurnos != undefined && this.lstTurnos.length > 0) {
        this.lstTurnos = this.lstTurnos.sort(FuncionesGenerales.getInstance().ordenarPor("numTurno", false));
        let turnoCombo = this.lstTurnos[0].numTurno;
        this.turnoSeleccionado = turnoCombo.toString();
        this.objTurnoSeleccionado = this.lstTurnos.find(element => element.numTurno == turnoCombo);
        this.cargarHorarios();
      } else {
        this.lstHorarios = [];
        this.horarioSeleccionado = "";
        let errorMensaje: string = "No existen turnos asociados a la unidad de despacho " + this.objUnidadDespachoSeleccionado.descripcion;
        let tituloErrores: string = "Mensajes de Advertencia: ";
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA,tituloErrores, errorMensaje, "");
      }
    }, error => console.error(error));
  }
  seleccionarTurno(objSeleccionado){
    this.turnoSeleccionado=objSeleccionado.target.value;
    this.lstHorarios = [];
    this.horarioSeleccionado = "";
    if (objSeleccionado.target.value != "") {
      this.objTurnoSeleccionado = this.lstTurnos.find(element => element.numTurno == objSeleccionado.target.value);
      this.cargarHorarios();
    }
  }
  seleccionarAnfora(objSeleccionado) {
    this.anforaSeleccionada = objSeleccionado.target.value;
    this.lstHorarios = [];
    this.horarioSeleccionado = "";
    if (objSeleccionado.target.value != "") {
      this.objAnforaSeleccionada = this.lstAnfora.find(element => element.cod_datacat == objSeleccionado.target.value);
      this.cargarHorarios();
    }
  }
  seleccionarHorario(objSeleccionado) {
    this.horarioSeleccionado = objSeleccionado.target.value;
    if (objSeleccionado.target.value != "") {
      this.objHorarioSeleccionado = this.lstHorarios.find(element => (element.sorteo.numeroSorteo+"-"+element.numSecHorario) == objSeleccionado.target.value);
    }
  }
  seleccionarPaquete(objSeleccionado:TmpPaquete){
    this.objTmpPaqueteSeleccionado = this.lstDetallesPaquetes.find(element => element.numPaquete == objSeleccionado.numPaquete);
    if (this.objTmpPaqueteSeleccionado != undefined) {
      this.txtNumSecPaquete = this.objTmpPaqueteSeleccionado.numeroSecuenciaPaqueteAnfora;
      this.txtCantidadDeclaraciones = this.objTmpPaqueteSeleccionado.listaDuasAnfora != undefined ? this.objTmpPaqueteSeleccionado.listaDuasAnfora.length : 0;
      if (this.objTmpPaqueteSeleccionado.listaDuasAnfora != undefined && this.objTmpPaqueteSeleccionado.listaDuasAnfora.length > 0) {
        this.txtTotalCargaLaboralPaquete = ""+this.objTmpPaqueteSeleccionado.listaDuasAnfora.reduce((acc,obj,)=> acc + obj.numeroCargaLaboral, 0);
        this.txtTotalCargaLaboralPaquete = parseFloat(this.txtTotalCargaLaboralPaquete).toFixed(1);
      } else {
        this.txtTotalCargaLaboralPaquete="0";
      }
    }
  }
  changeFechaPaquete() {
    this.lstHorarios = [];
    this.horarioSeleccionado = "";
    this.lstTurnos = [];
    this.turnoSeleccionado = "";
    this.cargarTurnos(this.fechaVigenteDesde);
    this.cargarHorarios();
  }
  cargarHorarios() {
    if (this.anforaSeleccionada != "" && this.turnoSeleccionado != "" && this.fechaVigenteDesde != undefined){
      this.horarioService.obtenerhorarios(this.anforaSeleccionada,this.turnoSeleccionado,this.fechaVigenteDesde, 1, this.fechaVigenteDesde).subscribe(result=>{
        FuncionesGenerales.getInstance().cerrarModalCargando();
        this.lstHorarios = result as Horariosorteo[];
        if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstHorarios)) {
          this.lstHorarios = this.lstHorarios.sort(FuncionesGenerales.getInstance().ordenarPor("horaCorte", false));
          let horarioCombo = this.lstHorarios[0].sorteo.numeroSorteo || this.lstHorarios[0].numSecHorario;
          this.horarioSeleccionado = horarioCombo.toString();
          this.objHorarioSeleccionado = this.lstHorarios.find(element => (element.sorteo.numeroSorteo || element.numSecHorario || '') == horarioCombo);
        } else {
          this.lstHorarios = [];
          this.horarioSeleccionado = "";
          let errorMensaje: string = "No existen horarios asociados al turno, ánfora y fecha seleccionados";
          let tituloErrores: string = "Mensajes de Advertencia: ";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA,tituloErrores, errorMensaje, "");
        }
      }, error => console.error(error));
    }
  }
  validarParametrosDeConsulta() {
    let tituloErrores: string = "Mensajes de Error: ";
    let esValido: boolean = false;
    if (this.aduanaSeleccionada == "") {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_DIECISIETE, "");
      return false;
    }
    if (this.fechaVigenteDesde == undefined) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_OCHO, "");
      return false;
    }
    if (!FuncionesGenerales.getInstance().esFechaValida(
         FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteDesde),
                                                        ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO)) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_NUEVE, "");
      return false;
    }
    /*if (this.unidadDespachoSeleccionado == "") {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_DIECINUEVE, "");
      return false;
    }
    if (this.turnoSeleccionado == "") {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_VEINTIUNO, "");
      return false;
    }

    if (this.horarioSeleccionado == "") {
      let errorMensaje: string = "No existen horarios asociados al turno, ánfora y fecha seleccionados";
      let tituloErrores: string = "Mensajes de Advertencia: ";
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA,tituloErrores, errorMensaje, "");
      return false;
    }*/

    esValido = true;
    return esValido;
  }
  cargarMensajesOptimizacionPaquetes(responseManager: ResponseManager) {
    if (responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO ||
        responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                   "Mensajes de Error: ",
                                                                    "",
                                                                    FuncionesGenerales.getInstance().mostrarTablaDeErrores(this.responseManager.errors));
    }
  }
  limpiarOptimizacionPaquetes(){
    this.ngOnInit();
  }
  consultarPaquetes(){
    if (!this.validarParametrosDeConsulta()) {
      return false;
    }
    this.consultarDeclaracionesPaquetesRFU();
    this.fechaPaqueteStr = ("00" + this.fechaVigenteDesde.getDate()).slice(-2) + "/" +
                           ("00" + (this.fechaVigenteDesde.getMonth() + 1)).slice(-2) + "/" +
                            this.fechaVigenteDesde.getFullYear();
    this.txtAduana = this.objAduanaSeleccionada.cod_datacat + " - " + this.objAduanaSeleccionada.des_corta;
    //this.txtFechaHoraCorte = this.fechaPaqueteStr + " " + this.funcionesGenerales.darFormatoAMPM(this.objHorarioSeleccionado.horaCorte);
    //this.txtFechaHoraSorteo = this.fechaPaqueteStr + " " + this.funcionesGenerales.darFormatoAMPM(this.objHorarioSeleccionado.horaSorteo);
    //this.txtAnfora = this.objAnforaSeleccionada.des_corta;
    this.txtFechaformacionPaquete = this.fechaPaqueteStr;
  }
  consultarDeclaracionesPaquetesRFU() {
    this.numeroSecuenciaPaqueteMaximo = 0;
    this.tmpPaqueteService.obtenerDetallesPaquetesRFU(
      this.aduanaSeleccionada,
      this.fechaVigenteDesde,
      5,
      this.fechaVigenteDesde,
      '', '', '',0
    ).subscribe(response => {
      this.lstDetallesPaquetes = response as TmpPaquete[];
      if(this.lstDetallesPaquetes.length <= 0){
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA, ConstantesExcepciones.DEFAULT_TITTLE_EXCEPTION, "No se encontraron paquetes", "");
      }else{
        FuncionesGenerales.getInstance().cerrarModalCargando();
        this.deshabilitarParametrosBuqueda = true;
        this.hayParametrosDeBusqueda=false;
        this.hayPaquetes = true;
        this.lstDetallesPaquetes = response;
        this.lstDetallesPaquetes.sort((n1,n2)=>{return n1.numeroSecuenciaPaqueteAnfora-n2.numeroSecuenciaPaqueteAnfora});
        this.lstDetallesPaquetes.forEach(x=>{
          this.numeroSecuenciaPaqueteMaximo = x.numeroSecuenciaPaqueteAnfora > this.numeroSecuenciaPaqueteMaximo && x.numeroSecuenciaPaqueteAnfora != 1000 ? x.numeroSecuenciaPaqueteAnfora : this.numeroSecuenciaPaqueteMaximo;
          if(x.listaDuasAnfora!=undefined && x.listaDuasAnfora.length>0)
          {
            x.cargaLaboralPaquete=x.listaDuasAnfora.reduce((acc,obj,)=>acc+obj.numeroCargaLaboral,0);
            x.allSelected=false;
            x.anforaDS=new MatTableDataSource<Anfora>(x.listaDuasAnfora);
          }
          x.selection = new SelectionModel<Anfora>(true, []);
        });

        this.txtTotalCargaLaboralAsignada = ""+this.lstDetallesPaquetes.reduce(
          (acc,obj,) => acc + (obj.numPaquete == 0 || obj.cargaLaboralPaquete == undefined || obj.cargaLaboralPaquete == null ? 0 : obj.cargaLaboralPaquete), 0
        );

        this.txtTotalPaquetes = this.validarTotalPaquetes(this.lstDetallesPaquetes);
        this.displayedColumns = ConstantesListas.COLUMNAS_GRID_DECLARACIONES;
        this.selection = new SelectionModel<Anfora>(true, []);
        this.anforaDS=new MatTableDataSource<Anfora>(this.anforasSinAsignar);
      }
    },
    errorResult => {
      this.deshabilitarParametrosBuqueda = false;
      if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
        let responseManager: ResponseManager = new ResponseManager();
        this.responseErrorManager = errorResult as ResponseErrorManager;
        responseManager.cod = errorResult.cod;
        responseManager.errors = [this.responseErrorManager];
        this.responseManager = responseManager;
        this.cargarMensajesOptimizacionPaquetes(this.responseManager);
      } else {
        this.responseManager = errorResult as ResponseManager;
        this.cargarMensajesOptimizacionPaquetes(this.responseManager);
      }
    });
  }

  validarTotalPaquetes(lstDetallesPaquetes: TmpPaquete[]) {
    let totalPaquetes: number = 0;
    for (let i = 0; i < lstDetallesPaquetes.length; i++) {
      if (lstDetallesPaquetes[i].numPaquete != 0) {
        totalPaquetes++;
      }
    }
    return totalPaquetes;
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.anforasSinAsignar.length;
    return numSelected === numRows;
  }
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.anforasSinAsignar.forEach(row => this.selection.select(row));
  }

  callback = () : void => {
      this.ngOnInit();
  };

  grabarOptimizacion(){
    let lstListaGrabar:TmpPaquete[];
    let paqueteGrabar:TmpPaquete = new TmpPaquete();
    lstListaGrabar = [];

    let lstTmpPaqueteDetalle: TmpPaquete[] = FuncionesGenerales.getInstance().clonarObjeto(this.lstDetallesPaquetes, "anforaDS", "selection");

    lstTmpPaqueteDetalle.map(
      x => {
        if(x.numPaquete != 0 && x.listaDuasAnfora.length!=undefined && x.listaDuasAnfora.length>0) {
          //x.sorteo=this.objHorarioSeleccionado.sorteo;
          //x.sorteo.detalleSorteo=new Horariosorteo();
          //x.sorteo.detalleSorteo.numSecHorario=this.objHorarioSeleccionado.numSecHorario;
          x.fecPP=this.fechaVigenteDesde;
          paqueteGrabar=x;
          paqueteGrabar.anforaDS=undefined;
          lstListaGrabar.push(paqueteGrabar);
        }
      }
    )
    let fechaFormacionPaqueteStr:string = this.fechaVigenteDesde.getFullYear() +"-"+
                                          ("00" + (this.fechaVigenteDesde.getMonth() + 1)).slice(-2) + "-" +
                                          ("00" + this.fechaVigenteDesde.getDate()).slice(-2);

    this.tmpPaqueteService.registrarOptimizacionPaquetesRFU(
      this.aduanaSeleccionada,
      fechaFormacionPaqueteStr,
      lstListaGrabar).subscribe(
      response => {
        console.log(response);
        FuncionesGenerales.getInstance().cerrarModalCargando();
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(
          ConstantesCadenas.MENSAJE_EXITOSO,
          "La Optimización de paquetes de RFU se grabó correctamente", "", "", this.callback);
      },
      errorResult => {
        if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
          let responseManager: ResponseManager = new ResponseManager();
          this.responseErrorManager = errorResult as ResponseErrorManager;
          responseManager.cod = errorResult.cod;
          responseManager.errors = [this.responseErrorManager];
          this.responseManager = responseManager;
        } else {
          this.responseManager = errorResult as ResponseManager;
        }
        if (this.responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO ||
            this.responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
              FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                       "Mensajes de Error: ",
                                                                        "",
                                                                        FuncionesGenerales.getInstance().mostrarTablaDeErrores(this.responseManager.errors));
        }
      }
    );
  }
  movDerecha(){
    this.lstDetallesPaquetes.map(x=>{
      if(x.listaDuasAnfora!=undefined && x.listaDuasAnfora.length>0){
        let listaMoverPaquete:Anfora[]=[];
        x.listaDuasAnfora.map(dua=>{
          if(x.selection.isSelected(dua))
          {
            listaMoverPaquete.push(dua);
          }
        });
        listaMoverPaquete.map(dua=>{
          this.anforasSinAsignar.push(dua);
            x.listaDuasAnfora.splice(x.listaDuasAnfora.indexOf(dua),1);
        });
        x.anforaDS=new MatTableDataSource<Anfora>(x.listaDuasAnfora);
        x.selection = new SelectionModel<Anfora>(true, []);
      }
    });
    this.anforaDS=new MatTableDataSource<Anfora>(this.anforasSinAsignar);
    this.selection = new SelectionModel<Anfora>(true, []);
    this.seleccionarPaquete(this.objTmpPaqueteSeleccionado);

    this.txtTotalCargaLaboralAsignada = "" + this.validarTotalCargaLaboral(this.lstDetallesPaquetes);
    this.txtTotalCargaLaboralAsignada = parseFloat(this.txtTotalCargaLaboralAsignada).toFixed(1);
  }
  movIzquierda(){
    if(this.anforasSinAsignar!=undefined && this.anforasSinAsignar.length>0){
      let cantSel:number=0;
      let listaMoverPaquete:Anfora[]=[];
      this.anforasSinAsignar.map(
        x=>{
          if(this.selection.isSelected(x))
          {
            cantSel=cantSel+1;
            listaMoverPaquete.push(x);
            
          }
        }
      );
      if(cantSel>0){
        listaMoverPaquete.map(
          x=>{
              this.objTmpPaqueteSeleccionado.listaDuasAnfora.push(x);
              this.anforasSinAsignar.splice(this.anforasSinAsignar.indexOf(x),1);
          }
        );
        this.lstDetallesPaquetes.map(x=>{
          if(x.numPaquete==this.objTmpPaqueteSeleccionado.numPaquete)
          {
            x.listaDuasAnfora=this.objTmpPaqueteSeleccionado.listaDuasAnfora;
            x.selection = new SelectionModel<Anfora>(true, []);
            x.anforaDS=new MatTableDataSource<Anfora>(x.listaDuasAnfora);
          }
        });
        this.anforaDS=new MatTableDataSource<Anfora>(this.anforasSinAsignar);
        this.selection = new SelectionModel<Anfora>(true, []);
        this.seleccionarPaquete(this.objTmpPaqueteSeleccionado);

        this.txtTotalCargaLaboralAsignada = "" + this.validarTotalCargaLaboral(this.lstDetallesPaquetes);
        this.txtTotalCargaLaboralAsignada = parseFloat(this.txtTotalCargaLaboralAsignada).toFixed(1);
      }else{
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA,
          "Mensaje de Advertencia", "Seleccione Declaraciones", "");
      }
     
    }
    else{
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA,
        "Mensaje de Advertencia", "Seleccione Declaraciones", "");
    }
  }

  movIzquierdaRFU(){
    let esValido: boolean = false;
    let mensajeError: String = "";
    let modals = [];
    if(this.anforasSinAsignar!=undefined && this.anforasSinAsignar.length>0){
      let cantSel:number=0;
      let listaMoverPaquete:Anfora[]=[];
      this.anforasSinAsignar.map(
        x=>{
          if(this.selection.isSelected(x))
          {
            cantSel=cantSel+1;
            listaMoverPaquete.push(x);
            
          }
        }
      );
      if(cantSel>0){
        listaMoverPaquete.map(
        x=>{  
          mensajeError = this.validarDAMsRFU(x);
          if (mensajeError.length > 0){
            modals.push({
                title: "Mensaje de Confirmación: ",
                html: mensajeError + ".<br> ¿Desea continuar?",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                confirmButtonText: "SI",
                cancelButtonColor: '#d33',
                cancelButtonText: "NO",
                preConfirm: () => { mensajeError = this.validarDAMsRFU(x);
                                    if (mensajeError.length > 0){
                                      this.movIzquierdaIndividual(x);
                                    }   
                                  }   
              });
          } else {
            this.movIzquierdaIndividual(x);
          }
        }
      );
      Swal.queue(modals);
    } else{
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA,
        "Mensaje de Advertencia", "Seleccione Declaraciones", "");
    }
  }
  else{
    FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA,
      "Mensaje de Advertencia", "Seleccione Declaraciones", "");
  }
    
  }

  validarDAMsRFU(anfora: Anfora){
    let mensajeError: string = "";
    let numeroDeclaracionCompleto: string = anfora.cabDeclara.aduana.codDatacat+"-"+
                                            anfora.cabDeclara.annPresen+"-"+
                                            anfora.cabDeclara.regimen.codDatacat+"-"+
                                            anfora.cabDeclara.numDeclaracion;
    if (this.objTmpPaqueteSeleccionado.zona !=null && this.objTmpPaqueteSeleccionado.zona.numZona != anfora.numZona){
      mensajeError += "Almacén de la declaración "+numeroDeclaracionCompleto+" no pertenece a la misma \nzona que el paquete destino";
    }
    //La DAM se mueve a al grupo sin empaquetar, pero tiene numero de paquete de régimen
    if (this.objTmpPaqueteSeleccionado.numPaquete == 0 && anfora.numeroPaquete != null && anfora.numeroPaquete > 0){
      mensajeError +=  "<br>Declaración "+numeroDeclaracionCompleto+" no tiene paquete RFU pero si tiene paquete de régimen";
    }
    //Si la DAM se mueve a un paquete de RFU y no tiene número de paquete de régimen
    if (this.objTmpPaqueteSeleccionado.numPaquete != 0 && anfora.numeroPaquete == null ){
      mensajeError +=   "<br>Declaración "+numeroDeclaracionCompleto+" no tiene paquete de régimen pero si tiene paquete de RFU" ;
    }
    
    return mensajeError;
  }

  movIzquierdaIndividual(anfora: Anfora){
    
    this.objTmpPaqueteSeleccionado.listaDuasAnfora.push(anfora);
    this.anforasSinAsignar.splice(this.anforasSinAsignar.indexOf(anfora),1);
    this.lstDetallesPaquetes.map(x=>{
      if(x.numPaquete==this.objTmpPaqueteSeleccionado.numPaquete)
      {
        x.listaDuasAnfora=this.objTmpPaqueteSeleccionado.listaDuasAnfora;
        x.selection = new SelectionModel<Anfora>(true, []);
        x.anforaDS=new MatTableDataSource<Anfora>(x.listaDuasAnfora);
      }
    });
    this.anforaDS=new MatTableDataSource<Anfora>(this.anforasSinAsignar);
    this.selection = new SelectionModel<Anfora>(true, []);
    this.seleccionarPaquete(this.objTmpPaqueteSeleccionado);

    this.txtTotalCargaLaboralAsignada = "" + this.validarTotalCargaLaboral(this.lstDetallesPaquetes);
    this.txtTotalCargaLaboralAsignada = parseFloat(this.txtTotalCargaLaboralAsignada).toFixed(1);
  }

  nuevoPaquete(){
    let nuevoPaquete:TmpPaquete=new TmpPaquete();
    let listaMoverPaquete:Anfora[]=[];
    let newZona:Zona = new Zona();
    nuevoPaquete.numPaquete=this.idNuevoPaquete;
    nuevoPaquete.allSelected=false;
    this.numeroSecuenciaPaqueteMaximo++;
    nuevoPaquete.numeroSecuenciaPaqueteAnfora = this.numeroSecuenciaPaqueteMaximo;
    nuevoPaquete.listaDuasAnfora=[];
    nuevoPaquete.selection = new SelectionModel<Anfora>(true, []);
    this.anforasSinAsignar.map(x=>{
      if(this.selection.isSelected(x))
      {
        listaMoverPaquete.push(x);
      }
    });
    if(listaMoverPaquete.length!=undefined && listaMoverPaquete.length>0)
    {
      listaMoverPaquete.map(dua=>{
        nuevoPaquete.listaDuasAnfora.push(dua);
        this.anforasSinAsignar.splice(this.anforasSinAsignar.indexOf(dua),1);
      });
    }
    nuevoPaquete.anforaDS=new MatTableDataSource<Anfora>(nuevoPaquete.listaDuasAnfora);
    nuevoPaquete.zona = newZona;
    nuevoPaquete.zona.numZona = 0;
    nuevoPaquete.zona.nombre=" ";
    this.lstDetallesPaquetes.push(nuevoPaquete);
    this.lstDetallesPaquetes.sort((p1,p2)=>{return p1.numeroSecuenciaPaqueteAnfora-p2.numeroSecuenciaPaqueteAnfora});
    this.anforaDS=new MatTableDataSource<Anfora>(this.anforasSinAsignar);
    this.selection = new SelectionModel<Anfora>(true, []);
    this.idNuevoPaquete=this.idNuevoPaquete-1;

    this.txtTotalCargaLaboralAsignada = "" + this.validarTotalCargaLaboral(this.lstDetallesPaquetes);
    this.txtTotalCargaLaboralAsignada = parseFloat(this.txtTotalCargaLaboralAsignada).toFixed(1);

    this.txtTotalPaquetes = this.validarTotalPaquetes(this.lstDetallesPaquetes);
  }

  validarTotalCargaLaboral(lstDetallesPaquetes: TmpPaquete[]) {
    let totalCargaLaboral: number = 0;
    for (let paquete of lstDetallesPaquetes) {
      if (paquete.numPaquete != null && paquete.numPaquete != undefined &&
          paquete.numPaquete <= -1 || paquete.numPaquete > 0
        ) {
          if (paquete.listaDuasAnfora.length > 0) {
            for (let dua of paquete.listaDuasAnfora) {
              totalCargaLaboral += dua.numeroCargaLaboral;
            }
          }
      }
    }
    return totalCargaLaboral;
  }
}
