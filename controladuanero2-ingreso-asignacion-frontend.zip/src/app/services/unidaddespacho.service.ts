import { Injectable } from '@angular/core';
import { Unidaddespacho } from '../models/unidaddespacho';
import { ConstantesRest } from '../utils/constantesrest';
import { Datacatalogo } from '../models/datacatalogo';
import { FuncionesGenerales } from '../utils/funcionesgenerales';
import { Observable, throwError } from 'rxjs';
import { ResponseManager } from '../models/responsemanager';
import { catchError } from 'rxjs/operators';
import { HttpClient, HttpResponse } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})

export class UnidaddespachoService {
  unidadDespachoSubmitter: Unidaddespacho;
  responseManager: ResponseManager;
  constructor(private http: HttpClient) {
    this.unidadDespachoSubmitter = new Unidaddespacho();
    this.unidadDespachoSubmitter.aduana = new Datacatalogo();
    this.responseManager = new ResponseManager();
  }

  obtenerRegimenesPorCodDataCat(regimenes: Datacatalogo[]) {
    let regimenesResult: Datacatalogo[] = [];
    let regimen: Datacatalogo;
    for (let i = 0; i < regimenes.length; i++) {
      regimen = new Datacatalogo();
      regimen.codDatacat = regimenes[i].cod_datacat;
      regimenesResult.push(regimen);
    }
    return regimenesResult;
  }

  registrarActualizarUnidadDespacho(unidaddespacho: Unidaddespacho, tk: string) : Observable<any> {
    this.unidadDespachoSubmitter.aduana.codDatacat = unidaddespacho.aduana.cod_datacat;
    this.unidadDespachoSubmitter.fecInicioVigencia = unidaddespacho.fecInicioVigencia;
    this.unidadDespachoSubmitter.fecFinVigencia = unidaddespacho.fecFinVigencia;
    this.unidadDespachoSubmitter.descripcion = unidaddespacho.descripcion;
    this.unidadDespachoSubmitter.numUnidadDespacho = unidaddespacho.numUnidadDespacho;
    this.unidadDespachoSubmitter.indSorteoFuncionarioZona = unidaddespacho.indSorteoFuncionarioZona;
    this.unidadDespachoSubmitter.regimenes = this.obtenerRegimenesPorCodDataCat(unidaddespacho.regimenes);
    /*return this.http.get<HttpResponse<Object>>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_GRABAR_UNIDAD_DESPACHO + "&paramBody={2}",
                                                                                                     "1",
                                                                                                     tk, JSON.stringify(this.unidadDespachoSubmitter))).pipe(
        catchError(e => {
          return throwError(e.error);
        })
      );*/
    return this.http.post<HttpResponse<Object>>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_GRABAR_UNIDAD_DESPACHO, "1", tk),
      this.unidadDespachoSubmitter, { observe: 'response' }).pipe(
        catchError(e => {
          return throwError(e.error);
        })
      );
  }

  validarServicioUnidadDespacho(unidaddespacho: Unidaddespacho) : Observable<ResponseManager> {
    return this.http.get<ResponseManager>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_VALIDAR_UNIDAD_DESPACHO,
                                                                               unidaddespacho.numUnidadDespacho,
                                                                               unidaddespacho.aduana.cod_datacat,
                                                                               unidaddespacho.descripcion,
                                                                               unidaddespacho.indSorteoFuncionarioZona,
                                                                               FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(unidaddespacho.fecInicioVigencia),
                                                                               FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(unidaddespacho.fecFinVigencia),
                                                                               unidaddespacho.regimenes.map(x => x.cod_datacat).toString())).pipe(
      catchError(e => {
        return throwError(e);
      })
    );
  }

  listarUnidadesDespacho(aduanaSeleccionada: string,
                         estadoSeleccionado: string,
                         campos: string) {
    return this.http.get<Unidaddespacho[]>(FuncionesGenerales.getInstance().reemplazarParametros(
        ConstantesRest.URL_LISTAR_UNIDAD_DESPACHO,
        aduanaSeleccionada,
        estadoSeleccionado,
        campos));
  }

}
