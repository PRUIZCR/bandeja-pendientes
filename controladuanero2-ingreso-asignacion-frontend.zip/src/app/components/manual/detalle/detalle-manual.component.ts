import { Component, OnInit, ViewChild } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { RespuestaInformacionOperacionManual } from 'src/app/models/respuestainformacionoperacionmanual';
import { DetalleInformacionOperacionManual } from 'src/app/models/detalleinformacionoperacionmanual';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { CatEmpleadoService } from 'src/app/services/catempleado.service';
import { CatEmpleado } from 'src/app/models/catempleado';
import { ConsultaSeleccionfuncionariosComponent } from '../../seleccionfuncionarios/consulta/consulta-seleccionfuncionarios.component';
import { Observable } from 'rxjs/Observable';
import { ManualService } from 'src/app/services/manual.service';
import { Datacatalogo } from 'src/app/models/datacatalogo';
import { ServicioRest } from 'src/app/models/serviciorest';
import { DatosRegistroOperacionManual } from 'src/app/models/datosregistrooperacionmanual';
import { Subject } from 'rxjs/Subject';
import { UnidadSeleccionDAM } from 'src/app/models/unidadselecciondam';
import { FuncionarioAnteriorRF } from 'src/app/models/funcionarioanteriorrf';

@Component({
  selector: 'app-detalle-manual',
  templateUrl: './detalle-manual.component.html',
  styleUrls: ['./detalle-manual.component.css']
})

export class DetalleManualComponent implements OnInit {
  @ViewChild('childModal') childModal: ModalDirective;
  @ViewChild(ConsultaSeleccionfuncionariosComponent) child: ConsultaSeleccionfuncionariosComponent;
  elementosLabel: DetalleInformacionOperacionManual[];
  elementosComboBox: DetalleInformacionOperacionManual[];
  elementosCheck: DetalleInformacionOperacionManual[];
  elementoHidden: DetalleInformacionOperacionManual[];
  estadoOperacion$: Observable<CatEmpleado>;
  private estadoAsignacion$ = new Subject<string>();
  titulo: string;
  txtObservacion: string;
  esObsEditable: boolean;
  registroFuncionario: string;
  apellidosNombresFuncionario: string;
  desabilitarCriterioRegistro: boolean;
  desabilitarCriterioAP: boolean;
  paramAduana: string;
  paramRegimen: string;
  paramAnio: number;
  paramNumero: number;
  empleadoSeleccionado: CatEmpleado;
  objOperacion: Datacatalogo;
  funcionarioDeshabilitado: boolean;
  codGrupoTrabajo: string;
  codUnidadSeleccion: string;
  esAsignacionRF: boolean;
  esReasignacionRF: boolean;
  esFuncionarioAnteriorRF: boolean;
  esAsignacionDSEERRectificacion: boolean;
  catEmpleadoHidden: CatEmpleado;
  funcionarioAnteriorRF: string;
  esModuloAsignacion: boolean;
  listFuncionariosAnteriores: FuncionarioAnteriorRF[];
  aduanaAsignada: string;
  unidadSeleccionDAM: UnidadSeleccionDAM;
  lstAduanasFuncionario: string[];
  indFuncionarioExistente: string;
  //PAS20221U220200001
  esAsignacionRFU: boolean;
  esReasignacionRFU: boolean;

  constructor(private manualService: ManualService, private catEmpleadoService: CatEmpleadoService) { }

  ngOnInit() {
    this.catEmpleadoHidden = new CatEmpleado();
    this.indFuncionarioExistente = "0";
    this.lstAduanasFuncionario = [];
    this.aduanaAsignada = "";
    this.esFuncionarioAnteriorRF = false;
    this.desabilitarCriterioRegistro = false;
    this.desabilitarCriterioAP = false;
    this.estadoOperacion$ = this.child.getEstadoOperacion$();
    this.estadoOperacion$.subscribe(x => {
      if (x != null && Object.entries(x).length != 0) {
        this.empleadoSeleccionado = x as CatEmpleado;
        this.apellidosNombresFuncionario = this.empleadoSeleccionado.apPate.trim().toUpperCase() + " " + this.empleadoSeleccionado.apMate.trim().toUpperCase() + " " + this.empleadoSeleccionado.nombres.trim().toUpperCase();
        this.registroFuncionario = this.empleadoSeleccionado.codPers.toUpperCase();
        this.desabilitarCriterioRegistro = true;
      } else {
        this.empleadoSeleccionado = null;
      }
     }
   );
  }

  abrirModal(respuesta: RespuestaInformacionOperacionManual, tituloModal: string, aduana: string, regimen: string, anio: number, numero: number, operacion: Datacatalogo, aduanasFuncionario: string[]){
    this.esAsignacionRF = false;
    this.esReasignacionRF = false;
    //PAS20221U220200001
    this.esAsignacionRFU = false;
    this.esReasignacionRFU = false;
    this.esFuncionarioAnteriorRF = false;
    this.esAsignacionDSEERRectificacion = false;
    this.aduanaAsignada = "";
    let tituloErrores: string = "Mensajes de Error: ";
    let errorMensaje: string = "";
    this.lstAduanasFuncionario = FuncionesGenerales.getInstance().clonarObjeto(aduanasFuncionario);
    this.esModuloAsignacion = sessionStorage.getItem('pagina') == 'asignacion-manual';
    this.titulo = tituloModal.toUpperCase();
    this.elementosLabel = respuesta.detalles.filter(param => (param.tipoControl == ConstantesCadenas.RESPUESTA_INFORMACION_OPERACION_MANUAL_TIPO_LABEL));
    this.elementosCheck = respuesta.detalles.filter(param => (param.tipoControl == ConstantesCadenas.RESPUESTA_INFORMACION_OPERACION_MANUAL_TIPO_CHECK));
    this.elementosComboBox = respuesta.detalles.filter(param => (param.tipoControl == ConstantesCadenas.RESPUESTA_INFORMACION_OPERACION_MANUAL_TIPO_COMBOBOX));
    this.elementoHidden = respuesta.detalles.filter(param => (param.tipoControl == ConstantesCadenas.RESPUESTA_INFORMACION_OPERACION_MANUAL_TIPO_HIDDEN));

    let elementosTexto: DetalleInformacionOperacionManual[] = respuesta.detalles.filter(param => (param.tipoControl == ConstantesCadenas.RESPUESTA_INFORMACION_OPERACION_MANUAL_TIPO_TEXTBOX));
    this.txtObservacion = respuesta.txtObservacion;
    this.esObsEditable = respuesta.indObsEditable == ConstantesCadenas.ESTADO_ACTIVO;
    this.paramAduana = aduana;
    this.paramRegimen = regimen;
    this.paramAnio = anio;
    this.paramNumero = numero;
    this.registroFuncionario = '';
    this.apellidosNombresFuncionario = '';
    this.objOperacion = operacion;

    if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.elementosComboBox)) {
       if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.elementosComboBox[0].lista))
         this.codGrupoTrabajo = this.elementosComboBox[0].lista[0].value;
    }
	  let noMostrarModal: boolean = true;
    this.esAsignacionRF = ConstantesCadenas.REGIMEN_EXPORTACION == regimen && ConstantesCadenas.TIPO_ASIGNACION_INDIVIDUAL_SOLICITUD_RECONOCIMIENTO_FISICO == this.objOperacion.cod_datacat;
    this.esReasignacionRF = ConstantesCadenas.REGIMEN_EXPORTACION == regimen && ConstantesCadenas.TIPO_REASIGNACION_INDIVIDUAL_SOLICITUD_RECONOCIMIENTO_FISICO == this.objOperacion.cod_datacat;
    //PAS20221U220200001
    this.esAsignacionRFU = ConstantesCadenas.REGIMEN_EXPORTACION == regimen && ConstantesCadenas.TIPO_ASIGNACION_INDIVIDUAL_DILIGENCIA_RFU == this.objOperacion.cod_datacat;
    this.esReasignacionRFU = ConstantesCadenas.REGIMEN_EXPORTACION == regimen && ConstantesCadenas.TIPO_REASIGNACION_INDIVIDUAL_DILIGENCIA_RFU == this.objOperacion.cod_datacat;

    this.esAsignacionDSEERRectificacion = ConstantesCadenas.REGIMEN_EER == regimen && ConstantesCadenas.TIPO_ASIGNACION_INDIVIDUAL_SOLICITUD_RECTIFICACION_DSEER_EVALUACION == this.objOperacion.cod_datacat;

    if (this.esAsignacionDSEERRectificacion) {
      if (this.elementoHidden[0].objeto.catEmpleadoCabDeclara != null && this.elementoHidden[0].objeto.catEmpleadoCabDeclara != undefined) {
        this.catEmpleadoHidden = JSON.parse(this.elementoHidden[0].objeto.catEmpleadoCabDeclara) as CatEmpleado;
      } else {
        this.catEmpleadoHidden = null;
      }
    }
    if (!this.esModuloAsignacion && this.esReasignacionRF) {
         this.listFuncionariosAnteriores = JSON.parse(this.elementoHidden[1].objeto.listFuncionariosAnteriores) as FuncionarioAnteriorRF[];
    }

    if (this.esReasignacionRF || this.esAsignacionRF || this.esReasignacionRFU || this.esAsignacionRFU) { //PAS20221U220200001 
      this.unidadSeleccionDAM = JSON.parse(this.elementoHidden[0].objeto.unidadSeleccion) as UnidadSeleccionDAM;
    }

    if (this.esAsignacionRF) { 
  		if (this.unidadSeleccionDAM.asignada) {
  			noMostrarModal = false;
  			errorMensaje = "La solicitud de reconocimiento físico ya cuenta con un funcionario asignado.";
  			FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR, tituloErrores, errorMensaje, "");
  		}
    }

    if (this.esReasignacionRF || this.esAsignacionRF || this.esReasignacionRFU || this.esAsignacionRFU) { //PAS20221U220200001
      this.aduanaAsignada = this.unidadSeleccionDAM.aduanaAsignacion;
      if (!(this.esAsignacionRF || this.esAsignacionRFU) && !this.unidadSeleccionDAM.indicadorSINI) { 
        if (!(this.esReasignacionRF || this.esReasignacionRFU) && !this.unidadSeleccionDAM.asignada) {
          this.elementosComboBox[1].lista = this.elementosComboBox[1].lista.sort(FuncionesGenerales.getInstance().ordenarPor("text", false));
          this.codUnidadSeleccion = this.elementosComboBox[1].lista[0].value;
        }
      }
      if ((this.esAsignacionRF || this.esReasignacionRF || this.esReasignacionRFU || this.esAsignacionRFU) && this.unidadSeleccionDAM.indicadorSINI) { //PAS20221U220200001
        this.codUnidadSeleccion = this.elementosComboBox[1].lista[0].value;
      }
      if (this.esReasignacionRF) this.mostrarUnidadesDeSeleccionReasignacion(this.codUnidadSeleccion);
    }

    if (respuesta.indBusquedaHabilitada == ConstantesCadenas.ESTADO_INACTIVO) {
      this.desabilitarCriterioAP = true;
      this.desabilitarCriterioRegistro = true;
    }
    if (this.esAsignacionDSEERRectificacion) {
      if (this.catEmpleadoHidden != null && this.catEmpleadoHidden != undefined) {
        this.registroFuncionario = this.catEmpleadoHidden.codPers;
        this.apellidosNombresFuncionario = this.catEmpleadoHidden.apPate.toUpperCase().trim() + ' ' +
        this.catEmpleadoHidden.apMate.toUpperCase().trim() + ' ' +
        this.catEmpleadoHidden.nombres.toUpperCase().trim();
        this.desabilitarCriterioAP = true;
        this.desabilitarCriterioRegistro = true;
        this.indFuncionarioExistente = "1";
      }
    }

    this.empleadoSeleccionado = respuesta.catEmpleado;
    this.funcionarioDeshabilitado = FuncionesGenerales.getInstance().validarListaNoVaciaONula(elementosTexto);
    if(this.funcionarioDeshabilitado){
      this.registroFuncionario = elementosTexto[0].descripcion;
      this.apellidosNombresFuncionario = elementosTexto[1].descripcion;
    }
    if (noMostrarModal) this.childModal.show();
  }

  buscarCatalogoFuncionarios() { //Se agrego por PAS20221U220200001 esAsignacionRFU y esReasignacionRFU
    let tituloErrores: string = "Mensajes de Error: ";
    let errorMensaje: string;
    if (this.registroFuncionario.trim().length == 0 && this.desabilitarCriterioAP){
      this.apellidosNombresFuncionario = "";
      this.desabilitarCriterioAP = false;
    } else if (this.apellidosNombresFuncionario.trim().length == 0 && this.desabilitarCriterioRegistro){
      this.registroFuncionario = "";
      this.desabilitarCriterioRegistro = false;
    } else if (!this.desabilitarCriterioRegistro && this.registroFuncionario.trim().length > 0){
      this.apellidosNombresFuncionario = '';
      if (!FuncionesGenerales.getInstance().validarExpresionesRegulares(this.registroFuncionario.trim(), "^[a-zA-Z0-9]+$")) {
        errorMensaje = "Valor del registro es incorrecto.";
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    tituloErrores, errorMensaje, "");
      } else if (this.registroFuncionario.trim().length != 4) {
        errorMensaje = "Código de funcionario es incorrecto.";
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR, tituloErrores, errorMensaje, "");
      } else {
        let indicadorValidacionTurno: string = "X";
        if (this.esReasignacionRF || this.esAsignacionRF || this.esReasignacionRFU || this.esAsignacionRFU) indicadorValidacionTurno = "1";
        this.catEmpleadoService.buscarCatalogoFuncionarios((this.esReasignacionRF || this.esAsignacionRF ? this.aduanaAsignada : this.paramAduana), this.registroFuncionario.trim().toUpperCase(), "", this.codGrupoTrabajo, indicadorValidacionTurno, this.paramRegimen).subscribe(response => {
            FuncionesGenerales.getInstance().cerrarModalCargando();
            let lstCatEmpleado = response as CatEmpleado[];
            if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(lstCatEmpleado)) {
              this.empleadoSeleccionado = lstCatEmpleado[0];
              this.apellidosNombresFuncionario = lstCatEmpleado[0].apPate.trim().toUpperCase() + " " + lstCatEmpleado[0].apMate.trim().toUpperCase() + " " + lstCatEmpleado[0].nombres.trim().toUpperCase();
              this.desabilitarCriterioAP = true;
            } else {
              errorMensaje = "No se encontraron funcionarios.";
              FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR, tituloErrores, errorMensaje, "");
            }
          },
        errorResult => console.error(errorResult));
      }
    } else if (!this.desabilitarCriterioAP && this.apellidosNombresFuncionario.trim().length > 0){
      this.registroFuncionario = '';
      if (!FuncionesGenerales.getInstance().validarExpresionesRegulares(this.apellidosNombresFuncionario.trim(), "^[a-zA-Z]+$")) {
        errorMensaje = "Valor de apellidos y nombres es incorrecto.";
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    tituloErrores, errorMensaje, "");
      } else if(this.apellidosNombresFuncionario.trim().length < 4){
        errorMensaje = "Debe ingresar al menos 4 caracteres.";
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR, tituloErrores, errorMensaje, "");
      } else {
        let indicadorValidacionTurno: string = "X";
        if (this.esReasignacionRF || this.esAsignacionRF || this.esReasignacionRFU || this.esAsignacionRFU) indicadorValidacionTurno = "1";
        this.catEmpleadoService.buscarCatalogoFuncionarios((this.esReasignacionRF || this.esAsignacionRF || this.esReasignacionRFU || this.esAsignacionRFU ? this.aduanaAsignada : this.paramAduana), "", this.apellidosNombresFuncionario.trim().toUpperCase(), this.codGrupoTrabajo, indicadorValidacionTurno, this.paramRegimen).subscribe(response => {
            FuncionesGenerales.getInstance().cerrarModalCargando();
            let lstCatEmpleado = response as CatEmpleado[];
            //if (lstCatEmpleado != undefined && lstCatEmpleado != null && lstCatEmpleado.length > 0) {
            if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(lstCatEmpleado)) {
              if(lstCatEmpleado.length == 1){
                this.empleadoSeleccionado = lstCatEmpleado[0];
                this.apellidosNombresFuncionario = lstCatEmpleado[0].apPate.trim().toUpperCase() + " " + lstCatEmpleado[0].apMate.trim().toUpperCase() + " " + lstCatEmpleado[0].nombres.trim().toUpperCase();
                this.registroFuncionario = lstCatEmpleado[0].codPers.toUpperCase();
                this.desabilitarCriterioRegistro = true;
              }else{
                this.child.mostrarSeleccionDeFuncionarios(lstCatEmpleado);
              }
            }else{
              errorMensaje = "No se encontraron funcionarios.";
              FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR, tituloErrores, errorMensaje, "");
            }
          },
        errorResult => console.error(errorResult));
      }
    }
  }

  cerrar(){
    this.childModal.hide();
  }

  grabar(){
    let tituloErrores: string = "Mensajes de Error: ";
    let errorMensaje: string = "";
    this.manualService.validarOperacionManual(this.objOperacion.cod_datacat, ConstantesCadenas.TIPO_SERVICIO_GRABACION).subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      if(result != null && result != undefined)
        if (this.validarAduanaAsignacionFuncionario()) {
          this.ejecutarServicioGrabacion(result as ServicioRest);
        } else {
          errorMensaje = "Aduana del funcionario aduanero no corresponde a la aduana de asignación de la DAM.";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR, tituloErrores, errorMensaje, "");
        }
      else{
        errorMensaje = "La operación no tiene asociada ningún servicio de grabación.";
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR, tituloErrores, errorMensaje, "");
      }
    }, error => console.error(error));
  }

  validarAduanaAsignacionFuncionario() {
    let noEsValido: boolean = true;
    if (this.esReasignacionRF || this.esAsignacionRF) {
      let perteneceAduanaAsignacion: boolean = false;
      for (let i = 0; i < this.lstAduanasFuncionario.length; i++) {
        if (this.unidadSeleccionDAM.aduanaAsignacion == this.lstAduanasFuncionario[i]) {
          perteneceAduanaAsignacion = true;
          break;
        }
      }
      if (!perteneceAduanaAsignacion) {
        noEsValido = false;
      }
    }
    return noEsValido;
  }

  ejecutarServicioGrabacion(servicioRest: ServicioRest){
    let datos: DatosRegistroOperacionManual = new DatosRegistroOperacionManual();
    datos.aduana = this.paramAduana;
    datos.anio = this.paramAnio;
    datos.regimen = this.paramRegimen;
    datos.numero = this.paramNumero;
    datos.observacion = this.txtObservacion;
    datos.detalles = this.elementosCheck;
    datos.grupoTrabajo = this.codGrupoTrabajo;
    datos.codTipoOperacion = this.objOperacion.cod_datacat;
    if (this.esAsignacionDSEERRectificacion) {
      datos.indFuncionarioExistente = this.indFuncionarioExistente;
      datos.catEmpleado = this.indFuncionarioExistente == '0' ? this.empleadoSeleccionado : this.catEmpleadoHidden;
    } else {
      datos.catEmpleado = this.empleadoSeleccionado;
    }
    if (this.esAsignacionRF || this.esReasignacionRF || this.esAsignacionRFU || this.esReasignacionRFU) { //PAS20221U220200001
        datos.unidadesSeleccion = FuncionesGenerales.getInstance().clonarObjeto(this.unidadSeleccionDAM, "class", "~unique-id~");
        if (this.unidadSeleccionDAM.indicadorSINI) {
          for (let i = 0; i < datos.unidadesSeleccion.unidadesSeleccion.length; i++) {
            if (datos.unidadesSeleccion.unidadesSeleccion[i].strFechaProgramacion != undefined ||
                datos.unidadesSeleccion.unidadesSeleccion[i].strFechaProgramacion != null) {
                  datos.unidadesSeleccion.unidadesSeleccion[i].fechaProgramacion = FuncionesGenerales.getInstance().convertirFormatoCadenaDiaMesAnnioADate(datos.unidadesSeleccion.unidadesSeleccion[i].strFechaProgramacion);
                }
          }
          datos.unidadSeleccionada = this.codUnidadSeleccion;
        } else {
          datos.unidadSeleccionada = "";
        }
        //Luego descomentar
        //datos.aduana = this.paramAduana;
        datos.aduanaAsignacion = this.unidadSeleccionDAM.aduanaAsignacion;
    }

  	this.manualService.ejecutarServicioRest(servicioRest, ConstantesCadenas.METHOD_HTTP_POST, datos).subscribe(
      result => {
    		FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_EXITOSO, result, "", "", this.callback);
    	  },
    	  error => {
    		FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
    																	   "Mensajes de Error: ",
    																		"",
    																		FuncionesGenerales.getInstance().mostrarTablaDeErrores(error.error.errors));
    	  }
    );
  }

  callback = () : void => {
    this.childModal.hide();
    this.estadoAsignacion$.next("X");
  };

  getEstadoAsignacion(){
    return this.estadoAsignacion$;
  }

  seleccionarElemento(objSeleccionado){
    this.codGrupoTrabajo = objSeleccionado.target.value;
    this.registroFuncionario = "";
    this.apellidosNombresFuncionario = "";
    this.buscarCatalogoFuncionarios();
  }

  seleccionarElementoUS(objSeleccionado){
    this.codUnidadSeleccion = objSeleccionado.target.value;
    this.mostrarUnidadesDeSeleccionReasignacion(this.codUnidadSeleccion);
  }

  mostrarUnidadesDeSeleccionReasignacion(codUnidadSeleccion: string) {
    if (!this.esModuloAsignacion) {
      if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.listFuncionariosAnteriores)) {
        this.esFuncionarioAnteriorRF = true;
        let funcionarioAnteriorRF: FuncionarioAnteriorRF;
        if (codUnidadSeleccion == undefined) {
          funcionarioAnteriorRF = this.listFuncionariosAnteriores[0];
          this.funcionarioAnteriorRF = this.concatenarNombresApellidosFuncionario(funcionarioAnteriorRF);
        } else {
          funcionarioAnteriorRF = this.listFuncionariosAnteriores.find(x => x.numCorredocUS == parseInt(codUnidadSeleccion));
          this.funcionarioAnteriorRF = this.concatenarNombresApellidosFuncionario(funcionarioAnteriorRF);
        }
      } else {
        this.esFuncionarioAnteriorRF = false;
      }
    }
  }

  concatenarNombresApellidosFuncionario(funcionarioAnteriorRF: FuncionarioAnteriorRF) {
    return funcionarioAnteriorRF.catEmpleado.codPers + " - " + funcionarioAnteriorRF.catEmpleado.apPate.toUpperCase().trim() + ' ' +
           funcionarioAnteriorRF.catEmpleado.apMate.toUpperCase().trim() + ' ' +
           funcionarioAnteriorRF.catEmpleado.nombres.toUpperCase().trim();
  }

  desabilitarKeyEnter(event) {
    if (event.key === "Enter") return false;
  }
}
