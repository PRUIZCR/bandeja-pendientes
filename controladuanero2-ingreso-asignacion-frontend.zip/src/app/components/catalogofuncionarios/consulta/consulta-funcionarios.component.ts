import { Component, OnInit, ViewChild } from '@angular/core';
import { setTheme } from 'ngx-bootstrap/utils';
import { CatalogoService } from 'src/app/services/catalogo.service';
import { Datacatalogo } from 'src/app/models/datacatalogo';
import { Unidaddespacho } from 'src/app/models/unidaddespacho';
import { UnidaddespachoService } from 'src/app/services/unidaddespacho.service';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { Turno } from 'src/app/models/turno';
import { CatEmpleadoService } from 'src/app/services/catempleado.service';
import { TurnoService } from 'src/app/services/turno.service';
import { MatTableDataSource, MatDatepickerInputEvent } from '@angular/material';
import { ConstantesExcepciones } from 'src/app/utils/constantesExcepciones';
import { FuncionariosDetalle } from 'src/app/models/funcionariosdetalle';
import { FuncionariosResumen } from 'src/app/models/funcionariosresumen';
import { ResponseManager } from 'src/app/models/responsemanager';
import { ResponseErrorManager } from 'src/app/models/responseerrormanager';
import { ConstantesListas } from 'src/app/utils/constanteslistas';
import { MatSort  } from '@angular/material/sort';
import { MatPaginator  } from '@angular/material/paginator';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { CatEmpleado } from 'src/app/models/catempleado';
import { ConsultaSeleccionfuncionariosComponent } from 'src/app/components/seleccionfuncionarios/consulta/consulta-seleccionfuncionarios.component';
import { Observable } from 'rxjs/Observable';
import { OptionsInput } from '@fullcalendar/core';
import { TurnoFuncionariosComponent } from '../turno/turno-funcionarios.component';
import { CatempleadofuncionarioService } from 'src/app/services/catempleadofuncionario.service';
import { FuncionarioDisponible } from 'src/app/models/funcionariodisponible';
import { CatalogofuncionarioService } from 'src/app/services/catalogofuncionario.service';

@Component({
  selector: 'app-consulta-funcionarios',
  templateUrl: './consulta-funcionarios.component.html',
  styleUrls: ['./consulta-funcionarios.component.css']
})
export class ConsultaFuncionariosComponent implements OnInit {
  @ViewChild(ConsultaSeleccionfuncionariosComponent) child: ConsultaSeleccionfuncionariosComponent;
  @ViewChild(TurnoFuncionariosComponent) childTurno: TurnoFuncionariosComponent;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('motivoModal') motivoModal: ModalDirective;
  @ViewChild('modificarVigenciaModal') modificarVigenciaModal: ModalDirective;
  @ViewChild('nuevaVigenciaModal') nuevaVigenciaModal: ModalDirective;
  txtFecha: string;
  txtHora: string;
  fechaActual: Date;
  aduanaSeleccionada : string;
  unidadDespachoSeleccionado: string;
  turnoSeleccionado: string;
  grupoFuncionarioSeleccionado: string;
  deshabilitarParametrosBuqueda: boolean = false;
  fechaVigenteDesde: Date = new Date();
  fechaVigenteHasta: Date = new Date();
  minDate: Date = new Date();
  hayFuncionarios: boolean = false;
  hayParametrosDeBusqueda: boolean = true;
  objRegistro: string;
  objRegistroAP: string;
  desabilitarCriterioRegistro: boolean = true;
  desabilitarCriterioAP: boolean = true;
  habilitarSeleccion: boolean = false;
  habilitarAgregarFuncionarios: boolean = false;
  //cchavezt ATENCION BUGS
  filtroRegistro: string=ConstantesCadenas.FILTRO_REGISTRO;
  filtroRegistroAP: string=ConstantesCadenas.FILTRO_REGISTROAP;
  //cchavezt ATENCION BUGS
     /*objetos*/
  objAduanaSeleccionada: Datacatalogo;
  objUnidadDespachoSeleccionado: Unidaddespacho;
  objTurnoSeleccionado: Turno;
  objGrupoFuncionarioSeleccionado: Datacatalogo;
  responseManager: ResponseManager;
  responseErrorManager: ResponseErrorManager;
  funcionesGenerales: FuncionesGenerales;
  objCatEmpleado: CatEmpleado;
  options: OptionsInput;
  /*Colecciones de cobjetos*/
  aduanas: Datacatalogo[];
  lstUnidadDespacho: Unidaddespacho[];
  lstTurnos: Turno[];
  lstGrupoFuncionarios: Datacatalogo[];
  funcionariosDetalle: FuncionariosDetalle[];
  funcionariosResumen: FuncionariosResumen[];
  listaFuncionarios: FuncionarioDisponible[];
  displayedColumns: string[];
  displayedColumnsAsignacion: string[];
  funcionariosResumenDS: MatTableDataSource<FuncionariosResumen>;
  funcionariosResumenAsignacionDS: MatTableDataSource<FuncionarioDisponible>;
  estadoOperacion$: Observable<CatEmpleado>;
  estadoOperacionFuncionario$: Observable<FuncionariosDetalle>;
  lstCatEmpleado: CatEmpleado[];
  descripcionMotivo: String;
  turnoSinHorario: Turno;
  mostrarTurno: Boolean = false;

  constructor(
              private catalogoService:CatalogoService,
              private unidaddespachoService: UnidaddespachoService,
              private turnoService: TurnoService,
              private catEmpleadoService: CatEmpleadoService,
              private catempleadofuncionarioService: CatempleadofuncionarioService,
              private catalogofuncionarioService: CatalogofuncionarioService
            ) {
    setTheme('bs4');
  }

  ngOnInit() {
    this.mostrarTurno = false;
    this.catalogoService.listarGruposTrabajo().subscribe(result => {
      //FuncionesGenerales.getInstance().cerrarModalCargando();
      this.lstGrupoFuncionarios = result as Datacatalogo[];
      if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstGrupoFuncionarios)) {
        this.lstGrupoFuncionarios.map(
          gf => {
            gf.codDatacat = gf.cod_datacat;
          }
        );
        this.objGrupoFuncionarioSeleccionado = this.lstGrupoFuncionarios[0];
        this.grupoFuncionarioSeleccionado = this.lstGrupoFuncionarios[0].cod_datacat; //ConstantesCadenas.SELECCIONAR_GRUPO_FUNCIONARIO;
      }
    }, error => console.error(error));
    this.catalogoService.listarAduanas().subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.aduanaSeleccionada = result.aduana;
      this.aduanas = result.listaAduanas as Datacatalogo[];
      if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.aduanas)) {
        this.aduanas.map(
          x => (
            x.codDatacat = x.cod_datacat
          )
        );
        this.cargarControles();
      }
    }, error => console.error(error));
    this.fechaActual = new Date();
    this.txtFecha = ('00' + this.fechaActual.getDate()).slice(-2) + '/' +
                    ('00' + (this.fechaActual.getMonth() + 1)).slice(-2) + '/' +
                    this.fechaActual.getFullYear();
    this.txtHora = ('00' + this.fechaActual.getHours()).slice(-2) + ':' +
                   ('00' + this.fechaActual.getMinutes()).slice(-2) + ':' +
                   ('00' + this.fechaActual.getSeconds()).slice(-2);
    this.funcionariosDetalle = [];

     this.estadoOperacion$ = this.child.getEstadoOperacion$();
     this.estadoOperacion$.subscribe(x => {
       if (x != null && Object.entries(x).length != 0) {
         this.objCatEmpleado = x as CatEmpleado;
         this.mostrarFiltroFuncionarios(this.objCatEmpleado);
         this.habilitarSeleccion = true;
         this.habilitarAgregarFuncionarios = true;
       } else {
         this.objCatEmpleado = null;
       }
      }
    );
    this.funcionesGenerales = FuncionesGenerales.getInstance();
    this.displayedColumns = ConstantesListas.COLUMNAS_GRID_CONSULTAS_FUNCIONARIO_RESUMEN;
    this.displayedColumnsAsignacion = ConstantesListas.COLUMNAS_GRID_CONSULTAS_FUNCIONARIO_RESUMEN_ASIGNACIONES;

    this.funcionariosResumenDS = new MatTableDataSource<FuncionariosResumen>([]);
    this.funcionariosResumenDS.sort = this.sort;
    this.funcionariosResumenDS.paginator = this.paginator;
    /*asignacion de funcionario*/
    this.funcionariosResumenAsignacionDS = new MatTableDataSource<FuncionarioDisponible>([]);
    this.funcionariosResumenAsignacionDS.sort = this.sort;
    this.funcionariosResumenAsignacionDS.paginator = this.paginator;

    this.objRegistro = '';
    this.objRegistroAP = '';
    this.desabilitarCriterioRegistro = true;
    this.habilitarAgregarFuncionarios = false;
    this.objTurnoSeleccionado = new Turno();
    this.lstTurnos = [];
  }

  cargarControles(){
    //this.aduanaSeleccionada = this.aduanas[0].cod_datacat;
    this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == this.aduanaSeleccionada);
    this.lstUnidadDespacho = [];
    this.cargarUnidadesDespacho();
  }

  seleccionarAduana(objSeleccionado) {
    this.aduanaSeleccionada = objSeleccionado.target.value;
    this.lstTurnos = [];
    this.turnoSeleccionado = "";
    if (objSeleccionado.target.value != "") {
      this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == objSeleccionado.target.value);
      this.cargarUnidadesDespacho();
    }
  }

  cargarUnidadesDespacho(){
    let campos: string = 'numUnidadDespacho,nombre';
    this.unidaddespachoService.listarUnidadesDespacho(this.aduanaSeleccionada,
                                                      ConstantesCadenas.ESTADO_VIGENTE,
                                                      campos).subscribe(result => {
        FuncionesGenerales.getInstance().cerrarModalCargando();
        this.lstUnidadDespacho = result as Unidaddespacho[];
        if (this.aduanaSeleccionada != "" && FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstUnidadDespacho)) {
          this.lstUnidadDespacho = this.lstUnidadDespacho.sort(FuncionesGenerales.getInstance().ordenarPor("numUnidadDespacho", false));
          this.unidadDespachoSeleccionado = this.lstUnidadDespacho[0].numUnidadDespacho.toString();
          this.objUnidadDespachoSeleccionado = this.lstUnidadDespacho.find(element => element.numUnidadDespacho == parseInt(this.unidadDespachoSeleccionado));
          this.cargarTurnoSinHorario();
          this.cargarTurnos(false, false);
        } else {
          this.lstUnidadDespacho = [];
          this.unidadDespachoSeleccionado = "";
          this.lstTurnos = [];
          this.turnoSeleccionado = "";
          let errorMensaje: string = "No existen unidades de despacho asignadas a la Aduana " + this.objAduanaSeleccionada.des_corta;
          let tituloErrores: string = "Mensaje de Error: ";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                      tituloErrores, errorMensaje, "");
        }
    }, error => console.error(error));

  }


  cargarTurnoSinHorario() {
    let campos: string = 'numTurno,nombre,hraInicio,hraFin,fecInicioVigencia,fecFinVigencia,indPermanente';
    this.turnoService.listarTurnos(this.unidadDespachoSeleccionado,
                                   ConstantesCadenas.ESTADO_VIGENTE,
                                   "",
                                   "",
                                   campos,
                                   "",
                                   '1').subscribe(result => {
       this.turnoSinHorario = (result as Turno[])[0];
       if (this.objGrupoFuncionarioSeleccionado.indPermanente && this.objGrupoFuncionarioSeleccionado.indPermanente === '1') {
        this.turnoSeleccionado = this.turnoSinHorario.numTurno.toString();
        this.objTurnoSeleccionado = this.turnoSinHorario;
       }
    }, error => console.error(error));
  }

  cargarTurnos(esFechaInicio: boolean, esFechaFin: boolean) {
    let campos: string = 'numTurno,nombre,hraInicio,hraFin,fecInicioVigencia,fecFinVigencia';
    if (esFechaInicio && esFechaFin) {
        this.turnoService.listarTurnos(this.unidadDespachoSeleccionado,
          ConstantesCadenas.ESTADO_VIGENTE,
          (esFechaInicio ? FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteDesde) : ""),
          (esFechaFin ? FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteHasta) : ""),
          campos, "X").subscribe(result => {
        FuncionesGenerales.getInstance().cerrarModalCargando();
        this.lstTurnos = result as Turno[];
        if (this.unidadDespachoSeleccionado != '' && FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstTurnos)) {
          this.lstTurnos = this.lstTurnos.sort(FuncionesGenerales.getInstance().ordenarPor('numTurno', false));
          this.turnoSeleccionado = this.lstTurnos[0].numTurno.toString();
          this.objTurnoSeleccionado = this.lstTurnos.find(element => element.numTurno == parseInt(this.turnoSeleccionado))
        } else {
          if (!(this.objGrupoFuncionarioSeleccionado.indPermanente && this.objGrupoFuncionarioSeleccionado.indPermanente === '1')) {
            this.mostrarTurno = true;
            this.turnoSeleccionado = "";
            this.lstTurnos = [];
            let errorMensaje: string = 'No existen turnos asociados a la unidad de despacho ' + this.objUnidadDespachoSeleccionado.descripcion;
            let tituloErrores: string = 'Mensaje de Error: ';
            FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                            tituloErrores, errorMensaje, '');
            }
        }
      }, error => console.error(error));
    } else {
        this.turnoService.listarTurnos(this.unidadDespachoSeleccionado,
          ConstantesCadenas.ESTADO_VIGENTE,
          "",
          "",
          campos).subscribe(result => {
        FuncionesGenerales.getInstance().cerrarModalCargando();
        this.lstTurnos = result as Turno[];
        if (this.unidadDespachoSeleccionado != '' && FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstTurnos)) {
          this.lstTurnos = this.lstTurnos.sort(FuncionesGenerales.getInstance().ordenarPor('numTurno', false));
          this.turnoSeleccionado = this.lstTurnos[0].numTurno.toString();
          this.objTurnoSeleccionado = this.lstTurnos.find(element => element.numTurno == parseInt(this.turnoSeleccionado))
        } else {
          if (!(this.objGrupoFuncionarioSeleccionado.indPermanente && this.objGrupoFuncionarioSeleccionado.indPermanente === '1')) {
            this.mostrarTurno = true;
            this.turnoSeleccionado = "";
            this.lstTurnos = [];
            let errorMensaje: string = 'No existen turnos asociados a la unidad de despacho ' + this.objUnidadDespachoSeleccionado.descripcion;
            let tituloErrores: string = 'Mensaje de Error: ';
            FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                            tituloErrores, errorMensaje, '');
            }
        }
      }, error => console.error(error));
    }

  }

  seleccionarTurno(objSeleccionado) {
    this.turnoSeleccionado = objSeleccionado.target.value;
    if (objSeleccionado.target.value != '') {
      this.objTurnoSeleccionado = this.lstTurnos.find(element => element.numTurno == objSeleccionado.target.value);
    }
  }

  seleccionarUnidadDespacho(objSeleccionado) {
    this.unidadDespachoSeleccionado = objSeleccionado.target.value;
    this.lstTurnos = [];
    this.turnoSeleccionado = "";
    if (objSeleccionado.target.value != '') {
      this.objUnidadDespachoSeleccionado = this.lstUnidadDespacho.find(element => element.numUnidadDespacho == objSeleccionado.target.value);
      this.fechaVigenteDesde = new Date();
      this.fechaVigenteHasta = new Date();
      this.cargarTurnos(false, false);
      this.cargarTurnoSinHorario();
    }
  }

  limpiarFuncionarios() {
    this.deshabilitarParametrosBuqueda = false;
    this.hayFuncionarios = false;
    this.hayParametrosDeBusqueda = true;
    this.funcionariosDetalle = [];
    this.funcionariosResumen = [];
    this.ngOnInit();
  }

  cargarTurnoPorFechas() {
    if (this.unidadDespachoSeleccionado != undefined && this.unidadDespachoSeleccionado != null && this.unidadDespachoSeleccionado != "" &&
        this.fechaVigenteDesde != undefined && this.fechaVigenteDesde != null &&
        this.fechaVigenteHasta != undefined && this.fechaVigenteHasta != null) {
      this.cargarTurnos(true, true);
      this.cargarTurnoSinHorario();
    }
  }

  changeVigenteDesde(obj: MatDatepickerInputEvent<Date>){
    if(FuncionesGenerales.getInstance().compararFechas(
        FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(new Date()),
        ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
        FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(obj.value),
        ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 1)
    {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA,
                                                                  ConstantesExcepciones.DEFAULT_TITTLE_EXCEPTION, ConstantesExcepciones.EXCEPCION_UNO, "");
      return false;
    }
    if (this.fechaVigenteHasta != undefined && this.fechaVigenteHasta != null) {
      if (FuncionesGenerales.getInstance().compararFechas(
        FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(obj.value),
        ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
        FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteHasta),
        ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 1) {
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA,
          ConstantesExcepciones.DEFAULT_TITTLE_EXCEPTION, ConstantesExcepciones.EXCEPCION_DOS, "");
        return false;
      }  else {
        this.cargarTurnoPorFechas();
      }
    } else {
      this.cargarTurnoPorFechas();
    }
  }
  changeVigenteHasta(obj: MatDatepickerInputEvent<Date>){
    if (this.fechaVigenteDesde != undefined && this.fechaVigenteDesde != null) {
      if (FuncionesGenerales.getInstance().compararFechas(
        FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteDesde),
        ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
        FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(obj.value),
        ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 1) {
         FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA,
          ConstantesExcepciones.DEFAULT_TITTLE_EXCEPTION, ConstantesExcepciones.EXCEPCION_DOS, "");
        return false;
      } else {
        this.cargarTurnoPorFechas();
      }
    } else {
      this.cargarTurnoPorFechas();
    }
  }

  seleccionarGrupoFuncionarios(objSeleccionado) {
    this.cargarTurnoPorFechas();
    this.grupoFuncionarioSeleccionado = objSeleccionado.target.value;
    if (objSeleccionado.target.value != '-1') {
      this.objGrupoFuncionarioSeleccionado = this.lstGrupoFuncionarios.find(element => element.cod_datacat == objSeleccionado.target.value);
      if (this.objGrupoFuncionarioSeleccionado.indPermanente && this.objGrupoFuncionarioSeleccionado.indPermanente === '1') {
        this.mostrarTurno = false;
        this.turnoSeleccionado = this.turnoSinHorario.numTurno.toString();
        this.objTurnoSeleccionado = this.turnoSinHorario;
      } else if (!this.mostrarTurno) {
        if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstTurnos)) {
          this.turnoSeleccionado = this.lstTurnos[0].numTurno.toString();
          this.objTurnoSeleccionado = this.lstTurnos[0];
        } else {
          this.turnoSeleccionado = "";
          this.objTurnoSeleccionado = null;
          let errorMensaje: string = 'No existen turnos asociados a la unidad de despacho ' + this.objUnidadDespachoSeleccionado.descripcion;
          let tituloErrores: string = 'Mensaje de Error: ';
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                      tituloErrores, errorMensaje, '');
        }
        this.mostrarTurno = true;
      }
    }
  }

  exportarPDFExcel(nombrePaqueteFormado: string, tipoMime: string) {
    let campos: string = "tipoReporte,archivoBytes";
    let tipoReporte: string = tipoMime == ConstantesCadenas.TIPO_MIME_EXCEL ? ConstantesCadenas.TIPO_REPORTE_XLS : ConstantesCadenas.TIPO_REPORTE_PDF;

    if ((this.objRegistro == undefined || this.objRegistro.length <=0)
        && (this.objRegistroAP == undefined || this.objRegistroAP.length <=0)){
          this.reporteCatalogoFuncionarios(tipoReporte, campos, nombrePaqueteFormado, tipoMime);
    } else {
          this.reporteCatalogoAsignacionFuncionarios(tipoReporte, campos, nombrePaqueteFormado, tipoMime);
    }
  }

  reporteCatalogoFuncionarios(tipoReporte: string, campos: string, nombrePaqueteFormado: string, tipoMime: string) {
    //let reporteJSON: ReporteGenerico = new ReporteGenerico();
    this.catalogofuncionarioService.reporteCatalogoFuncionarios(
      tipoReporte,
      this.unidadDespachoSeleccionado,
      this.turnoSeleccionado,
      this.grupoFuncionarioSeleccionado,
      this.fechaVigenteDesde,
      this.fechaVigenteHasta,
      campos
    ).subscribe(response => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      if (response != undefined && response != null) {
        let strBase64 = FuncionesGenerales.getInstance().base64ToArrayBuffer(response);
        FuncionesGenerales.getInstance().saveByteArray(nombrePaqueteFormado, strBase64, tipoMime);
      } else {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    "Mensajes de Error: ",
                                                                    "Ocurrio un error, comuníquese con el área de sistemas", '');
      }
    },
    errorResult => {
      if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
        let responseManager: ResponseManager = new ResponseManager();
        this.responseErrorManager = errorResult as ResponseErrorManager;
        responseManager.cod = errorResult.cod;
        responseManager.errors = [this.responseErrorManager];
        this.responseManager = responseManager;
        this.cargarMensajesCatalogoFuncionarios(this.responseManager);
      } else {
        this.responseManager = errorResult as ResponseManager;
        this.cargarMensajesCatalogoFuncionarios(this.responseManager);
      }
    });
  }

  reporteCatalogoAsignacionFuncionarios(tipoReporte: string, campos: string, nombrePaqueteFormado: string, tipoMime: string) {
    //let reporteJSON: ReporteGenerico = new ReporteGenerico();
    this.catalogofuncionarioService.reporteCatalogoAsignacionFuncionarios(
      tipoReporte,
      this.unidadDespachoSeleccionado,
      this.fechaVigenteDesde,
      this.fechaVigenteHasta,
      this.objRegistro,
      campos
    ).subscribe(response => {
      //console.log(response);
      /*reporteJSON = response as ReporteGenerico;*/
      FuncionesGenerales.getInstance().cerrarModalCargando();
      if (response != undefined && response != null) {
        let strBase64 = FuncionesGenerales.getInstance().base64ToArrayBuffer(response);
        FuncionesGenerales.getInstance().saveByteArray(nombrePaqueteFormado, strBase64, tipoMime);
      } else {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    "Mensajes de Error: ",
                                                                    "Ocurrio un error, comuníquese con el área de sistemas", '');
      }
    },
    errorResult => {
      if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
        let responseManager: ResponseManager = new ResponseManager();
        this.responseErrorManager = errorResult as ResponseErrorManager;
        responseManager.cod = errorResult.cod;
        responseManager.errors = [this.responseErrorManager];
        this.responseManager = responseManager;
        this.cargarMensajesCatalogoFuncionarios(this.responseManager);
      } else {
        this.responseManager = errorResult as ResponseManager;
        this.cargarMensajesCatalogoFuncionarios(this.responseManager);
      }
    });
  }

  exportar() {
    this.exportarPDFExcel(ConstantesCadenas.NOMBRE_REPORTE_CONSULTA_CATALOGO_FUNCIONARIO_XLS, ConstantesCadenas.TIPO_MIME_EXCEL);
  }

  imprimir() {
    /*let str = "JVBERi0xLjQKJeLjz9MKMyAwIG9iaiA8PC9MZW5ndGggNTQ3L0ZpbHRlci9GbGF0ZURlY29kZT4+c3RyZWFtCnicvdfLbtpAFAbg/TzFLNNFzczxPTsXzCWiODLOKurCwiQhAhOZWH2+vlnPUERSKRwj+dgCwUj46JvxPxcD8k78yISWCl/mM3BAZjsxGGupsfUkbr5lryL+fImSq93nIg3aCkH6oW8p/1zsmWJ1vKR6FjdpfJ+kWSxHsRxG2Z95MklMe/ywGM6SRZTOkqWBlHz+Anv8hd+FAOzs5W6Akr7vWO65B+r/HozXq5ecwXAJY7qvOAibIKKizksORBPIQ7kp8kIWa3wf3vLVy7496IVUOHW52uzLvNq0lTS49DxQeqD8ASgdckjUbHBuATgMajqA7crvMorTOML1NMfFNZ9HCYdKzo/FbBSNEFzeR8Npgj1I48nsZ7yQEDDY5FQp6+22peEGlouK51s2XGJG60OxvtL5jRfdnWrTyfk3nPOBxoHshOu7p/ZWLK+t9dRH7bF9da111LD2X9PT15aida49tb8qvpidhyeB03Bjp/nhvfX+5dkWdpKGJlX9tjd72NPH5nJoCTu4szSOMKursvWGiaNzgp52MVICj0mCJolhZTuq4b4xGCYa8PqKhpJ4o6Ekrmg6Nkw0qq+zn5R4o6Ekrmg6NsAcu9BTNKRkc0nQJDFF07Vhojk+YFyayyFnNJRkK85oKIkrmo4NE43d12MAKfGuGkriiqZjw0SjqcOZddVQEu+qoSSuaDo2MBqH+gvJGg0psa4aUmKKhsf4Cz3dFmMKZW5kc3RyZWFtCmVuZG9iagoxIDAgb2JqPDwvUGFyZW50IDQgMCBSL0NvbnRlbnRzIDMgMCBSL1R5cGUvUGFnZS9SZXNvdXJjZXM8PC9Qcm9jU2V0IFsvUERGIC9UZXh0IC9JbWFnZUIgL0ltYWdlQyAvSW1hZ2VJXS9Gb250PDwvRjEgMiAwIFI+Pj4+L01lZGlhQm94WzAgMCA1OTUgODQyXT4+CmVuZG9iago1IDAgb2JqWzEgMCBSL1hZWiAwIDg1NCAwXQplbmRvYmoKMiAwIG9iajw8L0Jhc2VGb250L0hlbHZldGljYS9UeXBlL0ZvbnQvRW5jb2RpbmcvV2luQW5zaUVuY29kaW5nL1N1YnR5cGUvVHlwZTE+PgplbmRvYmoKNCAwIG9iajw8L1R5cGUvUGFnZXMvQ291bnQgMS9LaWRzWzEgMCBSXT4+CmVuZG9iago2IDAgb2JqPDwvTmFtZXNbKEpSX1BBR0VfQU5DSE9SXzBfMSkgNSAwIFJdPj4KZW5kb2JqCjcgMCBvYmo8PC9EZXN0cyA2IDAgUj4+CmVuZG9iago4IDAgb2JqPDwvTmFtZXMgNyAwIFIvVHlwZS9DYXRhbG9nL1BhZ2VzIDQgMCBSPj4KZW5kb2JqCjkgMCBvYmo8PC9DcmVhdG9yKFNVTkFUIEphdmEgR2VuRG9jIGRlcmVjaG9zIHJlc2VydmFkb3MpL1Byb2R1Y2VyKGlUZXh0IDEuNC42IFwoYnkgbG93YWdpZS5jb21cKSkvTW9kRGF0ZShEOjIwMTkwNzAyMTQzNDMzLTA1JzAwJykvQXV0aG9yKHN1bmF0LmdvYi5wZSkvQ3JlYXRpb25EYXRlKEQ6MjAxOTA3MDIxNDM0MzMtMDUnMDAnKT4+CmVuZG9iagp4cmVmCjAgMTAKMDAwMDAwMDAwMCA2NTUzNSBmIAowMDAwMDAwNjI5IDAwMDAwIG4gCjAwMDAwMDA4MTkgMDAwMDAgbiAKMDAwMDAwMDAxNSAwMDAwMCBuIAowMDAwMDAwOTA2IDAwMDAwIG4gCjAwMDAwMDA3ODUgMDAwMDAgbiAKMDAwMDAwMDk1NiAwMDAwMCBuIAowMDAwMDAxMDA5IDAwMDAwIG4gCjAwMDAwMDEwNDAgMDAwMDAgbiAKMDAwMDAwMTA5NiAwMDAwMCBuIAp0cmFpbGVyCjw8L1Jvb3QgOCAwIFIvSUQgWzw0ZmEyOGVkNDIzMTQ1MmY1YmMwMGVhZTJjMjk1Y2UwMT48NmE1OGIxODNmYTI1N2MyMzllN2I4ZjllMThkMmUwOWE+XS9JbmZvIDkgMCBSL1NpemUgMTA+PgpzdGFydHhyZWYKMTI5NQolJUVPRgo=";
    let strBase64 = FuncionesGenerales.getInstance().base64ToArrayBuffer(str);
    FuncionesGenerales.getInstance().saveByteArray("prueba", strBase64, ConstantesCadenas.TIPO_MIME_PDF);*/
    this.exportarPDFExcel(ConstantesCadenas.NOMBRE_REPORTE_CONSULTA_CATALOGO_FUNCIONARIO_PDF, ConstantesCadenas.TIPO_MIME_PDF);

  }

  consultarCatalogo() {
   if ((this.objRegistro == undefined || this.objRegistro.length <=0)
        && (this.objRegistroAP == undefined || this.objRegistroAP.length <=0)){
      if (!this.validarParametrosDeConsulta()) {
        return false;
      }
      this.consultarCatalogoFuncionarios();
    }else{
      this.consultarCatalogoFuncionariosAsignados();
    }
  }

  validarParametrosDeConsulta() {
    let tituloErrores: string = 'Mensajes de Error: ';
    let esValido: boolean = false;
    if (this.aduanaSeleccionada == "") {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_DIECISIETE, '');
      return false;
    }
    if (this.fechaVigenteDesde == undefined) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_OCHO, '');
      return false;
    }
    if (!FuncionesGenerales.getInstance().esFechaValida(
         FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteDesde),
                                                        ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO)) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_NUEVE, '');
      return false;
    }

    if (this.fechaVigenteHasta == undefined) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_DIEZ, '');
      return false;
    }
    if (!FuncionesGenerales.getInstance().esFechaValida(
         FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteHasta),
         ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO)) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_ONCE, '');
      return false;
    }
    if (FuncionesGenerales.getInstance().compararFechas(
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteDesde),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteHasta),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 1)
    {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
        ConstantesExcepciones.DEFAULT_TITTLE_EXCEPTION, ConstantesExcepciones.EXCEPCION_DOS, '');
      return false;
    }
    if (this.unidadDespachoSeleccionado == "") {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_DIECINUEVE, '');
      return false;
    }
    if (this.grupoFuncionarioSeleccionado == "") {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_VEINTE, '');
      return false;
    }
    if (this.turnoSeleccionado == "") {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_VEINTIUNO, '');
      return false;
    }
    /*Validacion mayor de 1 año*/
    let diferenciaAnnios: number = FuncionesGenerales.getInstance().diferenciaEntreFechas(
                                                                                  FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteDesde),
                                                                                  FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteHasta),
                                                                                  ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO_MOMENT,
                                                                                  ConstantesCadenas.FORMATO_UNIDAD_TIEMPO_ANNIOS);
    if (diferenciaAnnios >= 1) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_VEINTIDOS, '');
      return false;
    }

    esValido = true;
    return esValido;
  }

  consultarCatalogoFuncionarios() {
    this.catEmpleadoService.obtenerCatalogoFuncionarios(
      ConstantesCadenas.TIPO_CONSULTA_FUNCIONARIOS_CONSULTA,
      this.unidadDespachoSeleccionado,
      this.turnoSeleccionado,
      this.grupoFuncionarioSeleccionado,
      this.fechaVigenteDesde,
      this.fechaVigenteHasta
    ).subscribe(response => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.deshabilitarParametrosBuqueda = true;
      this.funcionariosResumen = response.funcionariosResumen;
      // setteo de propiedad traído de DB
      this.funcionariosResumen.map(fr => (fr.saved = true));
      console.log(this.funcionariosResumen);
      //this.cargarCalendario(this.funcionariosDetalle);
      this.cargarListaFuncionariosResumen(this.funcionariosResumen);
    },
    errorResult => {
      this.deshabilitarParametrosBuqueda = false;
      if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
        let responseManager: ResponseManager = new ResponseManager();
        this.responseErrorManager = errorResult as ResponseErrorManager;
        responseManager.cod = errorResult.cod;
        responseManager.errors = [this.responseErrorManager];
        this.responseManager = responseManager;
        this.cargarMensajesCatalogoFuncionarios(this.responseManager);
      } else {
        this.responseManager = errorResult as ResponseManager;
        this.cargarMensajesCatalogoFuncionarios(this.responseManager);
      }
    });
  }

  cargarListaFuncionariosResumen(funcionariosResumen: FuncionariosResumen[]) {
    this.displayedColumns = ConstantesListas.COLUMNAS_GRID_CONSULTAS_FUNCIONARIO_RESUMEN;
    console.log("funcionariosResumen");
    console.log(funcionariosResumen);
    this.funcionariosResumenDS = new MatTableDataSource<FuncionariosResumen>(funcionariosResumen);
    this.funcionariosResumenDS.sort = this.sort;
    this.funcionariosResumenDS.paginator = this.paginator;
  }

  consultarCatalogoFuncionariosAsignados() {
    this.catempleadofuncionarioService.obtenerAsignacionesFuncionario(
      ConstantesCadenas.TIPO_CONSULTA_FUNCIONARIOS_CONSULTA,
      this.unidadDespachoSeleccionado,
      this.fechaVigenteDesde,
      this.fechaVigenteHasta,
      this.objRegistro
    ).subscribe(response => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.deshabilitarParametrosBuqueda = true;
      this.listaFuncionarios = response.asignaciones;
      // setteo de propiedad traído de DB
      console.log(this.listaFuncionarios);
      this.cargarListaFuncionariosResumenAsignacion(this.listaFuncionarios);
    },
    errorResult => {
      this.deshabilitarParametrosBuqueda = false;
      if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
        let responseManager: ResponseManager = new ResponseManager();
        this.responseErrorManager = errorResult as ResponseErrorManager;
        responseManager.cod = errorResult.cod;
        responseManager.errors = [this.responseErrorManager];
        this.responseManager = responseManager;
        this.cargarMensajesCatalogoFuncionarios(this.responseManager);
      } else {
        this.responseManager = errorResult as ResponseManager;
        this.cargarMensajesCatalogoFuncionarios(this.responseManager);
      }
    });
  }

  cargarListaFuncionariosResumenAsignacion(funcionariosDisponible: FuncionarioDisponible[]) {
    this.displayedColumnsAsignacion = ConstantesListas.COLUMNAS_GRID_CONSULTAS_FUNCIONARIO_RESUMEN_ASIGNACIONES;
    this.funcionariosResumenAsignacionDS = new MatTableDataSource<FuncionarioDisponible>(funcionariosDisponible);
    this.funcionariosResumenAsignacionDS.sort = this.sort;
    this.funcionariosResumenAsignacionDS.paginator = this.paginator;
  }

  cargarMensajesCatalogoFuncionarios(responseManager: ResponseManager) {
    if (responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO ||
        responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                   'Mensajes de Error: ',
                                                                    '',
                                                                    FuncionesGenerales.getInstance().mostrarTablaDeErrores(this.responseManager.errors));
    }
  }

  cerrarModalMotivo() {
    this.motivoModal.hide();
  }

  mostrarMotivoFuncionario(funcionarioResumen: FuncionariosResumen) {
    this.descripcionMotivo = funcionarioResumen.motivo;
    this.motivoModal.show();
  }

  refreshFuncionariosResumen() {
    this.funcionariosResumenDS = new MatTableDataSource<FuncionariosResumen>(this.funcionariosResumen);
    this.funcionariosResumenDS.sort = this.sort;
    this.funcionariosResumenDS.paginator = this.paginator;
  }

  buscarCatalogoFuncionarios(hayFuncionario: boolean, filtroRegistroUsado: string) {
    let habilitarBusqueda: boolean = true;
    let registro: string = '';
    let registroAP: string = '';
    if (this.habilitarSeleccion) {
      registro = this.objRegistro.replace(/“/g, '"').replace(/”/g, '"');
      registroAP = this.objRegistroAP.replace(/“/g, '"').replace(/”/g, '"');
      if (this.desabilitarCriterioRegistro) {
        registroAP = '';
        habilitarBusqueda = true;
      } else {
        registro = '';
        if (registroAP == '') {
          habilitarBusqueda = false;
          this.habilitarSeleccion = false;
          this.objRegistro = registro;
          this.desabilitarCriterioRegistro = true;
        } else {
          habilitarBusqueda = true;
        }
      }
    } else {
      if (this.objRegistro.length > 0 && this.objRegistroAP.length == 0) {
        if (this.desabilitarCriterioRegistro) {
          this.desabilitarCriterioRegistro = true;
          this.desabilitarCriterioAP = false;
        } else {
          this.desabilitarCriterioRegistro = true;
          this.desabilitarCriterioAP = true;
          this.objRegistro = '';
          habilitarBusqueda = false;
        }
      } else if (this.objRegistroAP.length > 0 && this.objRegistro.length == 0) {
        if (this.desabilitarCriterioAP) {
          this.desabilitarCriterioRegistro = false;
          this.desabilitarCriterioAP = true;
        } else {
          this.desabilitarCriterioRegistro = true;
          this.desabilitarCriterioAP = true;
          this.objRegistroAP = '';
          habilitarBusqueda = false;
        }
      } else if (this.objRegistroAP.length == 0 && this.objRegistro.length == 0) {
        this.desabilitarCriterioRegistro = true;
        this.desabilitarCriterioAP = true;
        this.objRegistro = '';
        this.objRegistroAP = '';
        habilitarBusqueda = false;
      } else if (this.objRegistroAP.length > 0 && this.objRegistro.length > 0) {
        if (this.desabilitarCriterioAP) {
          this.objRegistro = '';
        } else {
          this.objRegistroAP = '';
        }
        habilitarBusqueda = true;
      }
      registro = this.objRegistro.replace(/“/g, '"').replace(/”/g, '"');
      registroAP = this.objRegistroAP.replace(/“/g, '"').replace(/”/g, '"');

    }
    if (habilitarBusqueda) {
      if(registroAP.length<=100){
      this.catEmpleadoService.buscarCatalogoFuncionarios(
        this.aduanaSeleccionada,
        registro,
        registroAP
      ).subscribe(response => {
        FuncionesGenerales.getInstance().cerrarModalCargando();
        this.lstCatEmpleado = response as CatEmpleado[];
        this.validarFuncionariosResumen(this.lstCatEmpleado,filtroRegistroUsado);
        if (hayFuncionario) {
          this.habilitarAgregarFuncionarios = true;
          this.mostrarFiltroFuncionarios(this.objCatEmpleado);
        }
      },
      errorResult => {
        this.habilitarSeleccion = false;
        if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
          let responseManager: ResponseManager = new ResponseManager();
          this.responseErrorManager = errorResult as ResponseErrorManager;
          responseManager.cod = errorResult.cod;
          responseManager.errors = [this.responseErrorManager];
          this.responseManager = responseManager;
          this.cargarMensajesCatalogoFuncionarios(this.responseManager);
        } else {
          this.responseManager = errorResult as ResponseManager;
          this.cargarMensajesCatalogoFuncionarios(this.responseManager);
        }
      });
    }
    else{
      let errorMensaje: string = '';
      let tituloErrores: string = 'Mensaje de Error: ';
      errorMensaje = 'Valor de apellidos y nombres es incorrecto';
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                tituloErrores, errorMensaje, '');
      }//cchavezt ATENCION BUGS
    }
  }

  validarFuncionariosResumen(lstCatEmpleado: CatEmpleado[], filtroRegistroUsado: string) {
    let errorMensaje: string = '';
    let tituloErrores: string = 'Mensaje de Error: ';
    let esValido: boolean = false;
    if (lstCatEmpleado.length == 0) {
      if(filtroRegistroUsado===ConstantesCadenas.FILTRO_REGISTRO)
      {
        errorMensaje = 'No se han encontrado resultados coincidentes con el número de registro del Funcionario Aduanero';
      }
      else{
        errorMensaje = 'No se encontraron funcionarios con los datos ingresados';
      }
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, '');
      return false;
    }
    if (lstCatEmpleado.length == 1) {
      this.mostrarFiltroFuncionarios(lstCatEmpleado[0]);
      this.habilitarAgregarFuncionarios = true;
      return false;
    }
    this.child.mostrarSeleccionDeFuncionarios(lstCatEmpleado);
    esValido = true;
    return esValido;
  }

  mostrarFiltroFuncionarios(objCatEmpleado: CatEmpleado) {
    this.objRegistro = objCatEmpleado.codPers;
    this.objRegistroAP = objCatEmpleado.apPate.trim() + ' ' +
                         objCatEmpleado.apMate.trim() + ' ' +
                         objCatEmpleado.nombres.trim();
  }
}
