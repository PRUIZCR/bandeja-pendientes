import { CatEmpleado } from "./catempleado";
import { Datacatalogo } from "./datacatalogo";
import { Turno } from "./turno";

export class FuncionarioDisponible {
  catEmpleado: CatEmpleado;
  aduana: Datacatalogo;
  grupoTrabajo: Datacatalogo;
  turno: Turno;
  fecAsignacion: Date;
  estado: string;
  motivo: string;
  esDeBD: boolean;

  constructor() { }
}
