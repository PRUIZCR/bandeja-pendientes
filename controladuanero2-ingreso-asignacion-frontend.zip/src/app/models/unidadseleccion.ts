export class UnidadSeleccion {
  numeroCorrelativoUS: number;
  asignada: boolean;
  tipoContenedor: string;
  numeroEquipamiento: string;
  fechaProgramacion: Date;
  strFechaProgramacion: string;
}
