import { Unidaddespacho } from "./unidaddespacho";

export class Zona {
  numZona: number;
  descripcion: string;
  nombre: string;
  indSusceptible: string;
  fecInicioVigencia: Date;
  fecFinVigencia: Date;
  unidadDespacho: Unidaddespacho;

  constructor() { }

}
