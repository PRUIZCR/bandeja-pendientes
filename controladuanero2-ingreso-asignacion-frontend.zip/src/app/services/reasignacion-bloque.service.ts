import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { ConstantesRest } from '../utils/constantesrest';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReasignacionBloqueService {

  constructor(private http: HttpClient) { }

  vigenciaRFU() {
      return this.http.get<any>(FuncionesGenerales.getInstance().reemplazarParametros(
        ConstantesRest.URL_CONSULTA_PAQUETES_VIGENCIA)).pipe(
      catchError(e => {
      return throwError(e);
      }));
  }
}
