import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { CriterioAsigEspe } from "src/app/models/criterioasigespe";
import { MatTableDataSource } from '@angular/material';
import { ConstantesListas } from 'src/app/utils/constanteslistas';
import { MatSort  } from '@angular/material/sort';
import { MatPaginator  } from '@angular/material/paginator';

@Component({
  selector: 'app-lista-criterio',
  templateUrl: './lista-criterio.component.html',
  styleUrls: ['./lista-criterio.component.css']
})
export class ListaCriterioComponent implements OnInit {
  @Input() criterio: CriterioAsigEspe;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  lstCriterioAsigEspe: CriterioAsigEspe[];
  criteriosDS: MatTableDataSource<CriterioAsigEspe>;
  displayedColumns: string[];

  constructor() { }

  ngOnInit() {
    this.displayedColumns = ConstantesListas.COLUMNAS_GRID_CRITERIOS;
    this.criteriosDS = new MatTableDataSource<CriterioAsigEspe>(this.criterio.detallesCriterio);
  }
}
