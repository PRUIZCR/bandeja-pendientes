import { ResponseErrorManager } from 'src/app/models/responseerrormanager';

export class ResponseManager {
  msg: string;
  cod: string;
  errors: ResponseErrorManager[]
  constructor() { }
}
