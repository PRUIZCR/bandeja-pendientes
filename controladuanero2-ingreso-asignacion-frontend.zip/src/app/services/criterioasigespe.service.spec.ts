import { TestBed } from '@angular/core/testing';

import { CriterioAsigEspeService } from './criterioasigespe.service';

describe('UnidaddespachoService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CriterioAsigEspeService = TestBed.get(CriterioAsigEspeService);
    expect(service).toBeTruthy();
  });
});
