import { DetalleInformacionOperacionManual } from './detalleinformacionoperacionmanual';
import { CatEmpleado } from './catempleado';

export class RespuestaInformacionOperacionManual{
  detalles: DetalleInformacionOperacionManual[];
  indObsEditable: string;
  txtObservacion: string;
  catEmpleado: CatEmpleado;
  indBusquedaHabilitada: string;
  constructor() {}
}
