import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainUnidadDespachoComponent } from './components/unidaddespacho/main/main-unidad-despacho.component';
import { MainZonaComponent } from './components/zona/main/main-zona.component';
import { MainTurnoComponent } from './components/turno/main/main-turno.component';
import { MainFuncionariosComponent } from './components/catalogofuncionarios/main/main-funcionarios.component';
import { OptimizacionPaquetesComponent } from './components/optimizacion-paquetes/main/optimizacion-paquetes.component';
import { OptimizacionPaquetesRFUComponent } from './components/optimizacion-paquetes-rfu/main/optimizacion-paquetes-rfu.component';
import { MainSorteoComponent } from './components/sorteo/main/main-sorteo.component';
import { ConsultaSorteoComponent } from './components/sorteo/consulta/consulta-sorteo.component';
import { ConsultaFuncionarioZonaComponent } from './components/asignacionfuncionarios/consulta-funcionario-zona/consulta-funcionario-zona.component';
import { MainAlmacenComponent } from './components/almacen/main/main-almacen.component';
import { ConsultaCriterioComponent } from './components/criterio/consulta/consulta-criterio.component';
import { PonderacionCriterioComponent } from './components/criterio/ponderacion/ponderacion-criterio.component';
import { MainManualComponent } from './components/manual/main/main-manual.component';
import { ReasignacionBloqueComponent } from './components/reasignacion-bloque/main/reasignacion-bloque.component';
import { ReporteAsignacionBloqueComponent } from './components/reporteasignacionbloque/reporte/reporte-asignacion-bloque.component';
import { ListaAsignacionBloqueComponent } from './components/reporteasignacionbloque/lista/lista-asignacion-bloque.component';
import { ConsultaPaquetesFormadosComponent } from './components/paquetes-formados/consulta/consulta-paquetes-formados.component';
import { DetallePaquetesFormadosComponent } from './components/paquetes-formados/detalle/detalle-paquetes-formados.component';
import { ConsultaFuncionariosComponent } from './components/catalogofuncionarios/consulta/consulta-funcionarios.component';

const routes: Routes = [
  { path: 'unidad-despacho', component: MainUnidadDespachoComponent },
  { path: 'zona', component: MainZonaComponent },
  { path: 'turno', component: MainTurnoComponent },
  { path: 'almacen', component: MainAlmacenComponent },
  { path: 'consulta-criterio', component: ConsultaCriterioComponent },
  { path: 'ponderacion-criterio', component: PonderacionCriterioComponent },
  { path: 'catalogo-funcionario', component: MainFuncionariosComponent },
  { path: 'sorteo', component: MainSorteoComponent },
  { path: 'consulta-sorteo', component: ConsultaSorteoComponent },
  { path: 'modificar-sorteo/:numSorteo', component: MainSorteoComponent },
  { path: 'edicion-sorteo', component: ConsultaSorteoComponent },
  { path: 'optimizacion-paquetes', component: OptimizacionPaquetesComponent },
  { path: 'optimizacion-paquetes-rfu', component: OptimizacionPaquetesRFUComponent },
  { path: 'consulta-funcionario-zona', component: ConsultaFuncionarioZonaComponent },
  { path: 'asignacion-manual', component: MainManualComponent },
  { path: 'reasignacion-manual', component: MainManualComponent },
  { path: 'reasignacion-bloque', component: ReasignacionBloqueComponent },
  { path: 'reporte-asignacion-bloque', component: ReporteAsignacionBloqueComponent },
  { path: 'lista-asignacion-bloque/:reporteAsignacion', component: ListaAsignacionBloqueComponent },
  { path: 'consulta-paquetes-formados', component: ConsultaPaquetesFormadosComponent },
  { path: 'detalle-paquetes-formados/:paqueteFormado', component: DetallePaquetesFormadosComponent },
  { path: 'consulta-funcionario', component: ConsultaFuncionariosComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
