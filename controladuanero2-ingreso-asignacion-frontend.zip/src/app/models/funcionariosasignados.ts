export class FuncionariosAsignados {
  zona: string;
  cantidad: number;
  funcionarios: string[];
  
  constructor () { }
}
