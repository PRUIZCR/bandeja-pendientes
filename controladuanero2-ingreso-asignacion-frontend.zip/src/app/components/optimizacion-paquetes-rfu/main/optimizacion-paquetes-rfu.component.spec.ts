import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OptimizacionPaquetesRFUComponent } from './optimizacion-paquetes-rfu.component';

describe('OptimizacionPaquetesRFUComponent', () => {
  let component: OptimizacionPaquetesRFUComponent;
  let fixture: ComponentFixture<OptimizacionPaquetesRFUComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OptimizacionPaquetesRFUComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OptimizacionPaquetesRFUComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
