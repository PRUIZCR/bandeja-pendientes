import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListaAsignacionBloqueComponent } from './lista-asignacion-bloque.component';

describe('ListaAsignacionBloqueComponent', () => {
  let component: ListaAsignacionBloqueComponent;
  let fixture: ComponentFixture<ListaAsignacionBloqueComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListaAsignacionBloqueComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListaAsignacionBloqueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
