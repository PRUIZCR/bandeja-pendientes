import { CatEmpleado } from './catempleado';
import { DetalleInformacionOperacionManual } from './detalleinformacionoperacionmanual';
import { UnidadSeleccionDAM } from './unidadselecciondam';

export class DatosRegistroOperacionManual{
  anio: number;
  aduana: string;
  regimen: string;
  numero: number;
  catEmpleado: CatEmpleado;
  observacion: string;
  detalles: DetalleInformacionOperacionManual[];
  grupoTrabajo: string;
  codTipoOperacion: string;
  unidadesSeleccion: UnidadSeleccionDAM;
  aduanaAsignacion: string;
  unidadSeleccionada: string;
  indFuncionarioExistente: string;
  constructor() { }
}
