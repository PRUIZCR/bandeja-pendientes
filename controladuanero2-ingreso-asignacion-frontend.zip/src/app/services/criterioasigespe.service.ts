import { Injectable } from '@angular/core';
import { ConstantesRest } from 'src/app/utils/constantesrest';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { Observable, throwError } from 'rxjs';
import { CriterioAsigEspe } from "src/app/models/criterioasigespe";
import { catchError } from 'rxjs/operators';
import { HttpClient, HttpResponse } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})

export class CriterioAsigEspeService {
  constructor(private http: HttpClient) { }

  registrarPonderacion(lstCriterioAsigEspe: CriterioAsigEspe[], unidadDespachoSeleccionado: string) : Observable<any> {
    return this.http.post<HttpResponse<Object>>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_GRABAR_CRITERIO_ASIGNACION, unidadDespachoSeleccionado),
      lstCriterioAsigEspe, { observe: 'response' }).pipe(
        catchError(e => {
          return throwError(e.error);
        })
      );
  }

  listarCriteriosDeAsignacion(unidadDespachoSeleccionado: string,
                              campos: string) {
    return this.http.get<CriterioAsigEspe[]>(FuncionesGenerales.getInstance().reemplazarParametros(
      ConstantesRest.URL_LISTAR_CRITERIO_ASIGNACION,
      unidadDespachoSeleccionado,
      campos));
   }
}
