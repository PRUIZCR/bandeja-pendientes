import { ParametroRest } from './parametrorest';

export class ServicioRest {
  url: string;
  descripcion: string;
  tipoOperacion: string;
  tipoServicio: string;
  parametros: ParametroRest[];
}
