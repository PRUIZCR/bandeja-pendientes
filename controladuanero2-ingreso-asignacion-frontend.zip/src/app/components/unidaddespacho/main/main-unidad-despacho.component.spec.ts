import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MainUnidadDespachoComponent } from './main-unidad-despacho.component';

describe('MainUnidadDespachoComponent', () => {
  let component: MainUnidadDespachoComponent;
  let fixture: ComponentFixture<MainUnidadDespachoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MainUnidadDespachoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MainUnidadDespachoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
