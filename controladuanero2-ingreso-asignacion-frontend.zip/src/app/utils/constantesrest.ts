import { environment } from "src/environments/environment";

export class ConstantesRest {
  static CONTEXTO: string = sessionStorage.getItem("apiEndpoint");
  //environment.apiEndpoint + environment.localContext;
  //sessionStorage.getItem("apiEndpoint");//environment.apiEndpoint + environment.localContext; // "/cl-at-iaingreso-asignacion-ws";
  //Configuracion
  static URL_LISTAR_REGIMENES: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/obtenerregimenes";
  static URL_LISTAR_ADUANAS: string = ConstantesRest.CONTEXTO + "/funcionarios/{0}/aduanas?roles={1}&filtroSolicitudRF={2}";
  static URL_LISTAR_ANFORAS: string = ConstantesRest.CONTEXTO + "/unidadesdespacho/{0}/anforas";
  static URL_LISTAR_GRUPOS_TRABAJO: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/grupostrabajo?roles={0}";
  static URL_LISTAR_UNIDAD_DESPACHO: string = ConstantesRest.CONTEXTO + "/aduanas/{0}/unidaddespacho?estado={1}&f={2}";
  static URL_VALIDAR_UNIDAD_DESPACHO: string = ConstantesRest.CONTEXTO + "/unidadesdespacho/{0}/validarunidaddespacho?aduana={1}&descripcion={2}&indSorteoZona={3}&fecInicio={4}&fecFin={5}&regimen={6}";
  static URL_GRABAR_UNIDAD_DESPACHO: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/grabarunidaddespacho?c={0}&tk={1}";
  static URL_LISTAR_ZONA: string = ConstantesRest.CONTEXTO + "/unidadesdespacho/{0}/zonas?estado={1}&f={2}";
  static URL_GRABAR_ZONA: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/grabarzona";
  static URL_LISTAR_TURNO: string = ConstantesRest.CONTEXTO + "/unidadesdespacho/{0}/turnos?estado={1}&fechaVigenteDesde={2}&fechaVigenteHasta={3}&tipoValidacionRango={4}&indPermanente={5}&f={6}";
  static URL_GRABAR_TURNO: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/grabarturno";
  static URL_LISTAR_CRITERIO_ASIGNACION: string = ConstantesRest.CONTEXTO + "/unidadesdespacho/{0}/criteriosasignacion?f={1}";
  static URL_GRABAR_CRITERIO_ASIGNACION: string = ConstantesRest.CONTEXTO + "/unidadesdespacho/{0}/grabarcriteriosasignacion";
  static URL_LISTAR_LUGARES_RECONOCIMIENTO: string = ConstantesRest.CONTEXTO + "/unidadesdespacho/{0}/lugaresreconocimiento";
  static URL_LISTAR_LUGARES_RECONOCIMIENTO_ZONA: string = ConstantesRest.CONTEXTO + "/unidadesdespacho/{0}/obtenerGrupoAlmacenPorZona?zona={1}&ruc={2}";
  static URL_LISTAR_LOCAL_ANEXO_POR_RUC: string = ConstantesRest.CONTEXTO + "/unidadesdespacho/obtenerlocalanexoporruc?ruc={0}";
  static URL_GRABAR_LUGARES_RECONOCIMIENTO: string = ConstantesRest.CONTEXTO + "/unidadesdespacho/{0}/grabarlugaresreconocimiento";

  //Programacion
  static URL_BUSCAR_FUNCIONARIO: string = ConstantesRest.CONTEXTO + "/aduanas/{0}/funcionarios?codigo={1}&nombres={2}&grupoTrabajo={3}&filtroFuncionarioPorTurno={4}&regimen={5}";
  static URL_LISTAR_CATALOGO_FUNCIONARIOS: string = ConstantesRest.CONTEXTO + "/unidadesdespacho/{1}/funcionarios?tipo={0}&turno={2}&grupoTrabajo={3}&fechaInicio={4}&fechaFin={5}&codigoFuncionario={6}";
  static URL_GRABAR_CATALOGO_FUNCIONARIOS: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/grabarfuncionarios?turno={0}&grupoTrabajo={1}&fechaInicio={2}&fechaFin={3}";
  static URL_LISTAR_HORARIO: string = ConstantesRest.CONTEXTO + "/turnos/{1}/horarios?codAnfora={0}&fechaConsulta={2}&tipoConsulta={3}&fechaFin={4}";
  static URL_GRABAR_SORTEO: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/grabarsorteo";
  static URL_EXPORTAR_REPORTE_SORTEOS_ASIGNACION: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/reportesorteoasignacion?tipo={0}&turno={1}&anfora={2}&fechaInicio={3}&fechaFin={4}&f={5}";
  static URL_ASIGNACION_FUNCIONARIOS_ZONA: string = ConstantesRest.CONTEXTO + "/unidadesdespacho/{0}/obtenerfuncionarioszona?mes={1}&anho={2}";
  static URL_OBTENER_ASIGNACION_FUNCIONARIOS_ZONA: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/obtenerasignacionfuncionariozona/{0}";
  static URL_LISTAR_SORTEOS: string = ConstantesRest.CONTEXTO + "/sorteos/{0}/obtenerconfiltros?turno={1}&anfora={2}&fechaInicio={3}&fechaFin={4}&f={5}";
  static URL_ASIGNAR_FUNCIONARIOS_ALEATORIO: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/sortearfuncionariozona/{0}";
  static URL_GRABAR_ASIGNACION_FUNCIONARIO_ZONA: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/grabarfuncionariozona";
  static URL_REVERTIR_ASIGNACION_FUNCIONARIO_ZONA: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/revertirfuncionariozona/{0}";
  static URL_LISTA_FUNCIONARIO_DISPONIBLES: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/obtenerfuncionariosdisponibles?turno={0}&fechaAsignacion={1}&aduana={2}";
  static URL_LISTA_FUNCIONARIO_DISPONIBLES_RFU: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/obtenerfuncionariosdisponiblesrfu?fechaAsignacion={0}&aduana={1}";
  static URL_EXPORTAR_REPORTE_CATALOGO_FUNCIONARIOS: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/obtenerreporte?tipo={0}&unidad={1}&turno={2}&grupoTrabajo={3}&fechaInicio={4}&fechaFin={5}&codigoFuncionario={6}";
  //Post ejecucion
  static URL_CONSULTA_PAQUETES_VIGENCIA: string = ConstantesRest.CONTEXTO + "/funcionarios/vigenciarfu";
  static URL_GRABAR_REASIGNACION_PAQUETES_BLOQUE_RFU: string  = ConstantesRest.CONTEXTO + "/paquetes/{0}/reasignaciondepaqueterfu";
  static URL_OBTENER_DETALLES_PAQUETE: string = ConstantesRest.CONTEXTO + "/sorteos/{0}/paquetes?numHorario={1}&codAnfora={2}&tipoConsulta={3}&fecha={4}&numRucAlmacen={5}&fechaFin={6}&numeroTurno={7}&codigoRegistro={8}&codigoZona={9}&codigoLocal={10}&tipoPaquete={11}";
  static URL_OBTENER_DETALLE_ASIGNACION: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/obtenetdetalleasignacion?codAnfora={0}&numTurno={1}&numHorario={2}&rucAlmacen={3}&codLocalAnexo={4}&codFuncionario={5}&fechaDesde={6}&fechaHasta={7}";
  static URL_GRABAR_OPTIMIZACION_PAQUETES: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/grabarpaquetes?numSorteo={0}&numHorario={1}&fechaFormacionPaquete={2}";
  static URL_GRABAR_OPTIMIZACION_PAQUETES_RFU: string = ConstantesRest.CONTEXTO + "/funcionarios/grabarpaquetesrfu?aduana={0}&fechaFormacionPaquete={1}";
  static URL_GRABAR_REASIGNACION_PAQUETES_BLOQUE: string = ConstantesRest.CONTEXTO + "/paquetes/{0}/resignaciondepaquete";
  static URL_CONSULTA_PAQUETES_FORMADOS: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/obtenerpaquetes?anfora={0}&turno={1}&fechaInicio={2}&fechaFin={3}";
  static URL_EXPORTAR_REPORTE_PAQUETES: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/exportarpaquetes?tipoReporte={0}&anfora={1}&horario={2}&numSorteo={3}&fecha={4}";
  static URL_CONSULTA_PAQUETES_FORMADOS_RFU: string = ConstantesRest.CONTEXTO + "/sorteos/obtenerpaquetesrfu?codAduana={0}&fechaInicio={1}&fechaFin={2}";
  static URL_EXPORTAR_REPORTE_ASIGNACION_PAQUETES: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/exportarreporteasignaciones?tipoReporte={0}&codAnfora={1}&numTurno={2}&numHorario={3}&rucAlmacen={4}&codLocalAnexo={5}&codFuncionario={6}&fechaDesde={7}&fechaHasta={8}&numSorteo={9}&numZona={10}";
  static URL_EXPORTAR_REPORTE_ASIGNACION_PAQUETES_RFU: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/exportarreporteasignacionesrfu?codAduana={0}&tipoReporte={1}&rucAlmacen={2}&codLocalAnexo={3}&codFuncionario={4}&fechaDesde={5}&fechaHasta={6}";
  static URL_OBTENER_DETALLES_PAQUETE_RFU: string = ConstantesRest.CONTEXTO + "/sorteos/obtenerdetpaqueterfu?codAduana={0}&fecha={1}&tipoConsulta={2}&fechaHasta={3}&numRucAlmacen={4}&codigoLocal={5}&codigoRegistro={6}&numSecHorario={7}";
  static URL_EXPORTAR_REPORTE_PAQUETES_RFU: string = ConstantesRest.CONTEXTO + "/sorteos/exportarpaquetesrfu?tipoReporte={0}&codAduana={1}&fecha={2}&numSecHorario={3}";
  //Manual                                                                                                                               
  static URL_LISTAR_OPERACIONES_MANUALES: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/obtenertipooperacion?tipo={0}&roles={1}";
  static URL_LISTAR_REGIMENES_OPERACION: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/obteneroperacionregimenes?tipoOperacion={0}";
  static URL_OBTENER_SERVICIO_REST: string = ConstantesRest.CONTEXTO + "/funcionarios/USUARIO/obtenerservicio?tipoOperacion={0}&tipoServicio={1}";

  static _inicializarDesarrollo(esDesarrollo: boolean) {
    if (esDesarrollo) {
      this.URL_LISTAR_REGIMENES = ConstantesRest.CONTEXTO + "/configuracion/obtenerregimenes";
      this.URL_LISTAR_ADUANAS = ConstantesRest.CONTEXTO + "/configuracion/obteneraduanas?codigoUUOO={0}&roles={1}&filtroSolicitudRF={2}";
      this.URL_LISTAR_ANFORAS = ConstantesRest.CONTEXTO + "/configuracion/{0}/anforas";
      this.URL_LISTAR_GRUPOS_TRABAJO = ConstantesRest.CONTEXTO + "/configuracion/obtenergrupos?roles={0}";
      this.URL_LISTAR_UNIDAD_DESPACHO = ConstantesRest.CONTEXTO + "/configuracion/obtenerunidadesdespacho?aduana={0}&estado={1}&f={2}";
      this.URL_VALIDAR_UNIDAD_DESPACHO = ConstantesRest.CONTEXTO + "/configuracion/validarunidaddespacho?numUnidadDespacho={0}&aduana={1}&descripcion={2}&indSorteoZona={3}&fecInicio={4}&fecFin={5}&regimen={6}";
      this.URL_GRABAR_UNIDAD_DESPACHO = ConstantesRest.CONTEXTO + "/configuracion/grabarunidaddespacho?c={0}&tk={1}";
      this.URL_LISTAR_ZONA = ConstantesRest.CONTEXTO + "/configuracion/obtenerzonas?unidad={0}&estado={1}&f={2}";
      this.URL_GRABAR_ZONA = ConstantesRest.CONTEXTO + "/configuracion/grabarzona";
      this.URL_LISTAR_TURNO = ConstantesRest.CONTEXTO + "/configuracion/obtenerturnos?unidad={0}&estado={1}&fechaVigenteDesde={2}&fechaVigenteHasta={3}&tipoValidacionRango={4}&indPermanente={5}&f={6}";
      this.URL_GRABAR_TURNO = ConstantesRest.CONTEXTO + "/configuracion/grabarturno";
      this.URL_LISTAR_CRITERIO_ASIGNACION = ConstantesRest.CONTEXTO + "/configuracion/obtenercatalogocriterios?unidad={0}&f={1}";
      this.URL_GRABAR_CRITERIO_ASIGNACION = ConstantesRest.CONTEXTO + "/configuracion/grabarcatalogocriterios?unidad={0}";
      this.URL_LISTAR_LUGARES_RECONOCIMIENTO = ConstantesRest.CONTEXTO + "/configuracion/obtenerlugaresreconocimiento?unidad={0}";
      this.URL_LISTAR_LUGARES_RECONOCIMIENTO_ZONA = ConstantesRest.CONTEXTO + "/configuracion/obtenerGrupoAlmacenPorZona?unidad={0}&zona={1}&ruc={2}";
      this.URL_LISTAR_LOCAL_ANEXO_POR_RUC  = ConstantesRest.CONTEXTO + "/configuracion/obtenerLocalAnexoPorRuc?ruc={0}";
      this.URL_GRABAR_LUGARES_RECONOCIMIENTO = ConstantesRest.CONTEXTO + "/configuracion/grabarlugaresreconocimiento?unidad={0}";
      //Programacion
      this.URL_BUSCAR_FUNCIONARIO = ConstantesRest.CONTEXTO + "/programacion/obtenerfuncionarios?aduana={0}&codigo={1}&nombres={2}&grupoTrabajo={3}&filtroFuncionarioPorTurno={4}&regimen={5}";
      this.URL_LISTAR_CATALOGO_FUNCIONARIOS = ConstantesRest.CONTEXTO + "/programacion/obtenercatfuncionarios?tipo={0}&unidad={1}&turno={2}&grupoTrabajo={3}&fechaInicio={4}&fechaFin={5}&codigoFuncionario={6}";
      this.URL_GRABAR_CATALOGO_FUNCIONARIOS = ConstantesRest.CONTEXTO + "/programacion/grabarcatfuncionarios?turno={0}&grupoTrabajo={1}&fechaInicio={2}&fechaFin={3}";
      this.URL_LISTAR_HORARIO = ConstantesRest.CONTEXTO + "/programacion/obtenerhorarios?codAnfora={0}&numTurno={1}&fechaConsulta={2}&tipoConsulta={3}&fechaFin={4}";
      this.URL_GRABAR_SORTEO = ConstantesRest.CONTEXTO + "/programacion/grabarsorteo";
      this.URL_EXPORTAR_REPORTE_SORTEOS_ASIGNACION = ConstantesRest.CONTEXTO + "/programacion/reportesorteoasignacion?tipo={0}&turno={1}&anfora={2}&fechaInicio={3}&fechaFin={4}&f={5}";
      this.URL_ASIGNACION_FUNCIONARIOS_ZONA = ConstantesRest.CONTEXTO + "/programacion/obtenerfunczona?unidad={0}&mes={1}&anho={2}";
      this.URL_OBTENER_ASIGNACION_FUNCIONARIOS_ZONA = ConstantesRest.CONTEXTO + "/programacion/obtenerasigfunczona/{0}";
      this.URL_LISTAR_SORTEOS = ConstantesRest.CONTEXTO + "/programacion/obtenersorteos?sorteo={0}&turno={1}&anfora={2}&fechaInicio={3}&fechaFin={4}&f={5}";
      this.URL_ASIGNAR_FUNCIONARIOS_ALEATORIO = ConstantesRest.CONTEXTO + "/programacion/sortearfunczona/{0}";
      this.URL_GRABAR_ASIGNACION_FUNCIONARIO_ZONA = ConstantesRest.CONTEXTO + "/programacion/grabarfunczona";
      this.URL_REVERTIR_ASIGNACION_FUNCIONARIO_ZONA = ConstantesRest.CONTEXTO + "/programacion/revertirfunczona/{0}";
      this.URL_LISTA_FUNCIONARIO_DISPONIBLES = ConstantesRest.CONTEXTO + "/programacion/obtenerfuncdisponibles?turno={0}&fechaAsignacion={1}&aduana={2}";
      this.URL_LISTA_FUNCIONARIO_DISPONIBLES_RFU = ConstantesRest.CONTEXTO + "/programacion/obtenerfuncdisponiblesrfu?fechaAsignacion={0}&aduana={1}";
      this.URL_EXPORTAR_REPORTE_CATALOGO_FUNCIONARIOS = ConstantesRest.CONTEXTO + "/programacion/exportarfuncionarios?tipo={0}&unidad={1}&turno={2}&grupoTrabajo={3}&fechaInicio={4}&fechaFin={5}&codigoFuncionario={6}";
      //Post ejecucion
      this.URL_CONSULTA_PAQUETES_VIGENCIA = ConstantesRest.CONTEXTO + "/postejecucion/vigenciarfu";
      this.URL_GRABAR_REASIGNACION_PAQUETES_BLOQUE_RFU = ConstantesRest.CONTEXTO + "/postejecucion/resignarpaqueterfu/{0}";
      this.URL_OBTENER_DETALLES_PAQUETE = ConstantesRest.CONTEXTO + "/postejecucion/obtenerdetpaquete?numSorteo={0}&numHorario={1}&codAnfora={2}&tipoConsulta={3}&fecha={4}&numRucAlmacen={5}&fechaFin={6}&numeroTurno={7}&codigoRegistro={8}&codigoZona={9}&codigoLocal={10}&tipoPaquete={11}";
      this.URL_OBTENER_DETALLE_ASIGNACION = ConstantesRest.CONTEXTO + "/postejecucion/obtenerdetasignacion?codAnfora={0}&numTurno={1}&numHorario={2}&rucAlmacen={3}&codLocalAnexo={4}&codFuncionario={5}&fechaDesde={6}&fechaHasta={7}";
      this.URL_GRABAR_OPTIMIZACION_PAQUETES = ConstantesRest.CONTEXTO + "/postejecucion/grabarpaquetes?numSorteo={0}&numHorario={1}&fechaFormacionPaquete={2}";
      this.URL_GRABAR_OPTIMIZACION_PAQUETES_RFU = ConstantesRest.CONTEXTO + "/postejecucion/grabarpaquetesrfu?aduana={0}&fechaFormacionPaquete={1}";
      this.URL_GRABAR_REASIGNACION_PAQUETES_BLOQUE = ConstantesRest.CONTEXTO + "/postejecucion/resignarpaquete/{0}";
      this.URL_CONSULTA_PAQUETES_FORMADOS = ConstantesRest.CONTEXTO + "/postejecucion/obtenerpaquetes?anfora={0}&turno={1}&fechaInicio={2}&fechaFin={3}";
      this.URL_EXPORTAR_REPORTE_PAQUETES = ConstantesRest.CONTEXTO + "/postejecucion/exportarpaquetes?tipoReporte={0}&anfora={1}&horario={2}&numSorteo={3}&fecha={4}";
      this.URL_EXPORTAR_REPORTE_ASIGNACION_PAQUETES = ConstantesRest.CONTEXTO + "/postejecucion/exportardetasignacion?tipoReporte={0}&codAnfora={1}&numTurno={2}&numHorario={3}&rucAlmacen={4}&codLocalAnexo={5}&codFuncionario={6}&fechaDesde={7}&fechaHasta={8}&numSorteo={9}&numZona={10}";
      this.URL_EXPORTAR_REPORTE_ASIGNACION_PAQUETES_RFU = ConstantesRest.CONTEXTO + "/postejecucion/exportardetasignacionrfu?codAduana={0}&tipoReporte={1}&rucAlmacen={2}&codLocalAnexo={3}&codFuncionario={4}&fechaDesde={5}&fechaHasta={6}";
      this.URL_CONSULTA_PAQUETES_FORMADOS_RFU = ConstantesRest.CONTEXTO + "/postejecucion/obtenerpaquetesrfu?codAduana={0}&fechaInicio={1}&fechaFin={2}";
      this.URL_OBTENER_DETALLES_PAQUETE_RFU = ConstantesRest.CONTEXTO + "/postejecucion/obtenerdetpaqueterfu?codAduana={0}&fecha={1}&tipoConsulta={2}&fechaHasta={3}&numRucAlmacen={4}&codigoLocal={5}&codigoRegistro={6}&numSecHorario={7}";
      this.URL_EXPORTAR_REPORTE_PAQUETES_RFU = ConstantesRest.CONTEXTO + "/postejecucion/exportarpaquetesrfu?tipoReporte={0}&codAduana={1}&fecha={2}&numSecHorario={3}";
      //Manual                                                                                                        
      this.URL_LISTAR_OPERACIONES_MANUALES = ConstantesRest.CONTEXTO + "/manual/obteneropermanuales?tipo={0}&roles={1}";
      this.URL_LISTAR_REGIMENES_OPERACION = ConstantesRest.CONTEXTO + "/manual/obtenerregimenesoper?tipoOperacion={0}";
      this.URL_OBTENER_SERVICIO_REST = ConstantesRest.CONTEXTO + "/manual/obtenerservicio?tipoOperacion={0}&tipoServicio={1}";
    }
  }
  constructor () { }
}

//ConstantesRest._inicializarDesarrollo(!environment.production);
