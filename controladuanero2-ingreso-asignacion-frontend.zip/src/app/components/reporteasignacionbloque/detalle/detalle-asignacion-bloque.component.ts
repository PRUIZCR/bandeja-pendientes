import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { TmpPaquete } from 'src/app/models/TmpPaquete';
import { MatSort  } from '@angular/material/sort';
import { MatPaginator  } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material';
import { ConstantesListas } from 'src/app/utils/constanteslistas';
import { Anfora } from 'src/app/models/anfora';

@Component({
  selector: 'app-detalle-asignacion-bloque',
  templateUrl: './detalle-asignacion-bloque.component.html',
  styleUrls: ['./detalle-asignacion-bloque.component.css']
})
export class DetalleAsignacionBloqueComponent implements OnInit {
  @Input() itemPaquete: TmpPaquete;
  @Input() esVigenteRfu: boolean;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  lstDuasAnfora: Anfora[];
  duasAnforaDS: MatTableDataSource<Anfora>;
  displayedColumns: string[];

  constructor() { }

  ngOnInit() {
    this.displayedColumns = ConstantesListas.COLUMNAS_GRID_DECLARACION(this.esVigenteRfu);
    this.duasAnforaDS = new MatTableDataSource<Anfora>(this.itemPaquete.listaDuasAnfora);
  }

}
