import { Observable } from 'rxjs/Observable';
import { Component, OnInit, ViewChild, ɵConsole } from '@angular/core';
import { ConstantesListas } from 'src/app/utils/constanteslistas';
import { setTheme } from 'ngx-bootstrap/utils';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { FuncionariosDetalle } from 'src/app/models/funcionariosdetalle';
import { FuncionariosResumen } from 'src/app/models/funcionariosresumen';
import { ResponseManager } from 'src/app/models/responsemanager';
import { ResponseErrorManager } from 'src/app/models/responseerrormanager';
import { Datacatalogo } from 'src/app/models/datacatalogo';
import { Unidaddespacho } from 'src/app/models/unidaddespacho';
import { Turno } from 'src/app/models/turno';
import { CatEmpleadoService } from 'src/app/services/catempleado.service';
import { CatalogofuncionarioService } from 'src/app/services/catalogofuncionario.service';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { MatTableDataSource, MatDatepickerInputEvent } from '@angular/material';
import esLocale from '@fullcalendar/core/locales/es';
import { CalendarComponent } from 'ng-fullcalendar';
import interactionPlugin from '@fullcalendar/interaction';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import { OptionsInput } from '@fullcalendar/core';
import { ConsultaSeleccionfuncionariosComponent } from 'src/app/components/seleccionfuncionarios/consulta/consulta-seleccionfuncionarios.component';
import { TurnoFuncionariosComponent } from 'src/app/components/catalogofuncionarios/turno/turno-funcionarios.component';
import { CatEmpleado } from 'src/app/models/catempleado';
import { MatSort  } from '@angular/material/sort';
import { MatPaginator  } from '@angular/material/paginator';
import { ConstantesExcepciones } from 'src/app/utils/constantesExcepciones';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { FuncionarioDisponible } from 'src/app/models/funcionariodisponible';
import { CatalogoService } from 'src/app/services/catalogo.service';
import { UnidaddespachoService } from 'src/app/services/unidaddespacho.service'
import { TurnoService } from 'src/app/services/turno.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-main-funcionarios',
  templateUrl: './main-funcionarios.component.html',
  styleUrls: ['./main-funcionarios.component.css']
})
export class MainFuncionariosComponent implements OnInit {
  @ViewChild(CalendarComponent) ufullcalendar: CalendarComponent;
  @ViewChild(ConsultaSeleccionfuncionariosComponent) child: ConsultaSeleccionfuncionariosComponent;
  @ViewChild(TurnoFuncionariosComponent) childTurno: TurnoFuncionariosComponent;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('motivoModal') motivoModal: ModalDirective;
  @ViewChild('modificarVigenciaModal') modificarVigenciaModal: ModalDirective;
  @ViewChild('nuevaVigenciaModal') nuevaVigenciaModal: ModalDirective;
  txtFecha: string;
  txtHora: string;
  fechaActual: Date;
  aduanas: Datacatalogo[];
  lstGrupoFuncionarios: Datacatalogo[];
  aduanaSeleccionada: string;
  objAduanaSeleccionada: Datacatalogo;
  objUnidadDespachoSeleccionado: Unidaddespacho;
  objGrupoFuncionarioSeleccionado: Datacatalogo;
  lstUnidadDespacho: Unidaddespacho[];
  lstTurnos: Turno[];
  turnoSinHorario: Turno;
  unidadDespachoSeleccionado: string;
  grupoFuncionarioSeleccionado: string;
  turnoSeleccionado: string;
  hayFuncionarios: boolean = false;
  hayParametrosDeBusqueda: boolean = true;
  deshabilitarParametrosBuqueda: boolean = false;
  habilitarAgregarFuncionarios: boolean = false;
  fechaVigenteDesde: Date = new Date();
  fechaVigenteHasta: Date = new Date();
  minDate: Date = new Date();
  responseManager: ResponseManager;
  responseErrorManager: ResponseErrorManager;
  funcionariosDetalle: FuncionariosDetalle[];
  funcionariosResumen: FuncionariosResumen[];
  objRegistro: string;
  objRegistroAP: string;
  lstCatEmpleado: CatEmpleado[];
  estadoOperacion$: Observable<CatEmpleado>;
  estadoOperacionFuncionario$: Observable<FuncionariosDetalle>;
  objCatEmpleado: CatEmpleado;
  objFuncionarioDisponible: FuncionarioDisponible;
  funcionariosResumenDS: MatTableDataSource<FuncionariosResumen>;
  displayedColumns: string[];
  funcionesGenerales: FuncionesGenerales;
  desabilitarCriterioRegistro: Boolean = true;
  desabilitarCriterioAP: Boolean = true;
  habilitarSeleccion: Boolean = false;
  objTurnoSeleccionado: Turno;
  aduanaVigencia: string;
  unidadDespachoVigencia: string;
  grupoFuncionariosVigencia: string;
  turnoVigencia: string;
  tituloModal: string;
  minDateM: Date;
  maxDateM: Date;
  fechaMVigenteDesde: Date;
  fechaMVigenteHasta: Date;
  fechaNVigenteDesde: Date;
  fechaNVigenteHasta: Date;
  modVigMotivo: string;
  modRetirarMotivo: string;
  objFuncionarioSeleccionado: FuncionariosResumen;
  options: OptionsInput;
  deleteMotivo: string;
  controlCambios: Boolean = false; //cchavezt ATENCION BUGS
  //cchavezt ATENCION BUG P_SNAA0001-24531
  filtroRegistro: string = ConstantesCadenas.FILTRO_REGISTRO;
  filtroRegistroAP: string = ConstantesCadenas.FILTRO_REGISTROAP;
  mostrarTurno: Boolean = false;
  //cchavezt ATENCION BUG P_SNAA0001-24531

  @ViewChild('fullcalendar') fullcalendar: CalendarComponent;
  constructor(private catEmpleadoService: CatEmpleadoService,
              private catalogofuncionarioService: CatalogofuncionarioService,
              private catalogoService: CatalogoService,
              private unidaddespachoService: UnidaddespachoService,
              private turnoService: TurnoService
              ) {
    setTheme('bs4');
    this.objCatEmpleado = new CatEmpleado();
    this.objFuncionarioDisponible = new FuncionarioDisponible();
  }
  ngOnInit() {
    this.mostrarTurno = false;

    this.catalogoService.listarGruposTrabajo().subscribe(result => {
      //FuncionesGenerales.getInstance().cerrarModalCargando();
      this.lstGrupoFuncionarios = result as Datacatalogo[];
      if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstGrupoFuncionarios)) {
        this.lstGrupoFuncionarios.map(
          gf => {
            gf.codDatacat = gf.cod_datacat;
          }
        );
        this.grupoFuncionarioSeleccionado = this.lstGrupoFuncionarios[0].cod_datacat; //ConstantesCadenas.SELECCIONAR_GRUPO_FUNCIONARIO;
        this.objGrupoFuncionarioSeleccionado = this.lstGrupoFuncionarios.find(x => x.cod_datacat == this.grupoFuncionarioSeleccionado);
        this.mostrarTurno = this.objGrupoFuncionarioSeleccionado.indPermanente !== '1';
      }
    }, error => console.error(error));

    this.catalogoService.listarAduanas().subscribe(result => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.aduanaSeleccionada = result.aduana;
      this.aduanas = result.listaAduanas as Datacatalogo[];
      if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.aduanas)) {
        this.aduanas.map(
          x => (
            x.codDatacat = x.cod_datacat
          )
        );
        this.cargarControles();
      }
    }, error => console.error(error));

    this.fechaActual = new Date();
    this.txtFecha = ('00' + this.fechaActual.getDate()).slice(-2) + '/' +
                    ('00' + (this.fechaActual.getMonth() + 1)).slice(-2) + '/' +
                    this.fechaActual.getFullYear();
    this.txtHora = ('00' + this.fechaActual.getHours()).slice(-2) + ':' +
                   ('00' + this.fechaActual.getMinutes()).slice(-2) + ':' +
                   ('00' + this.fechaActual.getSeconds()).slice(-2);
    this.funcionariosDetalle = [];
    this.options = {
       editable: false,
       events:  this.funcionariosDetalle,
       height: 700,
       contentHeight: 650,
       aspectRatio: 1.75,
       timeZone: 'UTC',
       defaultView: 'dayGridMonth',
       locale: esLocale,
       eventTextColor: '#FFF',
       header: {
         left: 'prev,next today',
         center: 'title'
       },
       plugins: [ interactionPlugin, dayGridPlugin, timeGridPlugin ]
     };
     this.estadoOperacion$ = this.child.getEstadoOperacion$();
     this.estadoOperacion$.subscribe(x => {
       if (x != null && Object.entries(x).length != 0) {
         this.objCatEmpleado = x as CatEmpleado;
         this.mostrarFiltroFuncionarios(this.objCatEmpleado);
         this.habilitarSeleccion = true;
         this.habilitarAgregarFuncionarios = true;
       } else {
         this.objCatEmpleado = null;
       }
      }
    );
    this.funcionesGenerales = FuncionesGenerales.getInstance();
    this.displayedColumns = ConstantesListas.COLUMNAS_GRID_FUNCIONARIO_RESUMEN;
    this.funcionariosResumenDS = new MatTableDataSource<FuncionariosResumen>([]);
    this.funcionariosResumenDS.sort = this.sort;
    this.funcionariosResumenDS.paginator = this.paginator;
    this.objRegistro = '';
    this.objRegistroAP = '';
    this.habilitarAgregarFuncionarios = false;
    this.objTurnoSeleccionado = new Turno();
    this.estadoOperacionFuncionario$ = this.childTurno.getEstadoOperacion$();
    this.estadoOperacionFuncionario$.subscribe(x => this.actualizarCalendario(x as FuncionariosDetalle));
    this.lstTurnos = [];
  }
  cargarControles() {
    this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == this.aduanaSeleccionada);
    this.lstUnidadDespacho = [];
    this.cargarUnidadesDespacho();
  }
  changeVigenteDesde(obj: MatDatepickerInputEvent<Date>){
    console.log('changeVigenteDesde => ');
    if(FuncionesGenerales.getInstance().compararFechas(
        FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(new Date()),
        ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
        FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(obj.value),
        ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 1)
    {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA,
                                                                  ConstantesExcepciones.DEFAULT_TITTLE_EXCEPTION, ConstantesExcepciones.EXCEPCION_UNO, "");
      return false;
    }
    if (this.fechaVigenteHasta != undefined && this.fechaVigenteHasta != null) {
      if (FuncionesGenerales.getInstance().compararFechas(
        FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(obj.value),
        ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
        FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteHasta),
        ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 1) {
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA,
          ConstantesExcepciones.DEFAULT_TITTLE_EXCEPTION, ConstantesExcepciones.EXCEPCION_DOS, "");
        return false;
      }  else {
        console.log('cargarTurnoPorFechas => ');
        this.cargarTurnoPorFechas();
      }
    } else {
      console.log('cargarTurnoPorFechas => ');
      this.cargarTurnoPorFechas();
    }
  }
  changeVigenteHasta(obj: MatDatepickerInputEvent<Date>) {
    console.log('changeVigenteHasta => ');
    if (this.fechaVigenteDesde != undefined && this.fechaVigenteDesde != null) {
      if (FuncionesGenerales.getInstance().compararFechas(
        FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteDesde),
        ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
        FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(obj.value),
        ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 1) {
         FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA,
          ConstantesExcepciones.DEFAULT_TITTLE_EXCEPTION, ConstantesExcepciones.EXCEPCION_DOS, "");
        return false;
      } else {
        console.log('cargarTurnoPorFechas => ');
        this.cargarTurnoPorFechas();
      }
    } else {
      console.log('cargarTurnoPorFechas => ');
      this.cargarTurnoPorFechas();
    }
  }

  changeVigenteDesdeMV(obj: MatDatepickerInputEvent<Date>) {
    if(FuncionesGenerales.getInstance().compararFechas(
        FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(new Date()),
        ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
        FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(obj.value),
        ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 1)
    {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA,
                                                                  ConstantesExcepciones.DEFAULT_TITTLE_EXCEPTION, ConstantesExcepciones.EXCEPCION_UNO, "");
      return false;
    }
    if (this.fechaVigenteHasta != undefined && this.fechaVigenteHasta != null) {
      if (FuncionesGenerales.getInstance().compararFechas(
        FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(obj.value),
        ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
        FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteHasta),
        ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 1) {
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA,
          ConstantesExcepciones.DEFAULT_TITTLE_EXCEPTION, ConstantesExcepciones.EXCEPCION_DOS, "");
        return false;
      }
    }
  }

  seleccionarAduana(objSeleccionado) {
    this.aduanaSeleccionada = objSeleccionado.target.value;
    this.lstTurnos = [];
    this.turnoSeleccionado = "";
    if (objSeleccionado.target.value != "") {
      this.objAduanaSeleccionada = this.aduanas.find(element => element.cod_datacat == objSeleccionado.target.value);
      this.cargarUnidadesDespacho();
    }
  }

  cargarUnidadesDespacho() {
    console.log('cargarUnidadesDespacho => ');
    let campos: string = 'numUnidadDespacho,nombre';
    this.unidaddespachoService.listarUnidadesDespacho(this.aduanaSeleccionada,
                                                      ConstantesCadenas.ESTADO_VIGENTE,
                                                      campos).subscribe(result => {
        FuncionesGenerales.getInstance().cerrarModalCargando();
        this.lstUnidadDespacho = result as Unidaddespacho[];
        if (this.aduanaSeleccionada != "" && FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstUnidadDespacho)) {
          this.lstUnidadDespacho = this.lstUnidadDespacho.sort(FuncionesGenerales.getInstance().ordenarPor("numUnidadDespacho", false));
          this.unidadDespachoSeleccionado = this.lstUnidadDespacho[0].numUnidadDespacho.toString();
          this.objUnidadDespachoSeleccionado = this.lstUnidadDespacho.find(element => element.numUnidadDespacho == parseInt(this.unidadDespachoSeleccionado));
          console.log('this.cargarTurnos(false, false) => ');
          this.cargarTurnos(false, false);
          console.log('this.cargarTurnoSinHorario => ');
          this.cargarTurnoSinHorario();
        } else {
          this.lstUnidadDespacho = [];
          this.unidadDespachoSeleccionado = "";
          this.lstTurnos = [];
          this.turnoSeleccionado = "";
          let errorMensaje: string = "No existen unidades de despacho asignadas a la Aduana " + this.objAduanaSeleccionada.des_corta;
          let tituloErrores: string = "Mensaje de Error: ";
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                      tituloErrores, errorMensaje, "");
        }
    }, error => console.error(error));
  }

  cargarTurnoPorFechas() {
    console.log('cargarTurnoPorFechas => ');
    if (this.unidadDespachoSeleccionado != undefined && this.unidadDespachoSeleccionado != null && this.unidadDespachoSeleccionado != "" &&
        this.fechaVigenteDesde != undefined && this.fechaVigenteDesde != null &&
        this.fechaVigenteHasta != undefined && this.fechaVigenteHasta != null) {
      console.log('this.cargarTurnos(true, true) => ');
      this.cargarTurnos(true, true);
      console.log('this.cargarTurnoSinHorario => ');
      this.cargarTurnoSinHorario();
    }
  }

  cargarTurnoSinHorario() {
    let campos: string = 'numTurno,nombre,hraInicio,hraFin,fecInicioVigencia,fecFinVigencia,indPermanente';
    this.turnoService.listarTurnos(this.unidadDespachoSeleccionado,
                                   ConstantesCadenas.ESTADO_VIGENTE,
                                   "",
                                   "",
                                   campos,
                                   "",
                                   '1').subscribe(result => {
       this.turnoSinHorario = (result as Turno[])[0];
       if (this.objGrupoFuncionarioSeleccionado.indPermanente && this.objGrupoFuncionarioSeleccionado.indPermanente === '1') {
        this.turnoSeleccionado = this.turnoSinHorario.numTurno.toString();
        this.objTurnoSeleccionado = this.turnoSinHorario;
       }
       console.log('turnoSeleccionado: ' + this.turnoSeleccionado);
       console.log('this.objTurnoSeleccionado : ' + this.objTurnoSeleccionado.numTurno);
       console.log('this.objGrupoFuncionarioSeleccionado : ' + this.objGrupoFuncionarioSeleccionado.indPermanente);
    }, error => console.error(error));
  }

  cargarTurnos(esFechaInicio: boolean, esFechaFin: boolean) {
    let campos: string = 'numTurno,nombre,hraInicio,hraFin,fecInicioVigencia,fecFinVigencia';
    if (esFechaInicio && esFechaFin) {
      this.turnoService.listarTurnos(this.unidadDespachoSeleccionado,
                                        ConstantesCadenas.ESTADO_VIGENTE,
                                        (esFechaInicio ? FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteDesde) : ""),
                                        (esFechaFin ? FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteHasta) : ""),
                                        campos, "X").subscribe(result => {
        FuncionesGenerales.getInstance().cerrarModalCargando();
        this.lstTurnos = result as Turno[];
        if (this.unidadDespachoSeleccionado != '' && FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstTurnos)) {
          this.lstTurnos = this.lstTurnos.sort(FuncionesGenerales.getInstance().ordenarPor('numTurno', false));
          this.turnoSeleccionado = this.lstTurnos[0].numTurno.toString();
          this.objTurnoSeleccionado = this.lstTurnos.find(element => element.numTurno == parseInt(this.turnoSeleccionado))
        } else {
          if (!(this.objGrupoFuncionarioSeleccionado.indPermanente && this.objGrupoFuncionarioSeleccionado.indPermanente === '1')) {
                this.turnoSeleccionado = "";
                this.lstTurnos = [];
                let errorMensaje: string = 'No existen turnos asociados a la unidad de despacho ' + this.objUnidadDespachoSeleccionado.descripcion;
                let tituloErrores: string = 'Mensaje de Error: ';
                FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                            tituloErrores, errorMensaje, '');
          }
        }
      }, error => console.error(error));
    } else {
      this.turnoService.listarTurnos(this.unidadDespachoSeleccionado,
                  ConstantesCadenas.ESTADO_VIGENTE,
                  "",
                  "",
                  campos).subscribe(result => {
          FuncionesGenerales.getInstance().cerrarModalCargando();
          this.lstTurnos = result as Turno[];
          if (this.unidadDespachoSeleccionado != '' && FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstTurnos)) {
            this.lstTurnos = this.lstTurnos.sort(FuncionesGenerales.getInstance().ordenarPor('numTurno', false));
            this.turnoSeleccionado = this.lstTurnos[0].numTurno.toString();
            this.objTurnoSeleccionado = this.lstTurnos.find(element => element.numTurno == parseInt(this.turnoSeleccionado))
          } else {
            if (!(this.objGrupoFuncionarioSeleccionado.indPermanente && this.objGrupoFuncionarioSeleccionado.indPermanente === '1')) {
              this.turnoSeleccionado = "";
              this.lstTurnos = [];
              let errorMensaje: string = 'No existen turnos asociados a la unidad de despacho ' + this.objUnidadDespachoSeleccionado.descripcion;
              let tituloErrores: string = 'Mensaje de Error: ';
              FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                      tituloErrores, errorMensaje, '');
          }
        }
      }, error => console.error(error));
    }
  }

  seleccionarUnidadDespacho(objSeleccionado) {
    this.unidadDespachoSeleccionado = objSeleccionado.target.value;
    this.lstTurnos = [];
    this.turnoSeleccionado = "";
    if (objSeleccionado.target.value != '') {
      this.objUnidadDespachoSeleccionado = this.lstUnidadDespacho.find(element => element.numUnidadDespacho == objSeleccionado.target.value);
      this.fechaVigenteDesde = new Date();
      this.fechaVigenteHasta = new Date();
      console.log('this.cargarTurnos(false, false) => ');
      this.cargarTurnos(false, false);
      console.log('this.cargarTurnoSinHorario => ');
      this.cargarTurnoSinHorario();
    }
  }
//cchavezt ATENCION BUGS
  cancelarFuncionarios() {

    if(this.controlCambios){
        Swal.fire({
        title: "Mensajes de Advertencia: ",
        text: "Se han realizado cambios en la lista de funcionarios. Si continúa los cambios serán deshechos. ¿Está seguro que desea deshacer los cambios?",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        confirmButtonText: "SI",
        cancelButtonColor: '#d33',
        cancelButtonText: "NO"
      }).then((result) => {
        if (result.value) {
          this.limpiarFuncionarios();
        }
      });
    }
    else{
      this.limpiarFuncionarios();
    }
  }//cchavezt ATENCION BUGS

  limpiarFuncionarios() {
    this.desabilitarCriterioAP=true;
    this.desabilitarCriterioRegistro=true;
    this.deshabilitarParametrosBuqueda = false;
    this.hayFuncionarios = false;
    this.hayParametrosDeBusqueda = true;
    this.funcionariosDetalle = [];
    this.funcionariosResumen = [];
    this.ufullcalendar.calendar.removeAllEvents();
    this.controlCambios=false;
    this.ngOnInit();
  }

  seleccionarGrupoFuncionarios(objSeleccionado) {
    console.log('seleccionarGrupoFuncionarios => ');
    console.log('cargarTurnoPorFechas => ');
    this.cargarTurnoPorFechas();
    this.grupoFuncionarioSeleccionado = objSeleccionado.target.value;
    if (objSeleccionado.target.value != '') {
      this.objGrupoFuncionarioSeleccionado = this.lstGrupoFuncionarios.find(element => element.cod_datacat == objSeleccionado.target.value);
      if (this.objGrupoFuncionarioSeleccionado.indPermanente && this.objGrupoFuncionarioSeleccionado.indPermanente === '1') {
        this.mostrarTurno = false;
        this.turnoSeleccionado = this.turnoSinHorario.numTurno.toString();
        this.objTurnoSeleccionado = this.turnoSinHorario;
      } else if (!this.mostrarTurno) {
        if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.lstTurnos)) {
          this.turnoSeleccionado = this.lstTurnos[0].numTurno.toString();
          this.objTurnoSeleccionado = this.lstTurnos[0];
        } else {
          this.turnoSeleccionado = "";
          this.objTurnoSeleccionado = null;
          let errorMensaje: string = 'No existen turnos asociados a la unidad de despacho ' + this.objUnidadDespachoSeleccionado.descripcion;
          let tituloErrores: string = 'Mensaje de Error: ';
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                      tituloErrores, errorMensaje, '');
        }
        this.mostrarTurno = true;
      }
    }
    console.log('mostrarTurno => ' + this.mostrarTurno);
    console.log('this.turnoSeleccionado => ' + this.turnoSeleccionado);
    console.log('this.objTurnoSeleccionado => ' + this.objTurnoSeleccionado.numTurno);
    console.log('this.objTurnoSeleccionado.indPermanente => ' + this.objTurnoSeleccionado.indPermanente);
  }

  consultarCatalogo() {
    if (!this.validarParametrosDeConsulta()) {
      return false;
    }
    this.consultarCatalogoFuncionarios();
    this.hayParametrosDeBusqueda = false;
    this.hayFuncionarios = true;
  }

  consultarCatalogoFuncionarios() {
    console.log('consultarCatalogoFuncionarios =>');
    console.log('this.turnoSeleccionado => ' +  this.turnoSeleccionado);
    console.log('this.objTurnoSeleccionado.num_turno => ' +  this.objTurnoSeleccionado.numTurno.toString());
    console.log('this.grupoFuncionarioSeleccionado => ' +  this.grupoFuncionarioSeleccionado);
    this.turnoSeleccionado =  this.objTurnoSeleccionado.numTurno.toString();
    this.catEmpleadoService.obtenerCatalogoFuncionarios(
      ConstantesCadenas.TIPO_CONSULTA_FUNCIONARIOS_REGISTRO,
      this.unidadDespachoSeleccionado,
      //this.turnoSeleccionado,
      this.objTurnoSeleccionado.numTurno.toString(),
      this.grupoFuncionarioSeleccionado,
      this.fechaVigenteDesde,
      this.fechaVigenteHasta
    ).subscribe(response => {
      FuncionesGenerales.getInstance().cerrarModalCargando();
      this.deshabilitarParametrosBuqueda = true;
      this.funcionariosDetalle = response.funcionariosDetalle;
      this.funcionariosResumen = response.funcionariosResumen;
      if (FuncionesGenerales.getInstance().validarListaNoVaciaONula(this.funcionariosDetalle)) {
        this.objTurnoSeleccionado = this.funcionariosDetalle[0].turno as Turno;
        this.turnoSeleccionado = this.funcionariosDetalle[0].turno.numTurno.toString();
        console.log('Inicio - Se setea los turnos correctos');
        console.log('------------------------------');
        console.log('this.objTurnoSeleccionado =>' + this.objTurnoSeleccionado.numTurno);
        console.log('this.turnoSeleccionado =>' + this.turnoSeleccionado);
        console.log('this.objGrupoFuncionarioSeleccionado.indPermanente =>' + this.objGrupoFuncionarioSeleccionado.indPermanente);
        console.log('this.objGrupoFuncionarioSeleccionado.cod_datacat =>' + this.objGrupoFuncionarioSeleccionado.cod_datacat);
        console.log('Fin - Se setea los turnos correctos');
      }
      // setteo de propiedad traído de DB
      this.funcionariosDetalle.map(fd => (
      fd.funcionarios.map(fdf => (fdf.esDeBD = true))
      ));
      this.funcionariosResumen.map(fr => (fr.saved = true));
      console.log('this.funcionariosDetalle =>' + this.funcionariosDetalle);
      console.log('this.funcionariosResumen =>' + this.funcionariosResumen);
      this.cargarCalendario(this.funcionariosDetalle);
      this.cargarListaFuncionariosResumen(this.funcionariosResumen);
      this.objRegistro = '';
      this.objRegistroAP = '';
    },
    errorResult => {
      this.deshabilitarParametrosBuqueda = false;
      if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
        let responseManager: ResponseManager = new ResponseManager();
        this.responseErrorManager = errorResult as ResponseErrorManager;
        responseManager.cod = errorResult.cod;
        responseManager.errors = [this.responseErrorManager];
        this.responseManager = responseManager;
        this.cargarMensajesCatalogoFuncionarios(this.responseManager);
      } else {
        this.responseManager = errorResult as ResponseManager;
        this.cargarMensajesCatalogoFuncionarios(this.responseManager);
      }
    });
  }
  buscarCatalogoFuncionarios(hayFuncionario: boolean, filtroRegistroUsado: string) {
    let habilitarBusqueda: boolean = true;
    let registro: string = '';
    let registroAP: string = '';
    if (this.habilitarSeleccion) {
      registro = this.objRegistro.replace(/“/g, '"').replace(/”/g, '"');
      registroAP = this.objRegistroAP.replace(/“/g, '"').replace(/”/g, '"');
      if (this.desabilitarCriterioRegistro) {
        registroAP = '';
        habilitarBusqueda = true;
      } else {
        registro = '';
        if (registroAP == '') {
          habilitarBusqueda = false;
          this.habilitarSeleccion = false;
          this.objRegistro = registro;
          this.desabilitarCriterioRegistro = true;
        } else {
          habilitarBusqueda = true;
        }
      }
    } else {
      if (this.objRegistro.length > 0 && this.objRegistroAP.length == 0) {
        if (this.desabilitarCriterioRegistro) {
          this.desabilitarCriterioRegistro = true;
          this.desabilitarCriterioAP = false;
        } else {
          this.desabilitarCriterioRegistro = true;
          this.desabilitarCriterioAP = true;
          this.objRegistro = '';
          habilitarBusqueda = false;
        }
      } else if (this.objRegistroAP.length > 0 && this.objRegistro.length == 0) {
        if (this.desabilitarCriterioAP) {
          this.desabilitarCriterioRegistro = false;
          this.desabilitarCriterioAP = true;
        } else {
          this.desabilitarCriterioRegistro = true;
          this.desabilitarCriterioAP = true;
          this.objRegistroAP = '';
          habilitarBusqueda = false;
        }
      } else if (this.objRegistroAP.length == 0 && this.objRegistro.length == 0) {
        this.desabilitarCriterioRegistro = true;
        this.desabilitarCriterioAP = true;
        this.objRegistro = '';
        this.objRegistroAP = '';
        habilitarBusqueda = false;
      } else if (this.objRegistroAP.length > 0 && this.objRegistro.length > 0) {
        if (this.desabilitarCriterioAP) {
          this.objRegistro = '';
        } else {
          this.objRegistroAP = '';
        }
        habilitarBusqueda = true;
      }
      registro = this.objRegistro.replace(/“/g, '"').replace(/”/g, '"');
      registroAP = this.objRegistroAP.replace(/“/g, '"').replace(/”/g, '"');
    }
    if (habilitarBusqueda) {//cchavezt ATENCION BUGS
      console.log(registroAP);
      if(registroAP.length<=100){
        this.catEmpleadoService.buscarCatalogoFuncionarios(
          this.aduanaSeleccionada,
          registro,
          registroAP
        ).subscribe(response => {
          FuncionesGenerales.getInstance().cerrarModalCargando();
          this.lstCatEmpleado = response as CatEmpleado[];
          this.validarFuncionariosResumen(this.lstCatEmpleado,filtroRegistroUsado);
          if (hayFuncionario) {
            this.habilitarAgregarFuncionarios = true;
            this.mostrarFiltroFuncionarios(this.objCatEmpleado);
          }
        },
        errorResult => {
          this.habilitarSeleccion = false;
          if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
            let responseManager: ResponseManager = new ResponseManager();
            this.responseErrorManager = errorResult as ResponseErrorManager;
            responseManager.cod = errorResult.cod;
            responseManager.errors = [this.responseErrorManager];
            this.responseManager = responseManager;
            this.cargarMensajesCatalogoFuncionarios(this.responseManager);
          } else {
            this.responseManager = errorResult as ResponseManager;
            this.cargarMensajesCatalogoFuncionarios(this.responseManager);
          }
        });
      } else {
        let errorMensaje: string = '';
        let tituloErrores: string = 'Mensaje de Error: ';
        errorMensaje = 'Valor de apellidos y nombres es incorrecto';
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, '');
      }//cchavezt ATENCION BUGS

    }
  }

  mostrarFiltroFuncionarios(objCatEmpleado: CatEmpleado) {
    this.objRegistro = objCatEmpleado.codPers;
    this.objRegistroAP = objCatEmpleado.apPate.trim() + ' ' +
                         objCatEmpleado.apMate.trim() + ' ' +
                         objCatEmpleado.nombres.trim();
  }

  validarFuncionariosResumen(lstCatEmpleado: CatEmpleado[], filtroRegistroUsado: string) {
    let errorMensaje: string = '';
    let tituloErrores: string = 'Mensaje de Error: ';
    let esValido: boolean = false;
    if (lstCatEmpleado.length == 0) {
      if(filtroRegistroUsado===ConstantesCadenas.FILTRO_REGISTRO)
      {
        errorMensaje = 'No se han encontrado resultados coincidentes con el número de registro del Funcionario Aduanero';
      }
      else{
        errorMensaje = 'No se encontraron funcionarios con los datos ingresados';
      }
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, '');
      return false;
    }
    if (lstCatEmpleado.length == 1) {
      this.mostrarFiltroFuncionarios(lstCatEmpleado[0]);
      this.habilitarAgregarFuncionarios = true;
      return false;
    }
    this.child.mostrarSeleccionDeFuncionarios(lstCatEmpleado);
    esValido = true;
    return esValido;
  }

  eventClick(model) {
    let objFechaActual: Date = model.event.start;
    objFechaActual.setDate(objFechaActual.getDate() + 1);
    //console.log(model);
    //console.log(model.el.ownerDocument.lastModified as string);
    this.childTurno.cargarFuncionariosRegistrados(model.event._def.extendedProps as FuncionariosDetalle,
                                                  objFechaActual,
                                                  this.objAduanaSeleccionada.cod_datacat + ' - ' + this.objAduanaSeleccionada.des_corta,
                                                  this.objUnidadDespachoSeleccionado.descripcion,
                                                  this.objGrupoFuncionarioSeleccionado.des_corta);
  }

  cargarListaFuncionariosResumen(funcionariosResumen: FuncionariosResumen[]) {
    this.displayedColumns = ConstantesListas.COLUMNAS_GRID_FUNCIONARIO_RESUMEN;
    this.funcionariosResumenDS = new MatTableDataSource<FuncionariosResumen>(funcionariosResumen);
    this.funcionariosResumenDS.sort = this.sort;
    this.funcionariosResumenDS.paginator = this.paginator;
  }

  cargarCalendario(funcionariosDetalle: FuncionariosDetalle[]) {
    this.funcionariosDetalle = funcionariosDetalle;
    this.ufullcalendar.calendar.removeAllEvents();
    this.ufullcalendar.calendar.addEventSource(this.funcionariosDetalle);
    this.ufullcalendar.calendar.refetchEvents();
  }

  cargarMensajesCatalogoFuncionarios(responseManager: ResponseManager) {
    if (responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO ||
        responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                   'Mensajes de Error: ',
                                                                    '',
                                                                    FuncionesGenerales.getInstance().mostrarTablaDeErrores(this.responseManager.errors));
    }
  }

  validarParametrosDeConsulta() {
    let tituloErrores: string = 'Mensajes de Error: ';
    let esValido: boolean = false;
    let fechaActual: Date = new Date();
    if (this.aduanaSeleccionada == "") {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_DIECISIETE, '');
      return false;
    }
    if (this.fechaVigenteDesde == undefined) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_OCHO, '');
      return false;
    }
    if (!FuncionesGenerales.getInstance().esFechaValida(
         FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteDesde),
                                                        ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO)) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_NUEVE, '');
      return false;
    }
    if (FuncionesGenerales.getInstance().compararFechas(
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(new Date()),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteDesde),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 1)
    {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
        ConstantesExcepciones.DEFAULT_TITTLE_EXCEPTION, ConstantesExcepciones.EXCEPCION_UNO, '');
      return false;
    }
    if (this.fechaVigenteHasta == undefined) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_DIEZ, '');
      return false;
    }
    if (!FuncionesGenerales.getInstance().esFechaValida(
         FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteHasta),
         ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO)) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_ONCE, '');
      return false;
    }
    if (FuncionesGenerales.getInstance().compararFechas(
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteDesde),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteHasta),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 1)
    {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
        ConstantesExcepciones.DEFAULT_TITTLE_EXCEPTION, ConstantesExcepciones.EXCEPCION_DOS, '');
      return false;
    }
    if (this.unidadDespachoSeleccionado == "") {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_DIECINUEVE, '');
      return false;
    }
    if (this.grupoFuncionarioSeleccionado == "") {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_VEINTE, '');
      return false;
    }
    if (this.turnoSeleccionado == "") {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_VEINTIUNO, '');
      return false;
    }
    /*Validacion mayor de 1 año*/
    let diferenciaAnnios: number = FuncionesGenerales.getInstance().diferenciaEntreFechas(
                                                                                  FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteDesde),
                                                                                  FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteHasta),
                                                                                  ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO_MOMENT,
                                                                                  ConstantesCadenas.FORMATO_UNIDAD_TIEMPO_ANNIOS);
    if (diferenciaAnnios >= 1) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_VEINTIDOS, '');
      return false;
    }
    /*Validar si las fechas ingresadas estan dentro del rango del turno*/
    //let fechaInicioVigenciaTurno: Date = FuncionesGenerales.getInstance().convertirFormatoCadenaDiaMesAnnioADate(FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objTurnoSeleccionado.fecInicioVigencia));
    //let fechaFinVigenciaTurno: Date = FuncionesGenerales.getInstance().convertirFormatoCadenaDiaMesAnnioADate(FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objTurnoSeleccionado.fecFinVigencia));
    //let fechaInicioCF: Date = FuncionesGenerales.getInstance().convertirFormatoCadenaDiaMesAnnioADate(FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteDesde));
    //let fechaFinCF: Date = FuncionesGenerales.getInstance().convertirFormatoCadenaDiaMesAnnioADate(FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteHasta));
    let fechaInicioVigenciaTurno: Date = FuncionesGenerales.getInstance().convertirNumeroADate(this.objTurnoSeleccionado.fecInicioVigencia);
    let fechaFinVigenciaTurno: Date = FuncionesGenerales.getInstance().convertirNumeroADate(this.objTurnoSeleccionado.fecFinVigencia);
    let fechaInicioCF: Date = FuncionesGenerales.getInstance().convertirNumeroADate(this.fechaVigenteDesde);
    let fechaFinCF: Date = FuncionesGenerales.getInstance().convertirNumeroADate(this.fechaVigenteHasta);
    let sonFechasIguales: boolean = false;

    fechaInicioVigenciaTurno.setHours(0);
    fechaInicioVigenciaTurno.setMinutes(0);
    fechaInicioVigenciaTurno.setSeconds(0);

    fechaFinVigenciaTurno.setHours(0);
    fechaFinVigenciaTurno.setMinutes(0);
    fechaFinVigenciaTurno.setSeconds(0);

    fechaInicioCF.setHours(0);
    fechaInicioCF.setMinutes(0);
    fechaInicioCF.setSeconds(0);

    fechaFinCF.setHours(0);
    fechaFinCF.setMinutes(0);
    fechaFinCF.setSeconds(0);

    if (!((fechaInicioCF >= fechaInicioVigenciaTurno && fechaInicioCF <= fechaFinVigenciaTurno) &&
        (fechaFinCF >= fechaInicioVigenciaTurno && fechaFinCF <= fechaFinVigenciaTurno))) {

        sonFechasIguales = (FuncionesGenerales.getInstance().momentCompararFechas(
                            fechaInicioCF,
                            fechaInicioVigenciaTurno) &&
                            FuncionesGenerales.getInstance().momentCompararFechas(
                            fechaInicioCF,
                            fechaFinVigenciaTurno)) &&
                            (FuncionesGenerales.getInstance().momentCompararFechas(
                            fechaFinCF,
                            fechaInicioVigenciaTurno) &&
                            FuncionesGenerales.getInstance().momentCompararFechas(
                            fechaFinCF,
                            fechaFinVigenciaTurno));
        if (!sonFechasIguales) {
          sonFechasIguales = false;
          let momentFechaInicioCF = FuncionesGenerales.getInstance().momentFecha(fechaInicioCF);
          let momentFechaFinCF = FuncionesGenerales.getInstance().momentFecha(fechaFinCF);
          let momentFechaInicioVigenciaTurno = FuncionesGenerales.getInstance().momentFecha(fechaInicioVigenciaTurno);
          let momentFechaFinVigenciaTurno = FuncionesGenerales.getInstance().momentFecha(fechaFinVigenciaTurno);
          sonFechasIguales = (momentFechaInicioCF.isSame(momentFechaFinCF) &&
                       momentFechaFinCF.isSame(momentFechaFinVigenciaTurno)) &&
                      (momentFechaInicioVigenciaTurno <= momentFechaFinCF);
            if (!sonFechasIguales) {
              let esMensajeDeErrorSinHorario: Boolean = this.objGrupoFuncionarioSeleccionado.indPermanente && this.objGrupoFuncionarioSeleccionado.indPermanente === '1';
              let mensajeError: string = esMensajeDeErrorSinHorario ? ConstantesExcepciones.EXCEPCION_VEINTICINCO : ConstantesExcepciones.EXCEPCION_VEINTICUATRO;
              FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
              tituloErrores,
              FuncionesGenerales.getInstance().reemplazarParametros(mensajeError,
              FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objTurnoSeleccionado.fecInicioVigencia),
              FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.objTurnoSeleccionado.fecFinVigencia)), '');
              return false;
            }
        }
    }

    esValido = true;
    return esValido;
  }

  seleccionarTurno(objSeleccionado) {
    console.log('seleccionarTurno =>');
    console.log('objSeleccionado => ' + objSeleccionado.target.value);
    this.turnoSeleccionado = objSeleccionado.target.value;
    if (objSeleccionado.target.value != '') {
      this.objTurnoSeleccionado = this.lstTurnos.find(element => element.numTurno == objSeleccionado.target.value);
    }
  }

  validarFuncionarioEnLista(objCatEmpleado: CatEmpleado) {
    let errorMensaje: string = '';
    let tituloErrores: string = 'Mensaje de Error: ';
    let esValido: boolean = false;
    let existeFuncionario: boolean = false;
    let fechaInicioFuncionarioRegistrado: string=''; //cchavezt ATENCION BUGS
    let fechaTerminoFuncionarioRegistrado: string=''; //cchavezt ATENCION BUGS
    if (this.funcionariosResumen == undefined) {
      this.funcionariosResumen = [];
    }
    for (let i = 0; i < this.funcionariosResumen.length; i++) {
      if (this.funcionariosResumen[i].codigo == objCatEmpleado.codPers) {
        fechaInicioFuncionarioRegistrado=FuncionesGenerales.getInstance().formatearFecha(this.funcionariosResumen[i].fecInicio); //cchavezt ATENCION BUGS
        fechaTerminoFuncionarioRegistrado=FuncionesGenerales.getInstance().formatearFecha(this.funcionariosResumen[i].fecFin); //cchavezt ATENCION BUGS
        existeFuncionario = true;
        break;
      }
    }
    if (existeFuncionario) {
      errorMensaje = 'Funcionario Aduanero ya se encuentra registrado con fecha de inicio de vigencia '+fechaInicioFuncionarioRegistrado+' y fecha de término de vigencia '+fechaTerminoFuncionarioRegistrado+'.'; //cchavezt ATENCION BUGS
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, errorMensaje, '');
      return false;
    }
    esValido = true;
    return esValido;
  }

  agregarFuncionario() {
    let funcionario: FuncionariosResumen;
    let objCatEmpleado: CatEmpleado;
    objCatEmpleado = (this.habilitarSeleccion ? this.objCatEmpleado : this.lstCatEmpleado[0]);
    this.objRegistro = '';
    this.objRegistroAP = '';
    if (this.desabilitarCriterioRegistro) {
      this.desabilitarCriterioAP = true;
    } else {
      this.desabilitarCriterioRegistro = true;
    }
    this.habilitarSeleccion = false;
    this.habilitarAgregarFuncionarios = false;
    if (this.validarFuncionarioEnLista(objCatEmpleado)) {
      funcionario = new FuncionariosResumen();
      funcionario.codigo = objCatEmpleado.codPers;
      funcionario.apellidoMaterno = objCatEmpleado.apMate.trim();
      funcionario.apellidoPaterno = objCatEmpleado.apPate.trim();
      funcionario.nombres = objCatEmpleado.nombres.trim();
      funcionario.fecInicio = this.fechaVigenteDesde;
      funcionario.fecFin = this.fechaVigenteHasta;
      funcionario.saved = false;
      if (this.funcionariosResumen == undefined) {
        this.funcionariosResumen = [];
      }
      if (this.funcionariosDetalle == undefined) {
        this.funcionariosDetalle = [];
      }
      this.funcionariosResumen.push(funcionario);
      this.displayedColumns = ConstantesListas.COLUMNAS_GRID_FUNCIONARIO_RESUMEN;
      this.refreshFuncionariosResumen();
      this.cargarListaACalendario(objCatEmpleado);
    }
  }

  cargarListaACalendario(objCatEmpleado: CatEmpleado) {
    this.funcionariosDetalle.map(x => {
      let funcDisponible: FuncionarioDisponible;
      funcDisponible = new FuncionarioDisponible();
      funcDisponible.catEmpleado = new CatEmpleado();
      funcDisponible.catEmpleado = objCatEmpleado;
      funcDisponible.aduana = new Datacatalogo();
      funcDisponible.aduana = this.objAduanaSeleccionada as Datacatalogo;
      funcDisponible.grupoTrabajo = new Datacatalogo();
      funcDisponible.grupoTrabajo = this.objGrupoFuncionarioSeleccionado as Datacatalogo;
      funcDisponible.turno = new Turno();
      funcDisponible.turno = this.objTurnoSeleccionado as Turno;
      funcDisponible.fecAsignacion = FuncionesGenerales.getInstance().convertirFormatoCadenaDiaMesAnnioADateSlash(x.start);
      funcDisponible.fecAsignacion.setHours(parseInt('00'));
      funcDisponible.fecAsignacion.setMinutes(parseInt('00'));
      funcDisponible.fecAsignacion.setSeconds(parseInt('00'));
      funcDisponible.estado = '1'; // ya hice el change
      funcDisponible.esDeBD = false;
      funcDisponible.motivo = '';
      x.funcionarios.push(funcDisponible);
      x.esDeBD = false;
      x.title = x.turno.indPermanente && x.turno.indPermanente === '1' ? x.funcionarios.length.toString() + (x.funcionarios.length == 0 || x.funcionarios.length > 1 ? ' funcionarios' : ' funcionario') :
                'Turno ' + x.turno.nombre + "\n" + x.funcionarios.length.toString() + (x.funcionarios.length == 0 || x.funcionarios.length > 1 ? ' funcionarios' : ' funcionario');
      this.controlCambios=true; //cchavezt
      if (x.funcionariosTotales == null) {
        x.funcionariosTotales = FuncionesGenerales.getInstance().clonarObjeto(x.funcionarios);
      } else {
        x.funcionariosTotales.push(FuncionesGenerales.getInstance().clonarObjeto(funcDisponible));
      }
    });
    this.cargarCalendario(this.funcionariosDetalle);
  }

  actualizarCalendario(funcionarioDetalle: FuncionariosDetalle) {
    this.funcionariosDetalle.map(x => {
      if (x.start == funcionarioDetalle.start) {
        let fdactives: FuncionarioDisponible[];
        fdactives = funcionarioDetalle.funcionarios.filter(
          xy => (xy.estado === '1')
        );
        x.title =  x.turno.indPermanente && x.turno.indPermanente === '1' ?
                   fdactives.length.toString() + (fdactives.length == 0 || fdactives.length > 1 ? ' funcionarios' : ' funcionario') :
                   'Turno ' + x.turno.nombre + "\n" + fdactives.length.toString() + (fdactives.length == 0 || fdactives.length > 1 ? ' funcionarios' : ' funcionario');
        x.funcionarios = funcionarioDetalle.funcionarios;
        x.funcionariosTotales = funcionarioDetalle.funcionariosTotales;
        x.cantidad = fdactives.length;
      }
    });
    this.cargarCalendario(this.funcionariosDetalle);
    this.cargarLista(funcionarioDetalle);
  }

  // Método usado para reenderizar la lista de funcionarios Resumen
  cargarLista(funcionarioDetalle: FuncionariosDetalle) {
    console.log(funcionarioDetalle);
    let nuevosFuncionariosResumenCruce: FuncionariosResumen[];
    nuevosFuncionariosResumenCruce = [];
    let nuevosFuncionariosResumen: FuncionariosResumen[];
    nuevosFuncionariosResumen = [];
    // Recorrer la lista de funcionarios para el día en específico
    // ACTIVOS
    funcionarioDetalle.funcionarios.filter(z => z.estado === '1').map(
      x => {
        let funRes: FuncionariosResumen[];
        funRes = [];
        // (z.fecInicio instanceof Date) ? z.fecInicio : FuncionesGenerales.getInstance().formatearFecha(z.fecInicio.value)
        funRes = this.funcionariosResumen.filter(y => (y.codigo === x.catEmpleado.codPers && FuncionesGenerales.getInstance().enRangoFechas(
                                          (typeof(y.fecInicio) == 'number' ? new Date(y.fecInicio) : y.fecInicio),
                                          (typeof(y.fecFin) == 'number' ? new Date(y.fecFin) : y.fecFin),
                                          FuncionesGenerales.getInstance().convertirFormatoCadenaDiaMesAnnioADateSlash(funcionarioDetalle.start)
                                          //FuncionesGenerales.getInstance().convertirFormatoAnnioMesDiaComoCadena(y.fecInicio),
                                          //FuncionesGenerales.getInstance().convertirFormatoAnnioMesDiaComoCadena(y.fecFin),
                                          //funcionarioDetalle.start
                                          )) );
        if (funRes.length === 0) {
          let fr_newArray: FuncionariosResumen;
          fr_newArray = new FuncionariosResumen();
          fr_newArray.nombres = x.catEmpleado.nombres;
          fr_newArray.apellidoPaterno = x.catEmpleado.apPate;
          fr_newArray.apellidoMaterno = x.catEmpleado.apMate;
          fr_newArray.codigo = x.catEmpleado.codPers;
          fr_newArray.fecInicio = FuncionesGenerales.getInstance().convertirFormatoCadenaDiaMesAnnioADateSlash(funcionarioDetalle.start);
          fr_newArray.fecFin = FuncionesGenerales.getInstance().convertirFormatoCadenaDiaMesAnnioADateSlash(funcionarioDetalle.start);
          fr_newArray.saved = false;
          nuevosFuncionariosResumenCruce.push(fr_newArray);
        }
      }
    );
    // INACTIVOS
    funcionarioDetalle.funcionarios.filter(z => z.estado === '0').map(
      p => {
        this.funcionariosResumen.map(
          element => {
            if (element.codigo === p.catEmpleado.codPers && FuncionesGenerales.getInstance().enRangoFechas(
                  (typeof(element.fecInicio) == 'number' ? new Date(element.fecInicio) : element.fecInicio),
                  (typeof(element.fecFin) == 'number' ? new Date(element.fecFin) : element.fecFin),
                  FuncionesGenerales.getInstance().convertirFormatoCadenaDiaMesAnnioADateSlash(funcionarioDetalle.start)
                  //FuncionesGenerales.getInstance().convertirFormatoAnnioMesDiaComoCadena(element.fecInicio),
                  //FuncionesGenerales.getInstance().convertirFormatoAnnioMesDiaComoCadena(element.fecFin),
                  //funcionarioDetalle.start
                  )) {
                    if ( FuncionesGenerales.getInstance().convertirFormatoAnnioMesDiaComoCadena(element.fecInicio) == funcionarioDetalle.start) {
                      // actualizar el mismo registro, la fecha de inicio
                      let fechaseteo: Date;
                      fechaseteo = FuncionesGenerales.getInstance().clonarObjeto(element.fecInicio);
                      if (typeof(fechaseteo) === 'number') {
                        fechaseteo = new Date(fechaseteo);
                      }
                      FuncionesGenerales.getInstance().sumarDias(fechaseteo, 1);
                      element.fecInicio = fechaseteo;
                    } else if ( FuncionesGenerales.getInstance().convertirFormatoAnnioMesDiaComoCadena(element.fecFin) == funcionarioDetalle.start) {
                      // actualizar el mismo registro, la fecha final
                      let fechaseteo: Date;
                      fechaseteo = FuncionesGenerales.getInstance().clonarObjeto(element.fecFin);
                      if (typeof(fechaseteo) === 'number') {
                        fechaseteo = new Date(fechaseteo);
                      }
                      FuncionesGenerales.getInstance().restarDias(fechaseteo, 1);
                      element.fecFin = fechaseteo;
                    } else {
                      // Partir el resumen
                      let fechaInicioNuevo: Date;
                      fechaInicioNuevo = FuncionesGenerales.getInstance().clonarObjeto(p.fecAsignacion);
                      if (typeof(fechaInicioNuevo) === 'number') {
                        fechaInicioNuevo = new Date(fechaInicioNuevo);
                      }
                      FuncionesGenerales.getInstance().sumarDias(fechaInicioNuevo, 1);
                      let fr_newArray: FuncionariosResumen;
                      fr_newArray = new FuncionariosResumen();
                      fr_newArray.nombres = element.nombres;
                      fr_newArray.apellidoPaterno = element.apellidoPaterno;
                      fr_newArray.apellidoMaterno = element.apellidoMaterno;
                      fr_newArray.codigo = element.codigo;
                      fr_newArray.fecInicio = fechaInicioNuevo;
                      fr_newArray.fecFin = element.fecFin;
                      fr_newArray.saved = false;
                      let fechaseteo: Date;
                      fechaseteo = FuncionesGenerales.getInstance().clonarObjeto(p.fecAsignacion);
                      if (typeof(fechaseteo) === 'number') {
                        fechaseteo = new Date(fechaseteo);
                      }
                      FuncionesGenerales.getInstance().restarDias(fechaseteo, 1);
                      element.fecFin = fechaseteo;
                      nuevosFuncionariosResumen.push(fr_newArray);
                    }
                  }
          });
      }
    );
    //Agregar nuevos sin afectar cruces
    nuevosFuncionariosResumen.map(
      x => {
        this.funcionariosResumen.push(x);
        this.refreshFuncionariosResumen();
      }
    );
    //Agregar nuevos y puede afectar cruces
    nuevosFuncionariosResumenCruce.map(
      x => {
        this.funcionariosResumen.push(x);
        this.refreshFuncionariosResumen();
        this.ordenarListadoFuncionariosResumen(x);
      }
    );
  }

  retirarFuncionario(funcionarioResumen: FuncionariosResumen) {
    console.log('retirarFuncionario => ');
    console.log('funcionarioResumen => ' + funcionarioResumen);
    if (funcionarioResumen.saved) {
       this.deleteMotivo = '';

       this.objFuncionarioSeleccionado = funcionarioResumen;
       this.modRetirarMotivo = ""; //(this.objFuncionarioSeleccionado.motivo == null || this.objFuncionarioSeleccionado.motivo == undefined ? "" : this.objFuncionarioSeleccionado.motivo.trim());
       this.motivoModal.show();
     } else {
       this.funcionariosResumen = this.funcionariosResumen.filter(
           x =>
           !(x.codigo == funcionarioResumen.codigo && x.fecInicio == funcionarioResumen.fecInicio &&
             x.fecFin == funcionarioResumen.fecFin)
           );
       this.refreshFuncionariosResumen();
       let objEmpleado: CatEmpleado = new CatEmpleado();
       objEmpleado.codPers = funcionarioResumen.codigo;
       objEmpleado.nombres = funcionarioResumen.nombres;
       objEmpleado.apPate = funcionarioResumen.apellidoPaterno;
       objEmpleado.apMate = funcionarioResumen.apellidoMaterno;
       this.retirarFuncionarioMapaDesdeFR(objEmpleado, funcionarioResumen.fecInicio, funcionarioResumen.fecFin);
     }
  }

  retirarFuncionarioMapaDesdeFR(objCatEmpleado: CatEmpleado, fechaInicio: Date, fechaFin: Date) {
    console.log('retirarFuncionarioMapaDesdeFR => ');
    console.log('this.funcionariosDetalle =>' + this.funcionariosDetalle);
    this.funcionariosDetalle.map(x => {
      x.funcionarios = x.funcionarios.filter(
        y => !(
          y.catEmpleado.codPers == objCatEmpleado.codPers &&
                                                    FuncionesGenerales.getInstance().enRangoFechas(
                                                      (typeof(fechaInicio) == 'number' ? new Date(fechaInicio) : fechaInicio),
                                                      (typeof(fechaFin) == 'number' ? new Date(fechaFin) : fechaFin),
                                                      FuncionesGenerales.getInstance().convertirFormatoCadenaDiaMesAnnioADateSlash(x.start)
                                                      //FuncionesGenerales.getInstance().convertirFormatoAnnioMesDiaComoCadena(fechaInicio),
                                                      //FuncionesGenerales.getInstance().convertirFormatoAnnioMesDiaComoCadena(fechaFin),
                                                      //x.start
                                                      ))
      );
      x.title = x.turno.indPermanente && x.turno.indPermanente === '1' ?
      x.funcionarios.filter(xy => (xy.estado === '1')).length.toString() +
      (x.funcionarios.filter(xy => (xy.estado === '1')).length == 0 ||
      x.funcionarios.filter(xy => (xy.estado === '1')).length > 1 ? ' funcionarios' : ' funcionario') :
      'Turno ' + x.turno.nombre + "\n" + x.funcionarios.filter(xy => (xy.estado === '1')).length.toString() +
      (x.funcionarios.filter(xy => (xy.estado === '1')).length == 0 ||
      x.funcionarios.filter(xy => (xy.estado === '1')).length > 1 ? ' funcionarios' : ' funcionario');
      x.cantidad = x.funcionarios.filter(xy => (xy.estado === '1')).length;
    });
    this.cargarCalendario(this.funcionariosDetalle);
  }

  cerrarModalMotivo() {
    this.motivoModal.hide();
  }

  modificarVigenciaFuncionario(funcionarioResumen: FuncionariosResumen) {
    this.tituloModal = 'MODIFICAR VIGENCIA';
    this.aduanaVigencia = this.objAduanaSeleccionada.cod_datacat + ' - ' + this.objAduanaSeleccionada.des_corta;
    this.unidadDespachoVigencia = this.objUnidadDespachoSeleccionado.descripcion;
    this.grupoFuncionariosVigencia = this.objGrupoFuncionarioSeleccionado.des_corta;
    this.turnoVigencia = this.objTurnoSeleccionado.nombre
                          + ' - ' + this.objTurnoSeleccionado.hraInicio
                          + ' ' + this.objTurnoSeleccionado.hraFin;
    this.fechaMVigenteDesde = funcionarioResumen.fecInicio;
    this.fechaMVigenteHasta = funcionarioResumen.fecFin;
    this.objFuncionarioSeleccionado = funcionarioResumen;
    this.minDateM = this.fechaVigenteDesde;
    this.maxDateM = this.fechaVigenteHasta;
    this.modVigMotivo = ""; // (funcionarioResumen.motivo == null || funcionarioResumen.motivo == undefined ? "" : funcionarioResumen.motivo.trim());
    this.modificarVigenciaModal.show();
  }

  cerrarModalModificarVigencia() {
    this.modificarVigenciaModal.hide();
  }

  aceptarModalModificarVigencia() {
    console.log('aceptarModalModificarVigencia =>');
    console.log('this.funcionariosDetalle =>' + this.funcionariosDetalle);
    console.log('this.funcionariosResumen =>' + this.funcionariosResumen);
    if (this.validarFechasModalModificarVigencia()) {

      let funcionariosSinObjectCurrent: FuncionariosResumen[];
      funcionariosSinObjectCurrent = this.funcionariosResumen.filter(
        x => !(
          x.codigo === this.objFuncionarioSeleccionado.codigo &&
          x.fecInicio == this.objFuncionarioSeleccionado.fecInicio &&
          x.fecFin == this.objFuncionarioSeleccionado.fecFin
        )
      );
      if (this.validarCruceFechasEnResumen(this.fechaMVigenteDesde, this.fechaMVigenteHasta, funcionariosSinObjectCurrent)) {
        let tituloErrores: string;
        tituloErrores = 'Mensaje de Error: ';
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
          tituloErrores, 'Las fechas de inicio y término de vigencia ingresados se traslapa con otro registro para el mismo funcionario.', '');
      } else {
        this.funcionariosResumen.map(
          x => {
            if ( x.codigo == this.objFuncionarioSeleccionado.codigo &&
                x.fecInicio == this.objFuncionarioSeleccionado.fecInicio &&
                x.fecFin == this.objFuncionarioSeleccionado.fecFin) {
                x.fecInicio = this.fechaMVigenteDesde;
                x.fecFin = this.fechaMVigenteHasta;
                x.motivo = this.modVigMotivo.trim();
            }
          });
        this.refreshFuncionariosResumen();
        let funcionariosResumenEditado: FuncionariosResumen[];
        funcionariosResumenEditado = this.funcionariosResumen.filter(
          x => x.codigo === this.objFuncionarioSeleccionado.codigo
        );
        // Actualización en el calendario
        let existeFuncionario = false;
        let fechaEstaEnRango: boolean;
        this.funcionariosDetalle.map(
          z => {
            existeFuncionario = false;
            fechaEstaEnRango = this.existeEnRango(FuncionesGenerales.getInstance().convertirFormatoCadenaDiaMesAnnioADateSlash(z.start), funcionariosResumenEditado);
            z.funcionarios.map(
              y => {
                if(y.catEmpleado.codPers == this.objFuncionarioSeleccionado.codigo){
                  existeFuncionario = true;
                  y.estado = fechaEstaEnRango ? '1' : '0';
                  y.motivo = this.obtenerMotivo(FuncionesGenerales.getInstance().convertirFormatoCadenaDiaMesAnnioADateSlash(z.start), funcionariosResumenEditado);
                }
              }
            );
            if(!existeFuncionario && fechaEstaEnRango){
              let funcDisponibled: FuncionarioDisponible;
              funcDisponibled = new FuncionarioDisponible();
              let obEmpleado: CatEmpleado;
              obEmpleado = new CatEmpleado();
              obEmpleado.codPers = this.objFuncionarioSeleccionado.codigo;
              obEmpleado.apPate = this.objFuncionarioSeleccionado.apellidoPaterno;
              obEmpleado.apMate = this.objFuncionarioSeleccionado.apellidoMaterno;
              obEmpleado.nombres = this.objFuncionarioSeleccionado.nombres;
              funcDisponibled.catEmpleado = obEmpleado;
              funcDisponibled.aduana = this.objAduanaSeleccionada;
              funcDisponibled.grupoTrabajo = this.objGrupoFuncionarioSeleccionado;
              funcDisponibled.turno = this.objTurnoSeleccionado;
              funcDisponibled.fecAsignacion = FuncionesGenerales.getInstance().convertirFormatoCadenaDiaMesAnnioADateSlash(z.start);
              funcDisponibled.fecAsignacion.setHours(parseInt('00'));
              funcDisponibled.fecAsignacion.setMinutes(parseInt('00'));
              funcDisponibled.fecAsignacion.setSeconds(parseInt('00'));
              funcDisponibled.estado = '1';
              funcDisponibled.esDeBD = false;
              funcDisponibled.motivo = this.modVigMotivo == undefined || this.modVigMotivo == null ? "" : this.modVigMotivo.trim();
              z.funcionarios.push(funcDisponibled);
            }
            let funcDisponiblesActivos: FuncionarioDisponible[];
            funcDisponiblesActivos = z.funcionarios.filter(
              g => (g.estado == '1'));
            z.cantidad = funcDisponiblesActivos.length;
            z.title = z.turno.indPermanente && z.turno.indPermanente === '1' ? z.cantidad.toString() + (z.cantidad == 0 || z.cantidad > 1 ? ' funcionarios' : ' funcionario') :
                      'Turno ' + z.turno.nombre + "\n" + z.cantidad.toString() + (z.cantidad == 0 || z.cantidad > 1 ? ' funcionarios' : ' funcionario');
          }
        );
        this.cargarCalendario(this.funcionariosDetalle);
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_EXITOSO,
          'Mensaje', 'Datos modificados correctamente. Los datos se grabaran cuando presione el botón "Grabar".', '');
        this.ordenarListadoFuncionariosResumen(this.objFuncionarioSeleccionado);
        this.controlCambios=true; //cchavezt ATENCION BUGS
        this.modificarVigenciaModal.hide();
      }
    }
  }

  existeEnRango(fechaEvaluar: Date, listaResumen: FuncionariosResumen[]){
    let funcResumen: FuncionariosResumen;
    let existe = false;
    for(let i=0; i<listaResumen.length; i++){
      funcResumen = listaResumen[i];
      if(FuncionesGenerales.getInstance().enRangoFechas(
        (typeof(funcResumen.fecInicio) == 'number' ? new Date(funcResumen.fecInicio) : funcResumen.fecInicio),
        (typeof(funcResumen.fecFin) == 'number' ? new Date(funcResumen.fecFin) : funcResumen.fecFin),
        fechaEvaluar)
      )
        existe = true;
    }
    return existe;
  }

  obtenerMotivo(fechaEvaluar: Date, listaResumen: FuncionariosResumen[]){
    let funcResumen: FuncionariosResumen;
    let motivo = '';
    for(let i=0; i<listaResumen.length; i++){
      funcResumen = listaResumen[i];
      if(FuncionesGenerales.getInstance().enRangoFechas(
        (typeof(funcResumen.fecInicio) == 'number' ? new Date(funcResumen.fecInicio) : funcResumen.fecInicio),
        (typeof(funcResumen.fecFin) == 'number' ? new Date(funcResumen.fecFin) : funcResumen.fecFin),
        fechaEvaluar)
      )
        motivo = funcResumen.motivo == null || funcResumen.motivo == undefined ? "" : funcResumen.motivo.trim();
    }
    return motivo;
  }

  validarFechasModalModificarVigencia() {
    let tituloErrores: string = 'Mensajes de Error: ';
    let esValido: boolean = true;
    if (this.fechaMVigenteDesde == undefined || this.fechaMVigenteDesde.toDateString == undefined) { //cchavezt ATENCION BUGS
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_OCHO, '');
      return false;
    }
    if (!FuncionesGenerales.getInstance().esFechaValida(
         FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaMVigenteDesde),
                                                        ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO)) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_NUEVE, '');
      return false;
    }
    if (FuncionesGenerales.getInstance().compararFechas(
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(new Date()),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaMVigenteDesde),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 1) {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
        ConstantesExcepciones.DEFAULT_TITTLE_EXCEPTION, ConstantesExcepciones.EXCEPCION_UNO, '');
      return false;
    }
    if (this.fechaMVigenteHasta == undefined || this.fechaMVigenteHasta.toDateString == undefined) { //cchavezt ATENCION BUGS
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_DIEZ, '');
      return false;
    }
    if (!FuncionesGenerales.getInstance().esFechaValida(
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaMVigenteHasta),
                                                          ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO)) {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    tituloErrores, ConstantesExcepciones.EXCEPCION_ONCE, '');
        return false;
    }
    if (FuncionesGenerales.getInstance().compararFechas(
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaMVigenteDesde),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaMVigenteHasta),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 1) {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
        ConstantesExcepciones.DEFAULT_TITTLE_EXCEPTION, ConstantesExcepciones.EXCEPCION_DOS, '');
      return false;
    }
    if (FuncionesGenerales.getInstance().compararFechas(
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteDesde),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaMVigenteDesde),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 1) {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
        ConstantesExcepciones.DEFAULT_TITTLE_EXCEPTION, ConstantesExcepciones.EXCEPCION_VEINTITRES, '');
      return false;
    }
    if (FuncionesGenerales.getInstance().compararFechas(
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaMVigenteHasta),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteHasta),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 1) {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
        ConstantesExcepciones.DEFAULT_TITTLE_EXCEPTION, ConstantesExcepciones.EXCEPCION_VEINTITRES, '');
      return false;
    }
    if(this.modVigMotivo == undefined || this.modVigMotivo == '' || this.modVigMotivo.length < 20) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
        ConstantesExcepciones.DEFAULT_TITTLE_EXCEPTION, 'La cantidad de caracteres del motivo no debe ser menor a 20.', '');
        return false;
    }
    return esValido;
  }

  nuevaVigenciaFuncionario(funcionarioResumen: FuncionariosResumen) {
    this.tituloModal = 'NUEVA VIGENCIA';
    this.aduanaVigencia = this.objAduanaSeleccionada.cod_datacat + ' - ' + this.objAduanaSeleccionada.des_corta;
    this.unidadDespachoVigencia = this.objUnidadDespachoSeleccionado.descripcion;
    this.grupoFuncionariosVigencia = this.objGrupoFuncionarioSeleccionado.des_corta;
    this.turnoVigencia = this.objTurnoSeleccionado.nombre
                          + ' - ' + this.objTurnoSeleccionado.hraInicio
                          + ' ' + this.objTurnoSeleccionado.hraFin;
    this.fechaNVigenteDesde = funcionarioResumen.fecInicio;
    this.fechaNVigenteHasta = funcionarioResumen.fecFin;
    this.objFuncionarioSeleccionado = funcionarioResumen;
    this.minDateM = this.fechaVigenteDesde;
    this.maxDateM = this.fechaVigenteHasta;
    this.nuevaVigenciaModal.show();
  }

  aceptarModalNuevaVigencia() {
    if (this.validarFechasModalNuevaVigencia()) {
      if (this.validarCruceFechasEnResumen(this.fechaNVigenteDesde, this.fechaNVigenteHasta, this.funcionariosResumen)) {
        let tituloErrores: string;
        tituloErrores = 'Mensajes de Error: ';
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
          tituloErrores, 'Quiere ingresar una vigencia con fechas cruzadas (modificar texto)', '');
      } else {
        // add en Funcionares Detalle
        let funcionarioNuevo: FuncionariosResumen;
        funcionarioNuevo = new FuncionariosResumen();
        funcionarioNuevo.codigo = this.objFuncionarioSeleccionado.codigo;
        funcionarioNuevo.apellidoMaterno = this.objFuncionarioSeleccionado.apellidoMaterno;
        funcionarioNuevo.apellidoPaterno = this.objFuncionarioSeleccionado.apellidoPaterno;
        funcionarioNuevo.nombres = this.objFuncionarioSeleccionado.nombres;
        funcionarioNuevo.fecInicio = FuncionesGenerales.getInstance().convertirNumeroADate(this.fechaNVigenteDesde);
        funcionarioNuevo.fecFin = FuncionesGenerales.getInstance().convertirNumeroADate(this.fechaNVigenteHasta);
        funcionarioNuevo.saved = false;
        this.funcionariosResumen.push(funcionarioNuevo);
        this.refreshFuncionariosResumen();
        // Actualización en el calendario
        this.funcionariosDetalle.map(
          z => {
            z.funcionarios.map(
              y => {
                if (y.catEmpleado.codPers == this.objFuncionarioSeleccionado.codigo && FuncionesGenerales.getInstance().enRangoFechas(
                  (typeof(this.fechaNVigenteDesde) == 'number' ? new Date(this.fechaNVigenteDesde) : this.fechaNVigenteDesde),
                  (typeof(this.fechaNVigenteHasta) == 'number' ? new Date(this.fechaNVigenteHasta) : this.fechaNVigenteHasta),
                  FuncionesGenerales.getInstance().convertirFormatoCadenaDiaMesAnnioADateSlash(z.start)
                  //FuncionesGenerales.getInstance().convertirFormatoAnnioMesDiaComoCadena(this.fechaNVigenteDesde),
                  //FuncionesGenerales.getInstance().convertirFormatoAnnioMesDiaComoCadena(this.fechaNVigenteHasta),
                  //z.start
                  )) {
                    console.log('ENTRA POR AQUÍ');
                    y.estado = '1';
                  }
              }
            );

            let foundFDN: FuncionarioDisponible[];
            foundFDN = z.funcionarios.filter(f => f.catEmpleado.codPers === this.objFuncionarioSeleccionado.codigo && FuncionesGenerales.getInstance().convertirFormatoAnnioMesDiaComoCadena(f.fecAsignacion) === z.start);
            if (foundFDN.length === 0) { // No se encuentra el Funcionario en la fecha
              if (FuncionesGenerales.getInstance().enRangoFechas(
                (typeof(this.fechaNVigenteDesde) == 'number' ? new Date(this.fechaNVigenteDesde) : this.fechaNVigenteDesde),
                (typeof(this.fechaNVigenteHasta) == 'number' ? new Date(this.fechaNVigenteHasta) : this.fechaNVigenteHasta),
                FuncionesGenerales.getInstance().convertirFormatoCadenaDiaMesAnnioADateSlash(z.start)
                //FuncionesGenerales.getInstance().convertirFormatoAnnioMesDiaComoCadena(this.fechaNVigenteDesde),
                //FuncionesGenerales.getInstance().convertirFormatoAnnioMesDiaComoCadena(this.fechaNVigenteHasta),
                //z.start
                )) {
                  let funcDisponibled: FuncionarioDisponible;
                  funcDisponibled = new FuncionarioDisponible();
                  let obEmpleado: CatEmpleado;
                  obEmpleado = new CatEmpleado();
                  obEmpleado.codPers = this.objFuncionarioSeleccionado.codigo;
                  obEmpleado.apPate = this.objFuncionarioSeleccionado.apellidoPaterno;
                  obEmpleado.apMate = this.objFuncionarioSeleccionado.apellidoMaterno;
                  obEmpleado.nombres = this.objFuncionarioSeleccionado.nombres;
                  funcDisponibled.catEmpleado = obEmpleado;
                  funcDisponibled.aduana = this.objAduanaSeleccionada;
                  funcDisponibled.grupoTrabajo = this.objGrupoFuncionarioSeleccionado;
                  funcDisponibled.turno = this.objTurnoSeleccionado;
                  funcDisponibled.fecAsignacion = FuncionesGenerales.getInstance().convertirFormatoCadenaDiaMesAnnioADateSlash(z.start);
                  funcDisponibled.fecAsignacion.setHours(parseInt('00'));
                  funcDisponibled.fecAsignacion.setMinutes(parseInt('00'));
                  funcDisponibled.fecAsignacion.setSeconds(parseInt('00'));
                  funcDisponibled.estado = '1';
                  funcDisponibled.esDeBD = false;
                  funcDisponibled.motivo = this.modVigMotivo == undefined || this.modVigMotivo == null ? "" : this.modVigMotivo.trim();
                  z.funcionarios.push(funcDisponibled);
                }
            }

            let funcDisponiblesActivos: FuncionarioDisponible[];
            funcDisponiblesActivos = z.funcionarios.filter(
              g => (g.estado == '1'));
            z.cantidad = funcDisponiblesActivos.length;
            z.title = z.turno.indPermanente && z.turno.indPermanente === '1' ? z.cantidad.toString() + (z.cantidad == 0 || z.cantidad > 1 ? ' funcionarios' : ' funcionario') :
                      'Turno ' + z.turno.nombre + "\n" + z.cantidad.toString() + (z.cantidad == 0 || z.cantidad > 1 ? ' funcionarios' : ' funcionario');
          }
        );
        this.cargarCalendario(this.funcionariosDetalle);
        this.ordenarListadoFuncionariosResumen(funcionarioNuevo);
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_EXITOSO,
          'Mensaje', 'Datos modificados correctamente. Los datos se grabaran cuando presione el botón "Grabar".', '');
        this.controlCambios=true; //cchavezt ATENCION BUGS
        this.nuevaVigenciaModal.hide();
      }
    }
  }

  refreshFuncionariosResumen() {
    this.funcionariosResumenDS = new MatTableDataSource<FuncionariosResumen>(this.funcionariosResumen);
    this.funcionariosResumenDS.sort = this.sort;
    this.funcionariosResumenDS.paginator = this.paginator;
  }

  validarFechasModalNuevaVigencia() {
    let tituloErrores: string = 'Mensajes de Error: ';
    let esValido: boolean = true;
    if (this.fechaNVigenteDesde == undefined || this.fechaNVigenteDesde.toDateString() == undefined) { //cchavezt ATENCION BUGS
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_OCHO, '');
      return false;
    }
    if (!FuncionesGenerales.getInstance().esFechaValida(
         FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaNVigenteDesde),
                                                        ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO)) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_NUEVE, '');
      return false;
    }
    if (FuncionesGenerales.getInstance().compararFechas(
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(new Date()),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaNVigenteDesde),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 1) {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
        ConstantesExcepciones.DEFAULT_TITTLE_EXCEPTION, ConstantesExcepciones.EXCEPCION_UNO, '');
      return false;
    }
    if (this.fechaNVigenteHasta == undefined  || this.fechaNVigenteHasta.toDateString() == undefined) { //cchavezt ATENCION BUGS
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                  tituloErrores, ConstantesExcepciones.EXCEPCION_DIEZ, '');
      return false;
    }
    if (!FuncionesGenerales.getInstance().esFechaValida(
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaNVigenteHasta),
                                                          ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO)) {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    tituloErrores, ConstantesExcepciones.EXCEPCION_ONCE, '');
        return false;
    }
    if (FuncionesGenerales.getInstance().compararFechas(
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaNVigenteDesde),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaNVigenteHasta),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 1) {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
        ConstantesExcepciones.DEFAULT_TITTLE_EXCEPTION, ConstantesExcepciones.EXCEPCION_DOS, '');
      return false;
    }
    if (FuncionesGenerales.getInstance().compararFechas(
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteDesde),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaNVigenteDesde),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 1) {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
        ConstantesExcepciones.DEFAULT_TITTLE_EXCEPTION, ConstantesExcepciones.EXCEPCION_VEINTITRES, '');
      return false;
    }
    if (FuncionesGenerales.getInstance().compararFechas(
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaNVigenteHasta),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
      FuncionesGenerales.getInstance().convertirFormatoDiaMesAnnioComoCadena(this.fechaVigenteHasta),
      ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO) == 1) {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
        ConstantesExcepciones.DEFAULT_TITTLE_EXCEPTION, ConstantesExcepciones.EXCEPCION_VEINTITRES, '');
      return false;
    }
    return esValido;
  }

  cerrarModalNuevaVigencia() {
    this.nuevaVigenciaModal.hide();
  }

  validarFuncionario() {
    Swal.fire({
      title: "Mensajes de Advertencia: ",
      text: "¿Desea grabar los cambios?",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      confirmButtonText: "SI",
      cancelButtonColor: '#d33',
      cancelButtonText: "NO"
    }).then((result) => {
      if (result.value) {
        this.grabarFuncionario();
      }
    });
  }

  grabarFuncionario() {
    console.log('grabarFuncionario =>');
    console.log('this.funcionariosResumen =>' + this.funcionariosResumen);
    console.log('this.funcionariosDetalle =>' + this.funcionariosDetalle);
    console.log('this.objTurnoSeleccionado =>' + this.objTurnoSeleccionado.numTurno);
    if (this.funcionariosResumen.length > 0) {
      let funcionarioDisponiblePreSave: FuncionarioDisponible[];
      funcionarioDisponiblePreSave = [];
      this.funcionariosDetalle.map(
        x => {
          x.funcionarios.map(
            y => {funcionarioDisponiblePreSave.push(y);}
          );
        }
      );
      if (funcionarioDisponiblePreSave.length > 0) {
        this.catalogofuncionarioService.registrarCatalogoFuncionario(
          funcionarioDisponiblePreSave,
          this.objTurnoSeleccionado.numTurno,
          this.objGrupoFuncionarioSeleccionado.cod_datacat,
          this.fechaVigenteDesde,
          this.fechaVigenteHasta
        ).subscribe(
          response => {
            FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_EXITOSO,
            'Mensaje', 'Grupo de Funcionarios grabado correctamente ', '', this.callback);
            this.controlCambios=false; //cchavezt ATENCION BUGS
            this.deshabilitarParametrosBuqueda = false;
            this.hayFuncionarios = false;
            this.hayParametrosDeBusqueda = true;
            this.funcionariosDetalle = [];
            this.funcionariosResumen = [];
            this.ufullcalendar.calendar.removeAllEvents();
          },
          errorResult => {
            if (errorResult.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
              let responseManager: ResponseManager = new ResponseManager();
              this.responseErrorManager = errorResult as ResponseErrorManager;
              responseManager.cod = errorResult.cod;
              responseManager.errors = [this.responseErrorManager];
              this.responseManager = responseManager;
              this.cargarMensajesServicioCatalogoFuncionario(this.responseManager);
            } else {
              this.responseManager = errorResult as ResponseManager;
              this.cargarMensajesServicioCatalogoFuncionario(this.responseManager);
            }
          }
        );
      } else {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
          ConstantesExcepciones.DEFAULT_TITTLE_EXCEPTION, ConstantesExcepciones.EXCEPCION_CUATRO, '');
      }
    } else {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
        ConstantesExcepciones.DEFAULT_TITTLE_EXCEPTION, ConstantesExcepciones.EXCEPCION_CUATRO, '');
    }
  }

  callback = () : void => {
    this.ngOnInit();
  };

  validarCruceFechasEnResumen(fechaDesde: Date, fechaHasta: Date, funcionariosResumenParam: FuncionariosResumen[]) {
    let funcResumenFiltro: FuncionariosResumen[];
    fechaDesde = FuncionesGenerales.getInstance().convertirNumeroADate(fechaDesde);
    fechaHasta = FuncionesGenerales.getInstance().convertirNumeroADate(fechaHasta);
    funcResumenFiltro = [];
    funcResumenFiltro = funcionariosResumenParam.filter(
      x => (
        (
          x.codigo === this.objFuncionarioSeleccionado.codigo &&
          FuncionesGenerales.getInstance().enRangoFechas(FuncionesGenerales.getInstance().convertirNumeroADate(x.fecInicio),
                                                         FuncionesGenerales.getInstance().convertirNumeroADate(x.fecFin),
                                                         fechaDesde)) ||
        (
          x.codigo === this.objFuncionarioSeleccionado.codigo &&
          FuncionesGenerales.getInstance().enRangoFechas(FuncionesGenerales.getInstance().convertirNumeroADate(x.fecInicio),
                                                         FuncionesGenerales.getInstance().convertirNumeroADate(x.fecFin),
                                                         fechaHasta)) ||
        (
          x.codigo === this.objFuncionarioSeleccionado.codigo &&
          FuncionesGenerales.getInstance().compararFechas(
            FuncionesGenerales.getInstance().convertirNumeroADate(x.fecInicio),
            ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
            FuncionesGenerales.getInstance().convertirNumeroADate(this.fechaNVigenteDesde),
            ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
          ) === 1 &&
          x.codigo === this.objFuncionarioSeleccionado.codigo &&
          FuncionesGenerales.getInstance().compararFechas(
            FuncionesGenerales.getInstance().convertirNumeroADate(this.fechaNVigenteHasta),
            ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
            FuncionesGenerales.getInstance().convertirNumeroADate(x.fecFin),
            ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO,
          ) === 1)
      )
    );
    return funcResumenFiltro.length > 0;
  }

  ordenarListadoFuncionariosResumen(funcionarioResumen: FuncionariosResumen) {
    let funcionarioRepetido: FuncionariosResumen[]; // Funcionarios que coinciden CODIGO
    let funcionarioAfectado: FuncionariosResumen[]; // Funcionarios que coinciden en relacion con fechas
    let funcionarioIntacto: FuncionariosResumen[];  // Funcionarios que no coinciden
    let funcionarioLimpio: FuncionariosResumen[];  // Funcionarios limpios de repetidos
    funcionarioAfectado = [];
    funcionarioIntacto = [];
    funcionarioLimpio = [];
    funcionarioRepetido = this.funcionariosResumen.filter( x => (x.codigo === funcionarioResumen.codigo)).
                sort(FuncionesGenerales.getInstance().ordenarPor('fecInicio', false));
    let funcionarioRepetidoCant: number;
    funcionarioRepetidoCant = funcionarioRepetido.length;
    if (funcionarioRepetidoCant > 1) {
      // Quitar las filas afectadas
      funcionarioLimpio = this.funcionariosResumen.filter(xy => !(funcionarioRepetido.find(yz => (yz.codigo === xy.codigo))));
      // buscar reordenamiento
      // ordenar la lista
      this.funcionariosResumen.sort(FuncionesGenerales.getInstance().ordenarPor('fecInicio', false));
      // Buscar coincidencia
      funcionarioRepetido.map(
        z => {
          // Fecha de tipo number (?) ===>
          if (typeof(z.fecFin) === 'number') {
            z.fecFin = new Date(z.fecFin);
          }
          if (typeof(z.fecInicio) === 'number') {
            z.fecInicio = new Date(z.fecInicio);
          }
          // <=======Fin fecha tipo number
          if (
              (funcionarioResumen.fecInicio.getDate() === z.fecFin.getDate() + 1) ||
              (funcionarioResumen.fecFin.getDate() === z.fecInicio.getDate() - 1)
            ) {
              funcionarioAfectado.push(z);
          } else {
            if ( !(funcionarioResumen.codigo === z.codigo
                  && funcionarioResumen.fecInicio === z.fecInicio
                  && funcionarioResumen.fecFin === z.fecFin)
                ) {
                  funcionarioIntacto.push(z);
                }
          }
        }
      );
      // Unir las filas
      if (funcionarioAfectado.length > 0) {
        funcionarioAfectado.push(funcionarioResumen);
        funcionarioAfectado.sort(FuncionesGenerales.getInstance().ordenarPor('fecInicio', false));
        let fechaMinima: Date;
        let fechaMaxima: Date;
        fechaMinima = funcionarioAfectado.reduce((a, b) => a.fecInicio < b.fecInicio ? a : b).fecInicio;
        fechaMaxima = funcionarioAfectado.reduce((c, d) => c.fecFin > d.fecFin ? c : d ).fecFin;
        let newFuncionarioResumen: FuncionariosResumen;
        newFuncionarioResumen = new FuncionariosResumen();
        newFuncionarioResumen.apellidoMaterno = funcionarioResumen.apellidoMaterno;
        newFuncionarioResumen.apellidoPaterno = funcionarioResumen.apellidoPaterno;
        newFuncionarioResumen.nombres = funcionarioResumen.nombres;
        newFuncionarioResumen.codigo = funcionarioResumen.codigo;
        newFuncionarioResumen.fecFin = fechaMaxima;
        newFuncionarioResumen.fecInicio = fechaMinima;
        // Agregar
        funcionarioLimpio.push(newFuncionarioResumen);
      } else {
        funcionarioLimpio.push(funcionarioResumen);
      }
      // Agregar nuevas Filas
      funcionarioIntacto.map(
        fi => {
          funcionarioLimpio.push(fi);
        }
      );
      // Setear nuevo listado
      this.funcionariosResumen = funcionarioLimpio;
      this.refreshFuncionariosResumen();
    }
  }

  cargarMensajesServicioCatalogoFuncionario(responseManager: ResponseManager) {
    if (responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO ||
        responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                   "Mensajes de Error: ",
                                                                    "",
                                                                    FuncionesGenerales.getInstance().mostrarTablaDeErrores(this.responseManager.errors));
    }
  }

  retirarFuncionarioEnDb() {
      console.log('retirarFuncionarioEnDb => ');
      console.log('turnoSeleccionado: ' + this.turnoSeleccionado);
      console.log('objTurnoSeleccionado: ' + this.objTurnoSeleccionado.numTurno);
      console.log(this.modRetirarMotivo.length);
      console.log('Se inicia la lista resumen:');
      console.log(this.funcionariosResumen);
      console.log('Se inicia la lista detalle:');
      console.log(this.funcionariosDetalle);
      if(!(this.modRetirarMotivo.length<20)){
      this.funcionariosResumen = this.funcionariosResumen.filter(
        x =>
        !(x.codigo == this.objFuncionarioSeleccionado.codigo && x.fecInicio == this.objFuncionarioSeleccionado.fecInicio &&
          x.fecFin == this.objFuncionarioSeleccionado.fecFin)
        );

      // Actualización en el calendario
      this.funcionariosDetalle.map(
        z => {
          console.log('recorre funcionario Detalle');
          z.funcionarios.map(
            y => {
                console.log('recorre funcionarios');
                if (y.catEmpleado.codPers == this.objFuncionarioSeleccionado.codigo && FuncionesGenerales.getInstance().enRangoFechas(
                  (typeof(this.objFuncionarioSeleccionado.fecInicio) == 'number' ? new Date(this.objFuncionarioSeleccionado.fecInicio) : this.objFuncionarioSeleccionado.fecInicio),
                (typeof(this.objFuncionarioSeleccionado.fecFin) == 'number' ? new Date(this.objFuncionarioSeleccionado.fecFin) : this.objFuncionarioSeleccionado.fecFin),
                FuncionesGenerales.getInstance().convertirFormatoCadenaDiaMesAnnioADateSlash(z.start)
                //FuncionesGenerales.getInstance().convertirFormatoAnnioMesDiaComoCadena(this.objFuncionarioSeleccionado.fecInicio),
                //FuncionesGenerales.getInstance().convertirFormatoAnnioMesDiaComoCadena(this.objFuncionarioSeleccionado.fecFin),
                //z.start
                )) {
                  console.log('actualiza el estado y motivo:')
                  y.estado = '0';
                  y.motivo = this.deleteMotivo;
                }

                z.title = z.turno.indPermanente && z.turno.indPermanente === '1' ?
                          z.funcionarios.filter(xy => (xy.estado === '1')).length.toString() +
                          (z.funcionarios.filter(xy => (xy.estado === '1')).length == 0 || z.funcionarios.filter(xy => (xy.estado === '1')).length > 1 ? ' funcionarios' : ' funcionario') :
                          'Turno ' + z.turno.nombre + "\n" + z.funcionarios.filter(xy => (xy.estado === '1')).length.toString() +
                          (z.funcionarios.filter(xy => (xy.estado === '1')).length == 0 || z.funcionarios.filter(xy => (xy.estado === '1')).length > 1 ? ' funcionarios' : ' funcionario');
                z.cantidad = z.funcionarios.filter(xy => (xy.estado === '1')).length;

            }
          );
        }
      );
      console.log('Se actualiza la lista resumen:');
      console.log(this.funcionariosResumen);
      this.refreshFuncionariosResumen();
      this.cargarCalendario(this.funcionariosDetalle);
      console.log('Se actualiza la lista detalle:');
      console.log(this.funcionariosDetalle);
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_EXITOSO,
        'Mensaje', 'Datos modificados correctamente. Los datos se grabaran cuando presione el botón "Grabar".', '');
      this.controlCambios=true; //cchavezt ATENCION BUGS
      this.motivoModal.hide();
    }
    else
    {
            let errorMensaje: string = "Registre el motivo del retiro del funcionario aduanero";
            let tituloErrores: string = "Mensaje de Error: ";
            FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                        tituloErrores, errorMensaje, "");
    }
  }
}
