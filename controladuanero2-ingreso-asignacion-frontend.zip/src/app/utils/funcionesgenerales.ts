import { ConstantesListas } from 'src/app/utils/constanteslistas';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { ResponseErrorManager } from 'src/app/models/responseerrormanager';
import Swal from 'sweetalert2';
import * as moment from 'moment';

export class FuncionesGenerales {

  protected static funcionesGenerales : FuncionesGenerales;

  static getInstance() : FuncionesGenerales {
    if (!this.funcionesGenerales) {
      this.funcionesGenerales = new FuncionesGenerales();
    }
    return this.funcionesGenerales;
  }

  reemplazarParametros(cadena: string, ...parametros: any[]){
    for(var _i = 0; _i < parametros.length; _i++)
      cadena = cadena.replace("{" + _i + "}", parametros[_i]);
    return cadena;
  }

  ordenarPor (key, reverse) {
    // Move smaller items towards the front
    // or back of the array depending on if
    // we want to sort the array in reverse
    // order or not.
    var moveSmaller = reverse ? 1 : -1;

    // Move larger items towards the front
    // or back of the array depending on if
    // we want to sort the array in reverse
    // order or not.
    var moveLarger = reverse ? -1 : 1;

    /**
     * @param  {*} a
     * @param  {*} b
     * @return {Number}
     */
    return function(a, b) {
      if (a[key] < b[key]) {
        return moveSmaller;
      }
      if (a[key] > b[key]) {
        return moveLarger;
      }
      return 0;
    };
  }

  formatearFecha(objFechaEntero) {
    let dateFormat: Date = new Date(objFechaEntero);
    return ("00" + dateFormat.getDate()).slice(-2) + "/" + ("00" +
    (dateFormat.getMonth() + 1)).slice(-2) + "/" +
    dateFormat.getFullYear();
  }

  formatearFechaDiaMesAnnioHoraMinutoSeg(objFechaEntero) {
    let dateFormat: Date = new Date(objFechaEntero);
    return ("00" + dateFormat.getDate()).slice(-2) + "/" +
    ("00" + (dateFormat.getMonth() + 1)).slice(-2) + "/" +
    dateFormat.getFullYear() + " " +
    ("00" + dateFormat.getHours()).slice(-2) + ":" +
    ("00" + dateFormat.getMinutes()).slice(-2) + ":" +
    ("00" + dateFormat.getSeconds()).slice(-2) + " " + (dateFormat.getHours() < 12 ? "a.m." : "p.m.");
  }

  validarExpresionesRegulares(objValor: string, expresionRegular: string) {
    var objRegex = RegExp(expresionRegular);
    return objRegex.test(objValor);
  }

  /*mostrarMensajesDeValidacion(objTipo: string, objTitulo: string, objMensaje, objHTML : string) {
    Swal.fire({
      type: (objTipo == ConstantesCadenas.MENSAJE_ERROR ? 'error' : objTipo == ConstantesCadenas.MENSAJE_ADVERTENCIA ? 'info' : 'success'),
      title: objTitulo,
      text: objMensaje,
      html: objHTML
    });
  }*/

  compararFechas(objDate1, formatDate1, objDate2, formatDate2) {
  	/*
  	//   Compare two date strings to see which is greater.
  	//   Returns:
  	//   1 if date1 is greater than date2
  	//   0 if date2 is greater than date1 of if they are the same
  	//  -1 if either of the dates is in an invalid format
  	*/
  	let objDateCompare1 = this.formatearFechaConFormato(objDate1, formatDate1);
  	let objDateCompare2 = this.formatearFechaConFormato(objDate2, formatDate2);
  	if (objDateCompare1 == 0 || objDateCompare2 == 0)
  		return -1;
  	else if (objDateCompare1 > objDateCompare2)
  		return 1;
  	return 0;
  }

  enRangoFechas(objDateStart, objDateEnd, objDate3) {
    objDate3.setHours(0,0,0,0);
    let momentObjDate3 = this.momentFecha(objDate3);
    let momentobjDateStart = this.momentFecha(objDateStart);
    let momentobjDateEnd = this.momentFecha(objDateEnd);
    if ((momentObjDate3.toDate() >= momentobjDateStart.toDate()) && (momentObjDate3.toDate() <= momentobjDateEnd.toDate())) return true;
    /*if ((objDate3 >= objDateStart) && (objDate3 <= objDateEnd) ) {
      return true;
    }*/
    return false;
  }

  formatearFechaConFormato(objDate, formatDate) {
    objDate = objDate + "";
    formatDate = formatDate + "";
    let i_objDate : number = 0;
    let i_formatDate = 0;
    let c = "";
    let token = "";
    let x, y;
    let now = new Date();
    let year: number = now.getFullYear();
    let month: number = now.getMonth() + 1;
    let date: number = now.getDate();
    let hh: number = now.getHours();
    let mm: number = now.getMinutes();
    let ss: number = now.getSeconds();
    let ampm = "";

    while (i_formatDate < formatDate.length) {
    // Get next token from formatDate string
    c = formatDate.charAt(i_formatDate);
    token = "";
    while ((formatDate.charAt(i_formatDate) == c) && (i_formatDate < formatDate.length)) {
      token += formatDate.charAt(i_formatDate++);
    }
    // Extract contents of objDateue based on formatDate token
    if (token == "yyyy" || token == "yy" || token == "y") {
      if (token == "yyyy") { x = 4; y = 4; }
      if (token == "yy") { x = 2; y = 2; }
      if (token == "y") { x = 2; y = 4; }
      year = this.obtenerEntero(objDate, i_objDate, x, y);
      if (year == null) { return 0; }
      i_objDate += year.toString().length;
    }
    else if (token == "MMM") {
      month = 0;
      for (var i = 0; i < ConstantesListas.NOMBRE_DE_MESES.length; i++) {
        var month_name = ConstantesListas.NOMBRE_DE_MESES[i];
        if (objDate.substring(i_objDate, i_objDate + month_name.length).toLowerCase() == month_name.toLowerCase()) {
          month = i + 1;
          if (month > 12) { month -= 12; }
          i_objDate += month_name.length;
          break;
        }
      }
      if ((month < 1) || (month > 12)) { return 0; }
    }
    else if (token == "MM" || token == "M") {
      month = this.obtenerEntero(objDate, i_objDate, token.length, 2);
      if (month == null || (month < 1) || (month > 12)) { return 0; }
      i_objDate += month.toString().length;
    }
    else if (token == "dd" || token == "d") {
      date = this.obtenerEntero(objDate, i_objDate, token.length, 2);
      if (date == null || (date < 1) || (date > 31)) { return 0; }
      i_objDate += date.toString().length;
    }
    else if (token == "hh" || token == "h") {
      hh = this.obtenerEntero(objDate, i_objDate, token.length, 2);
      if (hh == null || (hh < 1) || (hh > 12)) { return 0; }
      i_objDate += hh.toString().length;
    }
    else if (token == "HH" || token == "H") {
      hh = this.obtenerEntero(objDate, i_objDate, token.length, 2);
      if (hh == null || (hh < 0) || (hh > 23)) { return 0; }
      i_objDate += hh.toString().length;
    }
    else if (token == "KK" || token == "K") {
      hh = this.obtenerEntero(objDate, i_objDate, token.length, 2);
      if (hh == null || (hh < 0) || (hh > 11)) { return 0; }
      i_objDate += hh.toString().length;
    }
    else if (token == "kk" || token == "k") {
      hh = this.obtenerEntero(objDate, i_objDate, token.length, 2);
      if (hh == null || (hh < 1) || (hh > 24)) { return 0; }
      i_objDate += hh.toString().length; hh--;
    }
    else if (token == "mm" || token == "m") {
      mm = this.obtenerEntero(objDate, i_objDate, token.length, 2);
      if (mm == null || (mm < 0) || (mm > 59)) { return 0; }
      i_objDate += mm.toString().length;
    }
    else if (token == "ss" || token == "s") {
      ss = this.obtenerEntero(objDate, i_objDate, token.length, 2);
      if (ss == null || (ss < 0) || (ss > 59)) { return 0; }
      i_objDate += ss.toString().length;
    }
    else if (token == "a") {
      if (objDate.substring(i_objDate, i_objDate + 2).toLowerCase() == "am") { ampm = "AM"; }
      else if (objDate.substring(i_objDate, i_objDate + 2).toLowerCase() == "pm") { ampm = "PM"; }
      else { return 0; }
      i_objDate += 2;
    }
    else {
      if (objDate.substring(i_objDate, i_objDate + token.length) != token) { return 0; }
      else { i_objDate += token.length; }
    }
    }
    // If there are any trailing characters left in the objDateue, it doesn't match
    if (i_objDate != objDate.length) { return 0; }
    // Is date objDateid for month?
    if (month == 2) {
    // Check for leap year
    if (((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0)) { // leap year
      if (date > 29) { return false; }
    }
    else { if (date > 28) { return false; } }
    }
    if ((month == 4) || (month == 6) || (month == 9) || (month == 11)) {
    if (date > 30) { return false; }
    }
    // Correct hours objDateue
    if (hh < 12 && ampm == "PM") { hh += 12; }
    else if (hh > 11 && ampm == "AM") { hh -= 12; }
    var newdate = new Date(year, month - 1, date, hh, mm, ss);
    return newdate.getTime();
  }

  esFechaValida(obj, formatDate) {
  	var date = this.formatearFechaConFormato(obj, formatDate);
  	if (date == 0) { return false; }
  	return true;
  }

  esEntero(obj) {
  	var digits = "1234567890";
  	for (var i = 0; i < obj.length; i++) {
  		if (digits.indexOf(obj.charAt(i)) == -1) { return false; }
  	}
  	return true;
  }

  obtenerEntero(str, i, minlength, maxlength) {
  	for (var x = maxlength; x >= minlength; x--) {
  		var token = str.substring(i, i + x);
  		if (token.length < minlength) { return null; }
  		if (this.esEntero(token)) { return token; }
  	}
  	return null;
  }

  existeElementoEnLista(elemento: string, lista: string[]) {
    for (let obj of lista) {
      if (obj == elemento) return true;
    }
    return false;
  }

  clonarObjeto(obj, ...atributosExcluir: string[]) {
      var copy;
      // Handle the 3 simple types, and null or undefined
      if (null == obj || "object" != typeof obj) return obj;

      // Handle Date
      if (obj instanceof Date) {
          copy = new Date();
          copy.setTime(obj.getTime());
          return copy;
      }

      // Handle Array
      if (obj instanceof Array) {
          copy = [];
          for (var i = 0, len = obj.length; i < len; i++) {
              //console.log(" index => " + i);
              //console.log(" obj => " + obj);
              copy[i] = this.clonarObjeto(obj[i], ...atributosExcluir);
          }
          return copy;
      }

      // Handle Object
      if (obj instanceof Object) {
          copy = {};
          for (var attr in obj) {
              if (!this.existeElementoEnLista(attr, atributosExcluir) && obj.hasOwnProperty(attr)) copy[attr] = this.clonarObjeto(obj[attr], ...atributosExcluir);
          }
          return copy;
      }
      throw new Error("¡No se puede copiar el objeto! Este tipo no es soportado.");
  }

  mostrarTablaDeErrores(listaErrores: ResponseErrorManager[]) {
    let html: string = "";
    html += "<div style='overflow-y: auto; overflow-x: hidden; height: 300px; width: 480px;'>";
    html +=   "<p style='text-align: justify; font-weight: bold;'>Descripción:</p>";
    if (listaErrores != null && listaErrores.length > 0) {
      html += "<div style='border: 1px solid black;'>";
      for (let i = 0; i < listaErrores.length; i++) {
        html += "<p style='text-align: justify;'>" + listaErrores[i].msg + "</p>";
      }
      html += "</div>";
    }
    html += "</div>";
    return html;
  }

  convertirFormatoDiaMesAnnioHoraMinutoSegundoComoCadena(objFecha: Date) {
    return ("00" + objFecha.getDate()).slice(-2) + "/" +
    ("00" + (objFecha.getMonth() + 1)).slice(-2) + "/" +
    objFecha.getFullYear() + " " +
    ("00" + objFecha.getHours()).slice(-2) + ":" +
    ("00" + objFecha.getMinutes()).slice(-2) + ":" +
    ("00" + objFecha.getSeconds()).slice(-2) + " " + (objFecha.getHours() < 12 ? "a.m." : "p.m.");
  }

  convertirFormatoDiaMesAnnioComoCadena(objFecha: Date) {
    if (typeof(objFecha) === 'number') {
      objFecha = new Date(objFecha);
    }
    return ("00" + objFecha.getDate()).slice(-2) + "/" + ("00" +
    (objFecha.getMonth() + 1)).slice(-2) + "/" +
    objFecha.getFullYear();
  }

  convertirFormatoAnnioMesDiaComoCadena(objFecha: Date) {
    if (typeof(objFecha) === 'number') {
      objFecha = new Date(objFecha);
    }
    return objFecha.getFullYear() + "-" + ("00" +
    (objFecha.getMonth() + 1)).slice(-2) + "-" + ("00" + objFecha.getDate()).slice(-2);
  }

  convertirFormatoCadenaDiaMesAnnioADate(objFecha: string) {
    let fechaActual: Date = new Date();
    fechaActual.setFullYear(parseInt(objFecha.split("/")[2]));
    fechaActual.setMonth(parseInt(objFecha.split("/")[1]));
    fechaActual.setDate(parseInt(objFecha.split("/")[0]));
    return fechaActual;
  }

  convertirFormatoCadenaDiaMesAnnioADateSlash(objFecha: string) {
    let annioAsignacion: number = parseInt(objFecha.split("-")[0]);
    let mesAsignacion: number = parseInt(objFecha.split("-")[1]) - 1;
    let diaAsignacion: number = parseInt(objFecha.split("-")[2]);
    let fechaActual: Date = new Date(annioAsignacion, mesAsignacion, diaAsignacion);
    return fechaActual;
  }

  /**
   * Considerar:
   * @param objFechaInicio - Fecha de Inicio en string.
   * @param objFechaFin - Fecha de Fin en string.
   * @param objFormatoFecha - Formato de la fecha en string.
   * @param objUnidadDeTiempo - Ir al ts: ConstantesCadenas y en la seccion IdentificadorFecha usar las siguientes constantes.
   */
  diferenciaEntreFechas(objFechaInicio: string,
                        objFechaFin: string,
                        objFormatoFecha: string,
                        objUnidadDeTiempo: any) {
    let fechaInicioMoment = moment(objFechaInicio, objFormatoFecha);
    let fechaFinMoment = moment(objFechaFin, objFormatoFecha);
    return fechaFinMoment.diff(fechaInicioMoment, objUnidadDeTiempo);
  }

  objTrim(obj: string) {
    return obj.trim();
  }

  sumarDias(fecha: Date, dias: number) {
    if (typeof(fecha) === 'number') {
      fecha = new Date(fecha);
    }
    return fecha.setDate(fecha.getDate() + dias);
  }

  restarDias(fecha: Date, dias: number) {
    if (typeof(fecha) === 'number') {
      fecha = new Date(fecha);
    }
    return fecha.setDate(fecha.getDate() - dias);
  }

  base64ToArrayBuffer(base64: any) {
    let binaryString = window.atob(base64);
    let binaryLen = binaryString.length;
    let bytes = new Uint8Array(binaryLen);
    for (let i = 0; i < binaryLen; i++) {
       let ascii = binaryString.charCodeAt(i);
       bytes[i] = ascii;
    }
    return bytes;
 }

 saveByteArray(reportName: string, byte: any, mimeType: string) {
    let blob = new Blob([byte], { type: mimeType });
    let link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.download = reportName;
    link.click();
    link.remove();
 }

 rucValido(ruc: number) {
    //11 dígitos y empieza en 10,15,16,17 o 20
    if (!(ruc >= 1e10 && ruc < 11e9
       || ruc >= 15e9 && ruc < 18e9
       || ruc >= 2e10 && ruc < 21e9))
        return false;
    for (var suma = -(ruc%10<2), i = 0; i<11; i++, ruc = ruc/10|0)
        suma += (ruc % 10) * (i % 7 + (i/7|0) + 1);
    return suma % 11 === 0;
 }

 validarListaNoVaciaONula(lista: any) {
   let noEsListaVaciaONula: boolean = false;
   if (lista != null && lista != undefined && lista.length > 0) {
     noEsListaVaciaONula = true;
   }
   return noEsListaVaciaONula;
 }

 mensajeRegistrosNoEncontrados() {
   let tituloErrores: string = "Mensaje de Advertencia: ";
   let errorMensaje = "No se encontraron registros.";
   this.mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ADVERTENCIA,
                                                                 tituloErrores, errorMensaje, "");
 }

  mostrarMensajesDeValidacion(objTipo: string, objTitulo: string, objMensaje, objHTML : string, callback?: () => any) {
    Swal.fire({
      type: (objTipo == ConstantesCadenas.MENSAJE_ERROR ? 'error' : objTipo == ConstantesCadenas.MENSAJE_ADVERTENCIA ? 'info' : 'success'),
      title: objTitulo,
      text: objMensaje,
      html: objHTML,
      onClose: () => {
        if(callback != undefined) callback();
      }
    });
  }

  mostrarModalCargando(){
    Swal.fire({
      title: "Cargando ...",
      allowEscapeKey: false,
      allowOutsideClick: false,
      onOpen: () => {
        Swal.showLoading();
      }
    });
  }

  cerrarModalCargando(){
    Swal.close();
  }

  darFormatoAMPM(horario){
    if (horario == " ") {
      return "";
    } else {
      let strFormato = " a.m.";
      let hora = +horario.substring(0,2);
      let minutos = horario.substring(3,5);
      if (hora >= 12) strFormato = " p.m.";
      if (hora > 12) hora -= 12;
      if (hora == 0) hora = 12;

      return (hora == 0 ? "12" : this.formatoHoraMinutoSegundoCadena(hora) + ":"
                               + this.formatoHoraMinutoSegundoCadena(parseInt(minutos)) + strFormato);
    }
  }

  formatoHoraMinutoSegundoCadena(hora: number) {
    return (hora < 10 ? "0" + hora.toString() : hora.toString());
  }

  convertirHoraCorteSorteoAEntero(hora: string) {
    return +hora.substr(0, 5).replace(":", "");
  }

  incluir (valor: string, ...lista: string[]) {
    if (valor == null || valor == undefined) return false;
    for (let i = 0; i < lista.length; ++i) {
      if (valor == lista[i]) return true;
    }
    return false;
  }

  convertirNumeroADate(objFecha: any) {
    if (typeof(objFecha) === 'number') {
      objFecha = new Date(objFecha);
    }
    return objFecha;
  }

  momentCompararFechas(objDateA, objDateB) {
    let strObjDateA: string = this.formatearFecha(objDateA);
    let strObjDateB: string = this.formatearFecha(objDateB);
    return moment(strObjDateA, ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO_MOMENT_DASH)
           .isSame(moment(strObjDateB, ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO_MOMENT_DASH));
  }

  momentRestarHorasMinutos(objFecha: Date, tipoFormato: string, cantidad: any) {
    let fechaActual;
    if (ConstantesCadenas.FORMATO_UNIDAD_TIEMPO_HORAS == tipoFormato) {
      fechaActual = moment(objFecha).subtract(cantidad, ConstantesCadenas.FORMATO_UNIDAD_TIEMPO_HORAS).toDate();
    } else if (ConstantesCadenas.FORMATO_UNIDAD_TIEMPO_MINUTOS == tipoFormato) {
      fechaActual = moment(objFecha).subtract(cantidad, ConstantesCadenas.FORMATO_UNIDAD_TIEMPO_MINUTOS).toDate();
    } else {
      fechaActual = moment(objFecha).subtract(cantidad, ConstantesCadenas.FORMATO_UNIDAD_TIEMPO_SEGUNDOS).toDate();
    }
    return fechaActual;
  }

  momentFecha(objFecha) {
    let strObjDate: string = this.formatearFecha(objFecha);
    return moment(strObjDate, ConstantesCadenas.FORMATO_FECHA_DIA_MES_ANNIO_MOMENT_DASH);
  }

  constructor() { }
}
