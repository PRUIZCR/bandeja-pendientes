import { Datacatalogo } from './datacatalogo';

export class PaquetesFormados {
  start: string;
  title: string;
  indice: number;
  codAnfora: string;
  numHorario: number;
  id: string;
  anfora: Datacatalogo;
  aduana: Datacatalogo;
  numSecHorario: number;

  constructor() { }
}
