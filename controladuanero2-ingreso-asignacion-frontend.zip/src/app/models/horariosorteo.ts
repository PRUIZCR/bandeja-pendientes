import { Sorteo } from "./sorteo";

export class Horariosorteo {
  sorteo: Sorteo;
  numSecHorario: number;
  horaSorteo: string;
  horaCorte: string;
  horaSorteoCorte: string;
  indicadorEliminacion: string;
  fechaProcesoFormarPaquete: Date;
  fechaProcesoAsignarPaquete: Date;
  estadoProcesoFormaPaquete: string;
  estadoProcesoAsignaPaquete: string;
  indFormacionPaquete: string;
  indAsignacionEspecialista: string;
  constructor() { }
}
