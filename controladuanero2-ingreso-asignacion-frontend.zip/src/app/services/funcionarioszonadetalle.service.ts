import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { ConstantesRest } from 'src/app/utils/constantesrest';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';

@Injectable({
  providedIn: 'root'
})
export class FuncionariosZonaDetalleService {

  constructor(private http: HttpClient) { }

  obtenerAsignacionFuncionariosAZonas(unidadDespacho: string,
                                      mes: string,
                                      anho: string) : Observable<any> {
    return this.http.get<HttpResponse<Object>>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_ASIGNACION_FUNCIONARIOS_ZONA,
                                                                                    unidadDespacho,
                                                                                    mes,
                                                                                    anho, "",  { observe: 'response' })).pipe(
      catchError(e => {
        return throwError(e.error);
      })
    );
  }
}
