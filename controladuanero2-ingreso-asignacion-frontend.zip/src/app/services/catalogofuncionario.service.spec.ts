import { TestBed } from '@angular/core/testing';

import { CatalogofuncionarioService } from './catalogofuncionario.service';

describe('CatalogofuncionarioService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CatalogofuncionarioService = TestBed.get(CatalogofuncionarioService);
    expect(service).toBeTruthy();
  });
});
