import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { ConstantesRest } from 'src/app/utils/constantesrest';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { AsignaFuncionarioZona } from 'src/app/models/asignafuncionariozona';

@Injectable({
  providedIn: 'root'
})
export class AsignaFuncionarioZonaService {

  constructor(private http: HttpClient) { }

  obtenerAsignacionFuncionariosAZonas(numAsigFuncZona: number) : Observable<any> {
    return this.http.get<HttpResponse<Object>>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_OBTENER_ASIGNACION_FUNCIONARIOS_ZONA,
                                                                                    numAsigFuncZona, "",  { observe: 'response' })).pipe(
      catchError(e => {
        if (e.status == 404) {
            return throwError(e);
        }
        return throwError(e.error);
      })
    );
  }

  obtenerFuncionariosDiponiblesPorTipoDeAsignacionAleatoria(asignacionFuncionarioZona: AsignaFuncionarioZona) {
    return this.http.put<HttpResponse<Object>>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_ASIGNAR_FUNCIONARIOS_ALEATORIO, asignacionFuncionarioZona.numAsignacion),
      asignacionFuncionarioZona, { observe: 'response' }).pipe(
        catchError(e => {
          return throwError(e.error);
        })
      );
  }

  revertirAsignacionFuncionariosAZonas(asignacionFuncionarioZona: AsignaFuncionarioZona) {
    return this.http.put<HttpResponse<Object>>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_REVERTIR_ASIGNACION_FUNCIONARIO_ZONA, asignacionFuncionarioZona.numAsignacion),
      asignacionFuncionarioZona, { observe: 'response' }).pipe(
        catchError(e => {
          return throwError(e.error);
        })
      );
  }

  grabarAsignacionDeFuncionarioAZonaManual(asignacionFuncionarioZona: AsignaFuncionarioZona) {
    return this.http.post<HttpResponse<Object>>(FuncionesGenerales.getInstance().reemplazarParametros(ConstantesRest.URL_GRABAR_ASIGNACION_FUNCIONARIO_ZONA, asignacionFuncionarioZona.numAsignacion),
      asignacionFuncionarioZona, { observe: 'response' }).pipe(
        catchError(e => {
          return throwError(e.error);
        })
      );
  }
}
