import { TestBed } from '@angular/core/testing';

import { CatempleadofuncionarioService } from './catempleadofuncionario.service';

describe('CatempleadofuncionarioService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CatempleadofuncionarioService = TestBed.get(CatempleadofuncionarioService);
    expect(service).toBeTruthy();
  });
});
