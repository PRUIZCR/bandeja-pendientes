import { TestBed } from '@angular/core/testing';

import { ReasignacionBloqueService } from './reasignacion-bloque.service';

describe('ReasignacionBloqueService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ReasignacionBloqueService = TestBed.get(ReasignacionBloqueService);
    expect(service).toBeTruthy();
  });
});
