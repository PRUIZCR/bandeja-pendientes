import { Combo } from './combo';
//import { UnidadSeleccionDAM } from './unidadselecciondam';

export class DetalleInformacionOperacionManual {
  id: number;
  titulo: string;
  descripcion: string;
  tipoControl: string;
  indSeleccion: string;
  lista: Combo[];
  objeto: any;
  constructor() { }
}
