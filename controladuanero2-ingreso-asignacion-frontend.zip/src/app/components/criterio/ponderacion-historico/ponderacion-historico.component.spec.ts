import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PonderacionHistoricoComponent } from './ponderacion-historico.component';

describe('PonderacionHistoricoComponent', () => {
  let component: PonderacionHistoricoComponent;
  let fixture: ComponentFixture<PonderacionHistoricoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PonderacionHistoricoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PonderacionHistoricoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
