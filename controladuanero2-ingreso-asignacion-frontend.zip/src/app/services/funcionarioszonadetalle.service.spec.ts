import { TestBed } from '@angular/core/testing';

import { FuncionariosZonaDetalleService } from './funcionarioszonadetalle.service';

describe('FuncionariosZonaDetalleService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FuncionariosZonaDetalleService = TestBed.get(FuncionariosZonaDetalleService);
    expect(service).toBeTruthy();
  });
});
