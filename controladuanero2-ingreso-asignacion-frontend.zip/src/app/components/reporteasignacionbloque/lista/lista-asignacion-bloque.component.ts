import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute, Params } from '@angular/router';
import { ReporteHorario } from 'src/app/models/reportehorario';
import { FuncionesGenerales } from 'src/app/utils/funcionesgenerales';
import { CatEmpleado } from 'src/app/models/catempleado';
import { ConstantesCadenas } from 'src/app/utils/constantescadenas';
import { ReportePaquetesService } from 'src/app/services/reportepaquetes.service';
import { ResponseManager } from 'src/app/models/responsemanager';
import { ResponseErrorManager } from 'src/app/models/responseerrormanager';
import { ReporteAsignacion, TipoPaquete } from 'src/app/models/reporteasignacion';

@Component({
  selector: 'app-lista-asignacion-bloque',
  templateUrl: './lista-asignacion-bloque.component.html',
  styleUrls: ['./lista-asignacion-bloque.component.css']
})
export class ListaAsignacionBloqueComponent implements OnInit {
  listaReporteHorarios: ReporteHorario[];
  funcionesGenerales: FuncionesGenerales;
  responseErrorManager: ResponseErrorManager;
  responseManager: ResponseManager;
  reporteAsignacion: ReporteAsignacion;
  habilitarCambiosRfu: boolean = false;
  esVigenteRfu: boolean = false;

  constructor(private route: ActivatedRoute,
              private location: Location,
              private reportePaquetesService: ReportePaquetesService) { }

  ngOnInit() {
    this.funcionesGenerales = FuncionesGenerales.getInstance();
    this.esVigenteRfu = this.route.snapshot.paramMap.get('esVigenteRfu') === 'true';
    this.route.params.forEach((params: Params) => {
      if (params['reporteAsignacion'] != undefined && params['reporteAsignacion'] != null) {        
        this.reporteAsignacion = JSON.parse(sessionStorage.getItem('reporteAsignacion')); //JSON.parse(params['reporteAsignacion']);
        this.reporteAsignacion.fechaDesde = FuncionesGenerales.getInstance().convertirFormatoCadenaDiaMesAnnioADate(this.reporteAsignacion.strFechaDesde);
        this.reporteAsignacion.fechaDesde.setMonth(this.reporteAsignacion.fechaDesde.getMonth() - 1);
        this.reporteAsignacion.fechaHasta = FuncionesGenerales.getInstance().convertirFormatoCadenaDiaMesAnnioADate(this.reporteAsignacion.strFechaHasta)
        this.reporteAsignacion.fechaHasta.setMonth(this.reporteAsignacion.fechaHasta.getMonth() - 1);
        this.listaReporteHorarios = this.formatearNombreCatEmpleadoCalcularTotalPaquete(this.reporteAsignacion.listaReporteHorarios);
        this.listaReporteHorarios = this.listaReporteHorarios.sort(FuncionesGenerales.getInstance().ordenarPor("horario", false));
        this.listaReporteHorarios = this.listaReporteHorarios.sort(FuncionesGenerales.getInstance().ordenarPor("fecha", false));
        this.habilitarCambiosRfu = this.reporteAsignacion.tipoPaquete === TipoPaquete.TIPO_PAQUETE_RFU;

        console.log("*****listaReporteHorarios*****");
        console.log(this.listaReporteHorarios);
      } else {
        this.listaReporteHorarios = [];
      }

    });
  }

  formatearNombreCatEmpleadoCalcularTotalPaquete(listaReporteHorarios: ReporteHorario[]) {

    listaReporteHorarios.map(
      x => {
        x.totalPaquetes = 0;
        x.totalPaquetes = x.listDetallePaquetes.length;
        x.listDetallePaquetes.map(
          y => {
            y.catEmpleado = this.eliminarEspaciosEnBlancoCatEmpleado(y.catEmpleado);
          }
        )
      }
    );
    return listaReporteHorarios;
  }

  eliminarEspaciosEnBlancoCatEmpleado(objCatEmpleado: CatEmpleado) {
    objCatEmpleado.apMate = objCatEmpleado.apMate.trim();
    objCatEmpleado.apPate = objCatEmpleado.apPate.trim();
    objCatEmpleado.nombres = objCatEmpleado.nombres.trim();
    return objCatEmpleado;
  }

  regresarReporte() {
    this.location.back();
  }

  exportarPDFExcel(nombrePaqueteFormado: string, tipoMime: string, tipoReporte: string) {
    console.log(this.reporteAsignacion);
    if(!this.habilitarCambiosRfu){
      this.reportePaquetesService.reporteAsignacionPaquetes(tipoReporte,
                                                            this.reporteAsignacion.codAnfora,
                                                            0,
                                                            this.reporteAsignacion.numHorario,
                                                            this.reporteAsignacion.rucAlmacen,
                                                            this.reporteAsignacion.codLocal,
                                                            this.reporteAsignacion.codFuncionario,
                                                            this.reporteAsignacion.fechaDesde,
                                                            this.reporteAsignacion.fechaHasta,
                                                            this.reporteAsignacion.numSorteo,
                                                            this.reporteAsignacion.numZona
                                                            ).subscribe(result => {
        FuncionesGenerales.getInstance().cerrarModalCargando();
        if (result != undefined && result != null) {
          let strBase64 = FuncionesGenerales.getInstance().base64ToArrayBuffer(result);
          FuncionesGenerales.getInstance().saveByteArray(nombrePaqueteFormado, strBase64, tipoMime);
        } else {
          FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                      "Mensajes de Error: ",
                                                                      "Ocurrio un error, comuníquese con el área de sistemas", '');
        }
      }, errorResult => {
        let error: any = errorResult;
        if (error.error.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
          let responseManager: ResponseManager = new ResponseManager();
          this.responseErrorManager = error.error as ResponseErrorManager;
          responseManager.cod = error.error.cod;
          responseManager.errors = [this.responseErrorManager];
          this.responseManager = responseManager;
          this.cargarMensajesReporteAsignacionPaquetes(this.responseManager);
        } else {
          this.responseManager = error.error as ResponseManager;
          this.responseErrorManager = new ResponseErrorManager();
          this.responseErrorManager.cod = error.error.cod;
          this.responseErrorManager.msg = error.error.msg;
          this.responseManager.errors = [this.responseErrorManager];
          this.cargarMensajesReporteAsignacionPaquetes(this.responseManager);
        }
      });
    } else {
      this.reportePaquetesService.reporteAsignacionPaquetesRfu(
        this.reporteAsignacion.codAduana,
        tipoReporte,
        this.reporteAsignacion.rucAlmacen,
        this.reporteAsignacion.codLocal,
        this.reporteAsignacion.codFuncionario,
        this.reporteAsignacion.fechaDesde,
        this.reporteAsignacion.fechaHasta
        ).subscribe(result => {
          FuncionesGenerales.getInstance().cerrarModalCargando();
          if (result != undefined && result != null) {
            let strBase64 = FuncionesGenerales.getInstance().base64ToArrayBuffer(result);
            FuncionesGenerales.getInstance().saveByteArray(nombrePaqueteFormado, strBase64, tipoMime);
          } else {
            FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                            "Mensajes de Error: ",
                            "Ocurrio un error, comuníquese con el área de sistemas", '');
          }
      }, errorResult => {
        let error: any = errorResult;
        if (error.error.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR) {
          let responseManager: ResponseManager = new ResponseManager();
          this.responseErrorManager = error.error as ResponseErrorManager;
          responseManager.cod = error.error.cod;
          responseManager.errors = [this.responseErrorManager];
          this.responseManager = responseManager;
          this.cargarMensajesReporteAsignacionPaquetes(this.responseManager);
        } else {
          this.responseManager = error.error as ResponseManager;
          this.responseErrorManager = new ResponseErrorManager();
          this.responseErrorManager.cod = error.error.cod;
          this.responseErrorManager.msg = error.error.msg;
          this.responseManager.errors = [this.responseErrorManager];
          this.cargarMensajesReporteAsignacionPaquetes(this.responseManager);
        }
      });
    }
  }

  cargarMensajesReporteAsignacionPaquetes(responseManager: ResponseManager) {
    if (responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO ||
        responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SERVICIO_GRABAR ||
        responseManager.cod == ConstantesCadenas.CODIGO_ERROR_SOLICITUD_INCORRECTA ||
        responseManager.cod == "999") {
      FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                   "Mensajes de Error: ",
                                                                    "",
                                                                    FuncionesGenerales.getInstance().mostrarTablaDeErrores(this.responseManager.errors));
    }
  }

  imprimir() {
    if (this.listaReporteHorarios == undefined ||
        this.listaReporteHorarios == null) {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    'Mensaje de Error: ',
                                                                    'No hay registros a mostrar en el reporte.', "");
          return false;
    } else {
      this.exportarPDFExcel(ConstantesCadenas.NOMBRE_REPORTE_ASIGNACION_BLOQUE_PAQUETES_PDF, ConstantesCadenas.TIPO_MIME_PDF, ConstantesCadenas.TIPO_REPORTE_PDF);
    }
  }

  exportar() {
    if (this.listaReporteHorarios == undefined ||
        this.listaReporteHorarios == null) {
        FuncionesGenerales.getInstance().mostrarMensajesDeValidacion(ConstantesCadenas.MENSAJE_ERROR,
                                                                    'Mensaje de Error: ',
                                                                    'No hay registros a mostrar en el reporte.', "");
    } else {
      this.exportarPDFExcel(ConstantesCadenas.NOMBRE_REPORTE_ASIGNACION_BLOQUE_PAQUETES_XLS, ConstantesCadenas.TIPO_MIME_EXCEL, ConstantesCadenas.TIPO_REPORTE_XLS);
    }
  }

}
